package com.jaatflix.tv

import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Relay (Wisper / Wispbyte) first, direct CDN as the fallback.
 *
 * - The site signs every link (/api/sign) and the signed links are carried by the relay. While the relay is trusted, the
 *   player gets the relay link first ([Source.url]) and keeps the direct CDN link as [Source.fb].
 * - Each time a relay link fails to play, that video goes DIRECT at once and the failure is counted ([fail]).
 * - After [MAX_FAILS] failures IN A ROW the relay is not used any more (every video plays direct).
 *   Every [RETRY_MS] one video tries the relay again; if it plays, the counter is reset ([ok]) and the relay is back.
 */
object Relay {
    const val MAX_FAILS = 10
    private const val RETRY_MS = 5 * 60_000L

    @Volatile private var fails = 0
    @Volatile private var nextProbe = 0L
    private val hosts: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /** True = build the sources with relay links first. Called once per video. */
    @Synchronized fun wanted(): Boolean {
        if (fails < MAX_FAILS) return true
        val now = System.currentTimeMillis()
        if (now >= nextProbe) { nextProbe = now + RETRY_MS; return true }   // one probe per window, the others stay direct
        return false
    }

    /** A relay link played: the relay is fine again. */
    @Synchronized fun ok() { fails = 0 }

    /** A relay link failed. */
    @Synchronized fun fail() {
        fails++
        if (fails >= MAX_FAILS) nextProbe = System.currentTimeMillis() + RETRY_MS
    }

    /** Remember the host of a relay link, so the player does not treat it like the CDN (no Referer swap, no http downgrade). */
    fun remember(url: String) {
        try { URL(url).host.takeIf { it.isNotEmpty() }?.let { hosts.add(it.lowercase()) } } catch (e: Exception) { }
    }

    fun isRelayHost(host: String) = hosts.contains(host.lowercase())

    /** This source is a relay link that still has its direct link behind it. */
    fun isRelay(s: Source?) = s != null && s.fb.isNotEmpty() && s.url != s.fb

    /** Same quality, direct CDN link. */
    fun direct(s: Source): Source = if (isRelay(s)) Source(s.label, s.res, s.fb, s.kind, "", false) else s
}
