package com.jaatflix.tv

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * The app asks MovieBox for the video links ITSELF (same steps as the website's "client resolve"),
 * so the links are made for this TV's own internet connection. No relay, no server in between:
 * the player fetches the CDN directly and adds the Referer / User-Agent headers itself (see PlayerActivity).
 */
object Mb {
    private const val API = "https://h5-api.aoneroom.com/wefeed-h5api-bff"
    private const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    private const val XCI = "{\"timezone\":\"Asia/Kolkata\"}"
    private const val IN_IP = "49.205.120.45"   // same India headers the relay / server send (they return Indian content)
    private const val HOME_REF = "https://moviebox.ph/"

    class Item(val url: String, val res: Int, val auto: Boolean)
    class Resolved(val items: List<Item>, val capId: String, val capFmt: String, val capIds: List<String>, val dom: String)

    @Volatile private var tok: String? = null
    @Volatile private var tokAt = 0L
    @Volatile private var lastKey = ""
    @Volatile private var lastAt = 0L
    @Volatile private var last: Resolved? = null

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Blocking GET with the SAME headers the relay (wisper) sends. Returns the JSON body and header [wantHeader] (if asked).
     *  Errors say exactly which step failed and what MovieBox answered. */
    private fun get(url: String, token: String?, ref: String = HOME_REF, wantHeader: String? = null, step: String = "request"): Pair<JSONObject, String?> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 25000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("Referer", ref)
            if (ref == HOME_REF) c.setRequestProperty("Origin", "https://moviebox.ph")
            c.setRequestProperty("X-Request-Lang", "en")
            c.setRequestProperty("X-Client-Info", XCI)
            c.setRequestProperty("Accept-Language", "en-IN,en;q=0.9")
            c.setRequestProperty("X-Forwarded-For", IN_IP)
            c.setRequestProperty("X-Real-IP", IN_IP)
            c.setRequestProperty("CF-Connecting-IP", IN_IP)
            c.setRequestProperty("CF-IPCountry", "IN")
            if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
            val code = try { c.responseCode } catch (e: java.io.IOException) {
                throw ApiException(0, "$step failed: ${e.javaClass.simpleName}: ${e.message ?: "no message"}")
            }
            val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val hv = if (wantHeader != null) c.getHeaderField(wantHeader) else null
            val j = try { JSONObject(body) } catch (e: Exception) { JSONObject() }
            if (code !in 200..299) throw ApiException(code, "$step: MovieBox answered HTTP $code" + (j.optString("message").takeIf { it.isNotEmpty() }?.let { " ($it)" } ?: ""), j)
            return Pair(j, hv)
        } finally {
            c.disconnect()
        }
    }

    /** get() that waits and retries on 429 and takes a fresh token once on 401/403 (like the relay's _mb). */
    private fun getRetry(url: String, tk0: String, ref: String, step: String): JSONObject {
        var tk = tk0; var fresh = false; var last: ApiException? = null
        for (attempt in 0..3) {
            try { return get(url, tk, ref, null, step).first }
            catch (e: ApiException) {
                last = e
                if (e.status == 429) { Thread.sleep(2500L * (attempt + 1)); continue }
                if ((e.status == 401 || e.status == 403) && !fresh) { tk = token(true); fresh = true; continue }
                throw e
            }
        }
        throw last ?: ApiException(502, "$step failed")
    }

    /** MovieBox gives an anonymous token in the x-user header of /home. Reused for 15 minutes. */
    private fun token(fresh: Boolean): String {
        val t = tok
        if (!fresh && t != null && System.currentTimeMillis() - tokAt < 15 * 60_000L) return t
        val (_, xu) = get("$API/home?host=moviebox.ph", null, HOME_REF, "x-user", "token")
        val n = try { JSONObject(xu ?: "").optString("token", "") } catch (e: Exception) { "" }
        if (n.isEmpty()) throw ApiException(502, "token: MovieBox gave no x-user token")
        tok = n; tokAt = System.currentTimeMillis()
        return n
    }

    /** Same title + episode again within a minute (captcha retry, Next button) reuses the answer. */
    fun resolveCached(id: String, slug: String, se: Int, ep: Int): Resolved {
        val key = "$id|$slug|$se|$ep"
        val l = last
        if (l != null && key == lastKey && System.currentTimeMillis() - lastAt < 60_000L) return l
        val r = try { resolve(id, slug, se, ep, false) } catch (e: Exception) { resolve(id, slug, se, ep, true) }   // 2nd try with a fresh token
        last = r; lastKey = key; lastAt = System.currentTimeMillis()
        return r
    }

    fun resolve(id: String, slug: String, se: Int, ep: Int, freshToken: Boolean): Resolved {
        val tk = token(freshToken)
        val dj = try { get("$API/media-player/get-domain", tk, HOME_REF, null, "get-domain").first } catch (e: ApiException) { JSONObject() }
        val dom = ((dj.opt("data") as? String) ?: "").ifEmpty { "https://netfilm.world" }.trimEnd('/')

        val combos = ArrayList<Pair<Int, Int>>()
        combos.add(Pair(se, ep))
        if (ep == 0) { combos.add(Pair(1, 1)); combos.add(Pair(0, 1)) }
        if (se == 0 && ep > 0) combos.add(Pair(1, ep))
        if (se > 0) combos.add(Pair(0, ep))
        fun q(s: Int, e: Int) = "?subjectId=" + enc(id) + "&se=$s&ep=$e&detailPath=" + enc(slug)

        fun ref(s: Int, e: Int) = "$dom/spa/videoPlayPage/movies/$slug?id=" + enc(id) + "&type=/movie/detail&detailSe=$s&detailEp=$e&lang=en"

        var pd: JSONObject? = null
        var used = Pair(se, ep)
        var tkNow = tk
        val why = StringBuilder()
        loop@ for ((s, e) in combos.take(4)) {
            for (round in 0..1) {
                val j = try { getRetry("$dom/wefeed-h5api-bff/subject/play" + q(s, e), tkNow, ref(s, e), "play se=$s ep=$e") }
                        catch (x: ApiException) { why.append("[se=$s ep=$e ${x.message}] "); break }
                val d = j.optJSONObject("data")
                if (d != null && d.optBoolean("hasResource")) { pd = d; used = Pair(s, e); break@loop }
                why.append("[se=$s ep=$e hasResource=false code=${j.opt("code")} msg=${j.optString("message")}] ")
                if (round == 0) tkNow = token(true)   // one retry with a fresh token (same as the relay)
            }
        }
        if (pd == null) throw ApiException(404, "No stream: " + why.toString().trim().take(300))

        var items = ArrayList<Item>()
        val hls = pd.optJSONArray("hls") ?: JSONArray()
        for (i in 0 until hls.length()) {
            val x = hls.opt(i)
            val u = if (x is JSONObject) x.optString("url") else (x as? String ?: "")
            if (u.isNotEmpty() && u != "null") items.add(Item(u, 9999, true))
        }
        val streams = pd.optJSONArray("streams") ?: JSONArray()
        for (i in 0 until streams.length()) {
            val s = streams.optJSONObject(i) ?: continue
            val u = s.optString("url")
            if (u.isNotEmpty() && u != "null") items.add(Item(u, s.optString("resolutions", "0").toDoubleOrNull()?.toInt() ?: 0, false))
        }

        // The download links (bcdnw host) replace the mp4 of the same quality: they are not tied to one connection.
        try {
            val dl = get("$dom/wefeed-h5api-bff/subject/download" + q(used.first, used.second), tkNow, ref(used.first, used.second), null, "download").first
            val ds = ArrayList<Item>()
            val have = HashSet<Int>()
            val arr = dl.optJSONObject("data")?.optJSONArray("downloads") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                val u = x.optString("url")
                val r = x.optString("resolution", "0").toDoubleOrNull()?.toInt() ?: 0
                if (u.isNotEmpty() && u != "null" && r > 0) { have.add(r); ds.add(Item(u, r, false)) }
            }
            if (ds.isNotEmpty()) {
                val kept = ArrayList<Item>()
                for (x in items) if (x.auto || x.url.contains(".m3u8") || !have.contains(x.res)) kept.add(x)
                kept.addAll(ds)
                items = kept
            }
        } catch (e: Exception) { /* optional */ }

        val dash = pd.optJSONArray("dash") ?: JSONArray()
        val first = streams.optJSONObject(0) ?: dash.optJSONObject(0)
        val ids = LinkedHashSet<String>()
        for (arr in listOf(streams, dash)) for (i in 0 until arr.length()) {
            val v = arr.optJSONObject(i)?.opt("id")
            if (v != null && v.toString().isNotEmpty() && v.toString() != "null") ids.add(v.toString())
        }
        val capId = first?.opt("id")?.toString()?.takeIf { it != "null" } ?: ""
        val capFmt = first?.optString("format", "")?.takeIf { it.isNotEmpty() && it != "null" } ?: "MP4"
        return Resolved(items, capId, capFmt, ids.take(8), dom)
    }
}
