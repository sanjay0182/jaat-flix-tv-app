package com.jaatflix.tv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/** [json] is the whole error body, so callers can see the guard flags (captcha / signin / open). */
class ApiException(val status: Int, message: String, val json: JSONObject = JSONObject()) : Exception(message)

/** Tiny HTTP + JSON helper for the site's own API (no WebView involved). */
object Net {
    val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(4)
    // Was 3: the home grid shows many posters at once, so only 3 parallel
    // downloads meant most cards sat queued behind the first few.
    // LIFO queue: the newest request (= the poster on screen NOW) is downloaded first; old ones that were queued while scrolling wait.
    private class LifoQueue : LinkedBlockingDeque<Runnable>() {
        override fun offer(e: Runnable): Boolean = offerFirst(e)
    }
    private val imgPool = ThreadPoolExecutor(4, 4, 30L, TimeUnit.SECONDS, LifoQueue()).apply { allowCoreThreadTimeOut(true) }
    // posters that are already on the disk are read here, so they never wait behind slow downloads
    private val diskPool = Executors.newFixedThreadPool(2)

    @Volatile
    var token: String? = null

    // ---- small in-memory cache for GET lists (home / more / browse / search): going back and forth does not download them again ----
    private val jsonCache = LruCache<String, Pair<Long, String>>(48)

    /** Like [request] (GET) but a fresh copy younger than [ttlMs] is reused; if the network fails, an older copy is better than an error. */
    fun requestCached(path: String, ttlMs: Long): JSONObject {
        val now = System.currentTimeMillis()
        val hit = synchronized(jsonCache) { jsonCache.get(path) }
        if (hit != null && now - hit.first < ttlMs) { try { return JSONObject(hit.second) } catch (e: Exception) { } }
        try {
            val j = request(path)
            synchronized(jsonCache) { jsonCache.put(path, Pair(now, j.toString())) }
            return j
        } catch (e: Exception) {
            if (hit != null && e !is ApiException) { try { return JSONObject(hit.second) } catch (x: Exception) { } }
            throw e
        }
    }

    // ---- the site's guard: a random device id (X-Device) and the TV pass (X-Captcha) ----
    private var appPrefs: android.content.SharedPreferences? = null
    @Volatile
    private var devId: String = ""
    private val DEV_RE = Regex("^[A-Za-z0-9_-]{8,40}$")

    /** The website address' host: the guard headers are only ever sent there, never to other video hosts. */
    val siteHost: String by lazy { try { URL(BuildConfig.SITE_URL).host } catch (e: Exception) { "" } }

    /** Call once with the application context (safe to call again). */
    fun init(ctx: Context) {
        if (appPrefs != null) return
        val p = ctx.getSharedPreferences("app", Context.MODE_PRIVATE)
        appPrefs = p
        val saved = p.getString("did", null)
        val id = if (saved != null && DEV_RE.matches(saved)) saved else {
            val a = "abcdefghijklmnopqrstuvwxyz0123456789"
            val r = SecureRandom()
            val fresh = String(CharArray(20) { a[r.nextInt(a.length)] })
            p.edit().putString("did", fresh).apply()
            fresh
        }
        devId = id
    }

    /** The TV pass token while it is still valid, else null. */
    fun tvToken(): String? {
        val p = appPrefs ?: return null
        val t = p.getString("tv_tok", null) ?: return null
        return if (p.getLong("tv_exp", 0L) > System.currentTimeMillis()) t else null
    }

    fun setTvPass(token: String, ttlSec: Long) {
        appPrefs?.edit()?.putString("tv_tok", token)
            ?.putLong("tv_exp", System.currentTimeMillis() + ttlSec * 1000L - 60_000L)?.apply()
    }

    fun forgetTvPass() {
        appPrefs?.edit()?.remove("tv_tok")?.remove("tv_exp")?.apply()
    }

    fun guardHeaders(): Map<String, String> {
        val m = HashMap<String, String>()
        if (devId.isNotEmpty()) m["X-Device"] = devId
        tvToken()?.let { m["X-Captcha"] = it }
        return m
    }

    private const val UA = "Mozilla/5.0 (Linux; Android 7.0; TV) JaatFlixTV/1.0"

    /** Relative paths ("/img/s/x", "/mq/...") are resolved against the site address. */
    fun abs(path: String): String {
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        return BuildConfig.SITE_URL + (if (path.startsWith("/")) "" else "/") + path
    }

    /** Blocking. GET when body == null, otherwise POST json. Call from a background thread. */
    fun request(path: String, body: JSONObject? = null): JSONObject {
        val c = URL(abs(path)).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", "application/json")
            token?.let { c.setRequestProperty("Authorization", "Bearer $it") }
            if (c.url.host == siteHost) for ((k, v) in guardHeaders()) c.setRequestProperty(k, v)
            if (body != null) {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val json = try {
                JSONObject(text)
            } catch (e: Exception) {
                JSONObject()
            }
            if (code !in 200..299) throw ApiException(code, json.optString("error", "HTTP $code"), json)
            return json
        } finally {
            c.disconnect()
        }
    }

    /** Runs [work] on a background thread, then [ok] or [fail] on the UI thread. */
    fun <T> async(work: () -> T, ok: (T) -> Unit, fail: (Exception) -> Unit = {}) {
        pool.execute {
            try {
                val r = work()
                main.post { ok(r) }
            } catch (e: Throwable) {
                // Throwable (not just Exception) so an OutOfMemoryError etc. shows the error screen instead of killing the app
                main.post { fail(if (e is Exception) e else RuntimeException(e.toString(), e)) }
            }
        }
    }

    fun loadImage(iv: ImageView, url: String, targetW: Int) = Img.load(iv, url, targetW)

    internal fun submitImage(r: Runnable) = imgPool.execute(r)

    internal fun submitDisk(r: Runnable) = diskPool.execute(r)
}

object Img {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    // Disk cache: posters already seen show instantly and cost no data. Capped; oldest files are trimmed.
    private const val DISK_CACHE_MAX_BYTES = 80L * 1024 * 1024
    private var diskDir: java.io.File? = null
    private val diskLock = Any()
    private var writesSinceTrim = 0

    private class Req(val url: String, val w: Int, val attempt: Int, val onSet: ((Bitmap) -> Unit)?)

    /** Cards waiting for their turn. A poster is downloaded ONLY when its card is on (or right next to) the screen,
     *  so rows far below / far to the right, and screens that are covered by another screen, cost no data at all. Main thread only. */
    private val pending = java.util.WeakHashMap<ImageView, Req>()
    @Volatile var paused = false
    private var started = 0
    /** Every activity that shows posters calls these from onStart / onStop: when none is visible (home button, player) nothing is downloaded. */
    fun activityStarted() { started++; paused = false; kick() }
    fun activityStopped() { started--; if (started <= 0) { started = 0; paused = true } }
    private var dm: android.util.DisplayMetrics? = null

    private val sweepRun = Runnable { sweep() }

    /** Call when something scrolled / appeared / came back: loads the posters that are now close to the screen. */
    fun kick() {
        Net.main.removeCallbacks(sweepRun)
        Net.main.postDelayed(sweepRun, 150L)
    }

    /** Call once (e.g. from MainActivity.onCreate) before the first load(). */
    fun init(appContext: android.content.Context) {
        dm = appContext.resources.displayMetrics
        if (diskDir != null) return
        val d = java.io.File(appContext.cacheDir, "posters")
        if (!d.exists()) d.mkdirs()
        diskDir = d
    }

    private fun diskFile(url: String, targetW: Int): java.io.File? {
        val dir = diskDir ?: return null
        val key = java.security.MessageDigest.getInstance("MD5")
            .digest(url.toByteArray()).joinToString("") { "%02x".format(it) }
        return java.io.File(dir, "${key}_$targetW.webp")
    }

    private fun trimDiskCacheIfNeeded() {
        val dir = diskDir ?: return
        synchronized(diskLock) {
            writesSinceTrim++
            if (writesSinceTrim < 20) return
            writesSinceTrim = 0
            val files = dir.listFiles() ?: return
            var total = files.sumOf { it.length() }
            if (total <= DISK_CACHE_MAX_BYTES) return
            for (f in files.sortedBy { it.lastModified() }) {
                if (total <= DISK_CACHE_MAX_BYTES) break
                val len = f.length()
                if (f.delete()) total -= len
            }
        }
    }

    /** Is this image on the screen, or at most about one card away from it? */
    private fun near(iv: ImageView): Boolean {
        if (!iv.isAttachedToWindow || !iv.isShown || iv.width <= 0 || iv.height <= 0) return false
        val m = dm ?: return true
        val loc = IntArray(2)
        iv.getLocationInWindow(loc)
        val mx = iv.width.coerceAtMost(m.widthPixels / 3)
        val my = iv.height / 2
        return loc[0] + iv.width > -mx && loc[0] < m.widthPixels + mx && loc[1] + iv.height > -my && loc[1] < m.heightPixels + my
    }

    private fun sweep() {
        if (paused || pending.isEmpty()) return
        val list = ArrayList(pending.entries.map { Pair(it.key, it.value) })
        var started = 0
        for ((iv, rq) in list) {
            if (iv == null) continue
            if (iv.tag != rq.url) { pending.remove(iv); continue }
            if (near(iv)) {
                if (started >= 12) { kick(); break }      // a few at a time, never a burst
                pending.remove(iv)
                start(iv, rq)
                started++
            }
        }
    }

    fun load(iv: ImageView, url: String, targetW: Int, attempt: Int = 0, onSet: ((Bitmap) -> Unit)? = null) {
        iv.tag = url
        val hit = cache.get(url)
        if (hit != null) {
            iv.animate().cancel(); iv.alpha = 1f
            iv.setImageBitmap(hit)
            onSet?.invoke(hit)
            return
        }
        if (attempt == 0) { iv.animate().cancel(); iv.alpha = 1f; iv.setImageDrawable(null) }
        if (url.isEmpty()) { pending.remove(iv); return }
        pending[iv] = Req(url, targetW, attempt, onSet)
        kick()
    }

    private fun start(iv: ImageView, rq: Req) {
        val url = rq.url; val targetW = rq.w; val attempt = rq.attempt; val onSet = rq.onSet
        // 1) disk cache, on its own small pool: a poster seen before shows at once and costs nothing
        Net.submitDisk(Runnable {
          try {
            if (iv.tag != url) return@Runnable
            val df = diskFile(url, targetW)
            if (attempt == 0 && df != null && df.exists()) {
                val fromDisk = try {
                    BitmapFactory.decodeFile(df.path, BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 })
                } catch (e: Exception) { null }
                if (fromDisk != null) {
                    cache.put(url, fromDisk)
                    Net.main.post { if (iv.tag == url) { fadeIn(iv, fromDisk); onSet?.invoke(fromDisk) } }
                    return@Runnable
                }
            }
            // 2) network (newest request first)
            Net.submitImage(Runnable {
              try {
                if (iv.tag != url) return@Runnable
                // the card was covered by another screen / scrolled far away while waiting: do NOT download, wait until it is seen again
                if (paused || !iv.isAttachedToWindow) {
                    Net.main.post { if (iv.tag == url) { pending[iv] = Req(url, targetW, attempt, onSet) } }
                    return@Runnable
                }
                val bmp = try { download(url, targetW) } catch (e: Exception) { null }
                if (bmp != null) {
                    cache.put(url, bmp)
                    Net.main.post { if (iv.tag == url) { fadeIn(iv, bmp); onSet?.invoke(bmp) } }
                    if (df != null) {
                        try {
                            @Suppress("DEPRECATION")
                            val fmt = if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                            java.io.FileOutputStream(df).use { bmp.compress(fmt, 80, it) }
                            trimDiskCacheIfNeeded()
                        } catch (e: Throwable) { /* disk cache is best-effort */ }
                    }
                } else if (attempt < 2) {
                    // failed (server asleep / bad link): at most 2 slow retries, only while the card is still wanted
                    Net.main.postDelayed({ if (iv.tag == url) load(iv, url, targetW, attempt + 1, onSet) }, 3000L * (attempt + 1))
                }
              } catch (t: Throwable) {
                cache.evictAll()
              }
            })
          } catch (t: Throwable) {
            cache.evictAll()
          }
        })
    }

    private fun fadeIn(iv: ImageView, bmp: Bitmap) {
        iv.alpha = 0f
        iv.setImageBitmap(bmp)
        iv.animate().alpha(1f).setDuration(180).start()
    }

    /** The poster CDN (aoneroom) resizes on request: ?x-oss-process=image/resize,w_N gives a picture 94-98% smaller (checked on real posters). */
    private fun small(url: String, targetW: Int): String {
        val host = try { URL(url).host } catch (e: Exception) { return url }
        if (!host.endsWith("aoneroom.com") || url.contains("x-oss-process")) return url
        val w = (((targetW + 49) / 50) * 50).coerceIn(150, 1280)
        return url + (if (url.contains("?")) "&" else "?") + "x-oss-process=image/resize,w_" + w
    }

    private fun download(url: String, targetW: Int): Bitmap? {
        val sm = small(url, targetW)
        if (sm != url) {
            val b = try { fetch(sm, targetW) } catch (e: Exception) { null }
            if (b != null) return b       // small picture worked; otherwise fall back to the original link below
        }
        return fetch(url, targetW)
    }

    private fun fetch(url: String, targetW: Int): Bitmap? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 12000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 7.0; TV) JaatFlixTV/1.0")
            if (c.responseCode !in 200..299) return null
            if (c.contentLength > 3_000_000) return null      // a poster is never this big: do not waste data on it
            val bytes = c.inputStream.use { it.readBytes() }
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var sample = 1
            while (o.outWidth / (sample * 2) >= targetW) sample *= 2
            val o2 = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
        } finally {
            c.disconnect()
        }
    }
}
