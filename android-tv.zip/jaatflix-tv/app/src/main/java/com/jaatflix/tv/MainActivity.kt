package com.jaatflix.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * PART 2: the full browsing app. Home (tabs, hero, rows, continue watching, My List), All-grid, Search,
 * Detail (language, seasons, episodes, My List), sign-in. Play = gets the video links (captcha QR / sign-in handled);
, Play opens PlayerActivity (part 3).
 */
class MainActivity : Activity() {
    private val ACCENT = 0xFF0A84FF.toInt()
    private val BG = 0xFF08090C.toInt()
    private val MUTED = 0xFFA29DA6.toInt()
    private val ACCENT2 = 0xFF4AA3FF.toInt()
    private val LINE = 0xFF272932.toInt()
    private val GOLD = 0xFFFFD166.toInt()
    private val PANEL = 0xFF1B1C23.toInt()

    private class Screen(val view: View, var focus: View? = null)

    private val stack = ArrayList<Screen>()
    private lateinit var content: FrameLayout
    private val h = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences

    // home state
    private var cat = "all"
    private var refocusCat = false
    private val catViews = HashMap<String, View>()
    private var sections: List<Section> = emptyList()
    private lateinit var homeBody: FrameLayout
    private var homeLoadFailed = false

    // account state
    private var me: Me? = null
    private val favIds = HashSet<String>()
    private var busy = false

    // hero
    private var heroItems: List<Title> = emptyList()
    private var heroIdx = 0
    private var heroImg: ImageView? = null
    private var heroTitle: TextView? = null
    private var heroMeta: TextView? = null
    private var heroKick: TextView? = null
    private var heroTag: TextView? = null
    private var heroGenres: LinearLayout? = null
    private var heroSeg: LinearLayout? = null
    private var heroBtns: Pair<View, View>? = null
    // the hero asks the detail page for rating / year ONCE per title (it used to ask again on every 7 s slide change)
    private val heroMeta2 = HashMap<String, Detail>()
    private val heroAsked = HashSet<String>()
    private val heroTick = object : Runnable {
        override fun run() {
            if (heroItems.size > 1 && stack.size == 1) { heroIdx = (heroIdx + 1) % heroItems.size; paintHero() }
            h.postDelayed(this, 7000L)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Net.init(applicationContext)
        Img.init(applicationContext)
        prefs = getSharedPreferences("app", MODE_PRIVATE)
        Net.token = prefs.getString("jf_token", null)
        content = FrameLayout(this).apply { setBackgroundColor(BG) }
        setContentView(content)
        // posters are loaded only for cards that are on / next to the screen: wake the loader when something scrolls or is laid out
        content.viewTreeObserver.addOnScrollChangedListener { Img.kick() }
        content.viewTreeObserver.addOnGlobalLayoutListener { Img.kick() }
        push(buildHomeShell())
        loadHome("")
        if (Net.token != null) loadMe()
    }

    override fun onResume() {
        super.onResume(); h.removeCallbacks(heroTick); h.postDelayed(heroTick, 7000L)
        // back from the player: refresh Continue watching
        if (PlayerEvents.played) { PlayerEvents.played = false; if (Net.token != null) loadMe() }
    }
    override fun onPause() { super.onPause(); h.removeCallbacks(heroTick) }
    // the app is not visible (player / home button): no poster downloads at all
    override fun onStop() { super.onStop(); Img.activityStopped() }
    override fun onStart() { super.onStart(); Img.activityStarted() }

    /** Remote: LEFT on "Watch now" = previous hero slide, RIGHT on "Details" = next slide (like swiping on the website). */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && stack.size == 1 && heroItems.size > 1) {
            val f = currentFocus
            val b = heroBtns
            if (b != null && f != null) {
                val step = if (event.keyCode == KeyEvent.KEYCODE_DPAD_LEFT && f === b.first) -1
                    else if (event.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && f === b.second) 1 else 0
                if (step != 0) {
                    heroIdx = (heroIdx + step + heroItems.size) % heroItems.size
                    paintHero()
                    h.removeCallbacks(heroTick); h.postDelayed(heroTick, 7000L)
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onBackPressed() { if (stack.size > 1) pop() else super.onBackPressed() }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) { openAccount(); return true }
        return super.onKeyDown(keyCode, event)
    }

    // ------------------------------------------------------------------ navigation
    private fun push(v: View) {
        if (stack.isNotEmpty()) { stack.last().focus = currentFocus; content.removeAllViews() }
        stack.add(Screen(v))
        content.addView(v)
        v.post { v.requestFocus() }
    }

    private fun pop() {
        if (stack.size <= 1) return
        stack.removeAt(stack.size - 1)
        content.removeAllViews()
        val s = stack.last()
        content.addView(s.view)
        s.view.post { if (s.focus?.requestFocus() != true) s.view.requestFocus(); Img.kick() }
    }

    // ------------------------------------------------------------------ small ui helpers
    private fun stateBg(fill: Int, r: Int): StateListDrawable {
        val f = GradientDrawable().apply { setColor(fill); cornerRadius = r.toFloat(); setStroke(dp(3), ACCENT2) }
        val n = GradientDrawable().apply {
            setColor(fill); cornerRadius = r.toFloat()
            if (fill != Color.TRANSPARENT && fill != ACCENT) setStroke(dp(1), LINE)
        }
        return StateListDrawable().apply { addState(intArrayOf(android.R.attr.state_focused), f); addState(intArrayOf(), n) }
    }

    private fun pill(label: String, accent: Boolean = false, selected: Boolean = false, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            isFocusable = true
            isClickable = true
            background = stateBg(if (accent || selected) ACCENT else PANEL, dp(22))
            setOnClickListener { onClick() }
        }

    private fun lp(w: Int, hh: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, hh).apply { setMargins(l, t, r, b) }

    private fun text(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun scroll(inner: View): ScrollView = ScrollView(this).apply {
        isVerticalScrollBarEnabled = false
        isFillViewport = true
        addView(inner)
    }

    /** Poster card (2:3) with rating, language badge and an optional progress bar. */
    private fun card(t: Title, w: Int = dp(140), onClick: () -> Unit): View {
        val ph = (w * 3) / 2
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isFocusable = true
            isClickable = true
            layoutParams = lp(w + dp(8), ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(10), dp(6))
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = stateBg(Color.TRANSPARENT, dp(10))
            setOnClickListener { onClick() }
        }
        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(w, ph)
            background = GradientDrawable().apply { setColor(0xFF1B1B24.toInt()); cornerRadius = dp(8).toFloat() }
            clipToOutline = true
        }
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(w, ph)
        }
        frame.addView(iv)
        t.rating?.let {
            frame.addView(TextView(this).apply {
                this.text = "\u2605 " + String.format("%.1f", it); textSize = 11f; setTextColor(GOLD); setTypeface(typeface, Typeface.BOLD)
                setPadding(dp(6), dp(2), dp(6), dp(2))
                background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = dp(6).toFloat() }
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(4), dp(4), 0) }
            })
        }
        // like the website: kind + year on the bottom of the poster
        frame.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xCC000000.toInt(), 0x00000000))
            layoutParams = FrameLayout.LayoutParams(w, dp(44), Gravity.BOTTOM)
        })
        frame.addView(TextView(this).apply {
            this.text = listOf(kindOf(t), t.year).filter { it.isNotEmpty() }.joinToString("  \u00B7  ")
            textSize = 11f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(6), 0, dp(6), dp(6))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START)
        })
        t.badge?.let {
            frame.addView(TextView(this).apply {
                this.text = it; textSize = 11f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
                setPadding(dp(6), dp(2), dp(6), dp(2)); setBackgroundColor(ACCENT)
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
            })
        }
        if (t.pct > 0) {
            frame.addView(View(this).apply {
                setBackgroundColor(0x66FFFFFF)
                layoutParams = FrameLayout.LayoutParams(w, dp(4), Gravity.BOTTOM)
            })
            frame.addView(View(this).apply {
                setBackgroundColor(ACCENT)
                layoutParams = FrameLayout.LayoutParams((w * t.pct) / 100, dp(4), Gravity.BOTTOM)
            })
        }
        box.addView(frame)
        box.addView(TextView(this).apply {
            this.text = t.name; maxLines = 2; textSize = 14f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT)
            setPadding(dp(2), dp(6), dp(2), 0)
        })
        val sub = t.genre.split(",").firstOrNull()?.trim().orEmpty()
        if (sub.isNotEmpty()) box.addView(TextView(this).apply {
            this.text = sub; maxLines = 1; textSize = 11f; setTextColor(MUTED)
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT)
            setPadding(dp(2), 0, dp(2), 0)
        })
        Net.loadImage(iv, t.poster, w)
        return box
    }

    // ------------------------------------------------------------------ HOME
    private fun buildHomeShell(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(40), dp(14), dp(40), dp(6))
        }
        bar.addView(logoView(), lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(24), 0))
        bar.addView(View(this), lp(0, 1).apply { weight = 1f })
        bar.addView(pill("Search") { openSearch() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, dp(10), 0, 0, 0))
        bar.addView(pill("My List") { openMyList() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, dp(10), 0, 0, 0))
        bar.addView(pill(if (Net.token != null) "Account" else "Sign in") { openAccount() }.also { accountBtn = it }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, dp(10), 0, 0, 0))
        col.addView(bar)
        homeBody = FrameLayout(this)
        col.addView(homeBody, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return col
    }

    /** Same logo as the website: "JAAT" in the blue accent + "FLIX" in white, bold italic capitals. */
    private fun logoView(): TextView = TextView(this).apply {
        val sp = SpannableStringBuilder("JAATFLIX")
        sp.setSpan(ForegroundColorSpan(ACCENT), 0, 4, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sp.setSpan(ForegroundColorSpan(Color.WHITE), 4, 8, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        this.text = sp
        textSize = 26f
        setTypeface(Typeface.defaultFromStyle(Typeface.BOLD_ITALIC))
        letterSpacing = -0.02f
    }

    private val HIDE_ROW = Regex("free\\s*now|midnight|18\\+|adult", RegexOption.IGNORE_CASE)
    private fun hiddenName(n: String) = HIDE_ROW.containsMatchIn(n)
    private fun kindOf(t: Title) = when (kindKey(t, "")) { "tv" -> "Series"; "anime" -> "Anime"; "short" -> "Short"; else -> "Movie" }

    private var accountBtn: TextView? = null

    private val CATS = listOf("all" to "Home", "movie" to "Movies", "tv" to "TV Shows", "anime" to "Anime", "short" to "Shorts")
    private val RE_ANIME_G = Regex("anim(e|ation)", RegexOption.IGNORE_CASE)
    private val RE_SHORT = Regex("short", RegexOption.IGNORE_CASE)
    private val RE_ANIME_S = Regex("anime|animation", RegexOption.IGNORE_CASE)
    private val RE_TV_S = Regex("series|drama|tv\\b|show", RegexOption.IGNORE_CASE)
    private val RE_MOVIE_S = Regex("movie|cinema|bollywood|hollywood|south", RegexOption.IGNORE_CASE)
    private val RE_TOP = Regex("trending|top|hot|rank|popular|most", RegexOption.IGNORE_CASE)
    private val RE_EMOJI = Regex("[\\p{So}\\p{Cn}\\uFE0F\\u200D]")

    /** Same grouping rules as the website (kindOf): anime / short / tv / movie. */
    private fun kindKey(t: Title, sec: String): String {
        if (RE_ANIME_G.containsMatchIn(t.genre)) return "anime"
        when (t.type) { 7 -> return "short"; 2 -> return "tv"; 1 -> return "movie" }
        return when {
            RE_SHORT.containsMatchIn(sec) -> "short"
            RE_ANIME_S.containsMatchIn(sec) -> "anime"
            RE_TV_S.containsMatchIn(sec) -> "tv"
            RE_MOVIE_S.containsMatchIn(sec) -> "movie"
            else -> "other"
        }
    }

    private fun cleanT(s: String) = s.replace(RE_EMOJI, "").trim()

    private fun loadHome(tab: String = "") {
        homeLoadFailed = false
        homeBody.removeAllViews()
        homeBody.addView(text("Loading\u2026", 20f, MUTED).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        Net.async({ Api.homeFull("") }, { d ->
            sections = d.sections
            renderHome()
        }, { e ->
            homeLoadFailed = true
            homeBody.removeAllViews()
            val t = text(Guard.message(e) + "\nPress OK to retry.", 20f, MUTED).apply { gravity = Gravity.CENTER; isFocusable = true; isClickable = true }
            t.setOnClickListener { loadHome() }
            homeBody.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            t.post { t.requestFocus() }
        })
    }

    /** Home / Movies / TV Shows / Anime / Shorts + Browse, same as the website's category bar. */
    private fun catBar(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(4)) }
        catViews.clear()
        for ((k, label) in CATS) {
            val v = pill(label, selected = cat == k) { if (cat != k) { cat = k; refocusCat = true; renderHome() } }
            catViews[k] = v
            row.addView(v, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(8), 0))
        }
        row.addView(pill("Browse \u203A") { openBrowse(if (cat == "all") "movie" else cat) })
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun renderHome() {
        if (homeLoadFailed) return
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(40), dp(4), dp(40), dp(40)) }
        // same rules as the website: "Free Now" and Midnight rows are hidden, Shorts go to the bottom
        val shown = sections.filter { it.isBanner || !hiddenName(it.title) }
        val banner = shown.firstOrNull { it.isBanner }
        val rest = shown.filter { !it.isBanner }.sortedBy { if (RE_SHORT.containsMatchIn(it.title)) 1 else 0 }
        heroItems = if (cat == "all") (banner?.items ?: rest.firstOrNull()?.items ?: emptyList()).take(8) else emptyList()
        heroIdx = 0
        if (heroItems.isNotEmpty()) col.addView(buildHero()) else heroBtns = null
        col.addView(catBar())
        val m = me
        if (cat == "all") {
            if (m != null && m.progress.isNotEmpty()) addRow(col, "Continue watching", m.progress, null) { t -> openDetail(t) }
            for (s in rest) {
                val more = s.moreId
                addRow(col, cleanT(s.title), s.items, if (more != null) ({ p: Int -> Api.more(more, s.title, p) }) else null,
                    RE_TOP.containsMatchIn(s.title) && s.items.size >= 5) { t -> openDetail(t) }
            }
        } else {
            buildCategory(col, rest)
        }
        homeBody.removeAllViews()
        homeBody.addView(scroll(col))
        if (refocusCat) { refocusCat = false; homeBody.post { catViews[cat]?.requestFocus() } }
        else if (stack.size == 1) homeBody.post { homeBody.requestFocus() }
    }

    /** One category (Movies / TV Shows / Anime / Shorts) built from the home feed, like the website. Every row keeps loading more when you scroll to its end. */
    private fun buildCategory(col: LinearLayout, rest: List<Section>) {
        val seen = HashSet<String>()
        val mixed = ArrayList<Title>()
        var n = 0
        val isS = cat == "short"
        val label = CATS.first { it.first == cat }.second
        if (isS) {
            col.addView(pill("\u25B6  Watch Shorts (full-screen reels)", accent = true) { openReels(null) },
                lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(8), 0, dp(4)))
        }
        for (s in rest) {
            val its = s.items.filter { kindKey(it, s.title) == cat && !seen.contains(it.slug) }
            val pure = its.isNotEmpty() && its.size == s.items.size
            if (isS && !pure && !RE_SHORT.containsMatchIn(s.title)) {
                for (i in its) if (mixed.none { it.slug == i.slug }) mixed.add(i)
                continue
            }
            if (its.size < (if (isS) 1 else 3)) continue
            for (i in its) seen.add(i.slug)
            n++
            val mo = s.moreId
            // more pages of the same row, only the titles of THIS category are kept
            addRow(col, cleanT(s.title), its.take(20), if (mo != null) ({ p: Int -> Api.more(mo, s.title, p) }) else null,
                keep = { t -> kindKey(t, s.title) == cat }) { t -> if (isS) openReels(t) else openDetail(t) }
        }
        val ml = mixed.filter { !seen.contains(it.slug) }
        if (ml.isNotEmpty()) { n++; addRow(col, "More " + label.lowercase(), ml.take(30), null) { t -> if (isS) openReels(t) else openDetail(t) } }
        // the whole catalogue of this category (same list as Browse), scrolls on and on
        val bt = when (cat) { "movie" -> "movie"; "tv" -> "tv"; "anime" -> "anime"; else -> "" }
        if (bt.isNotEmpty()) {
            n++
            addRow(col, "All $label", emptyList(), { p: Int -> Api.browse(bt, "All", "All", "All", "All", "ForYou", p) }) { t -> if (isS) openReels(t) else openDetail(t) }
        }
        if (n == 0) col.addView(text("Nothing in this category on the home feed right now.", 18f, MUTED).apply { setPadding(0, dp(20), 0, dp(20)) })
    }

    /**
     * One horizontal row. When [more] is given the row loads the next page by itself as soon as you get near its end
     * (remote: moving right; touch: swiping), so there is no "See all" button any more.
     * [keep] filters the extra pages (used by the category screens).
     */
    private fun addRow(col: LinearLayout, title: String, items: List<Title>, more: ((Int) -> List<Title>)?, top: Boolean = false,
                       keep: (Title) -> Boolean = { true }, click: (Title) -> Unit) {
        if (items.isEmpty() && more == null) return
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(16), 0, dp(6)) }
        head.addView(text(title, 20f, Color.WHITE, true), lp(0, ViewGroup.LayoutParams.WRAP_CONTENT).apply { weight = 1f })
        col.addView(head)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(4)) }
        val rank = top && items.size >= 5
        fun cellFor(t: Title, k: Int): View {
            if (!rank) return card(t) { click(t) }
            // "Top 10" style rail: big rank number next to the poster
            val cell = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
            cell.addView(TextView(this).apply {
                this.text = (k + 1).toString(); textSize = 54f; setTextColor(0x66FFFFFF.toInt())
                setTypeface(Typeface.defaultFromStyle(Typeface.BOLD_ITALIC)); includeFontPadding = false
                setPadding(0, 0, dp(2), dp(36))
            })
            cell.addView(card(t) { click(t) })
            return cell
        }
        val shown = if (rank) items.take(10) else items
        for ((k, t) in shown.withIndex()) row.addView(cellFor(t, k))
        val hs = EndlessScroll(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            addView(row)
        }
        col.addView(hs)
        if (more == null || rank) return

        // ---- endless loading
        val have = HashSet<String>()
        for (t in shown) have.add(t.slug)
        var page = 1
        var busy = false
        var done = false
        var fails = 0
        class Chunk(val items: List<Title>, val next: Int, val end: Boolean)
        hs.onNearEnd = fun() {
            if (busy || done) return
            busy = true
            val startPage = page
            Net.async({
                val out = ArrayList<Title>()
                val got = HashSet<String>()
                var pg = startPage
                var tries = 0
                var end = false
                while (out.size < 8 && tries < 2) {
                    val b = more(pg)
                    pg++; tries++
                    if (b.isEmpty()) { end = true; break }
                    for (t in b) if (keep(t) && !have.contains(t.slug) && got.add(t.slug)) out.add(t)
                }
                Chunk(out, pg, end)
            }, { c ->
                busy = false
                fails = 0
                page = c.next
                if (c.end) done = true
                for (t in c.items) { have.add(t.slug); row.addView(cellFor(t, row.childCount)) }
                if (c.items.isEmpty() && !c.end) done = true
                // still too short to scroll? keep filling
                if (!done && c.items.isNotEmpty()) hs.post { hs.checkEnd(true) }
            }, {
                busy = false
                fails++
                if (fails >= 3) done = true
            })
        }
        hs.post { hs.checkEnd(true) }
    }

    private fun buildHero(): View {
        val box = SwipeFrame(this).apply {
            layoutParams = lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(300), 0, dp(6), 0, dp(6))
            // touch: swipe the hero left / right to change the slide (same as the website)
            onSwipe = { dir ->
                if (heroItems.size > 1) {
                    heroIdx = (heroIdx + dir + heroItems.size) % heroItems.size
                    paintHero()
                    h.removeCallbacks(heroTick); h.postDelayed(heroTick, 7000L)
                }
            }
        }
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { setColor(0xFF1B1C23.toInt()); cornerRadius = dp(14).toFloat() }
            clipToOutline = true
        }
        box.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xEE08090C.toInt(), 0x0008090C)).apply { cornerRadius = dp(14).toFloat() }
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // "#1 Trending" tag (top left), like the website
        val tag = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(12), dp(5), dp(12), dp(5))
            background = GradientDrawable().apply { setColor(ACCENT); cornerRadius = dp(8).toFloat() }
        }
        box.addView(tag, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply { setMargins(dp(24), dp(16), 0, 0) })
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(18))
        }
        val kick = text("", 13f, 0xFF4AA3FF.toInt(), true)
        val title = text("", 30f, Color.WHITE, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
        val meta = text("", 14f, 0xFFD6D6DE.toInt())
        val genres = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        info.addView(kick); info.addView(title); info.addView(meta)
        info.addView(genres, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(6), 0, 0))
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val watchBtn = pill("\u25B6  Watch now", accent = true) { heroItems.getOrNull(heroIdx)?.let { openDetail(it) } }
        val detBtn = pill("Details") { heroItems.getOrNull(heroIdx)?.let { openDetail(it) } }
        btns.addView(watchBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(10), 0))
        btns.addView(detBtn)
        heroBtns = Pair(watchBtn, detBtn)
        info.addView(btns, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(10), 0, 0))
        val seg = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        info.addView(seg, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(12), 0, 0))
        heroSeg = seg
        box.addView(info, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        heroImg = iv; heroTitle = title; heroMeta = meta; heroKick = kick; heroTag = tag; heroGenres = genres
        paintHero()
        return box
    }

    private fun paintHero() {
        val t = heroItems.getOrNull(heroIdx) ?: return
        val idx = heroIdx
        heroTag?.text = "#" + (idx + 1) + " Trending"
        heroSeg?.let { sg ->
            sg.removeAllViews()
            for (k in heroItems.indices) sg.addView(View(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dp(2).toFloat()
                    setColor(if (k == idx) ACCENT else if (k < idx) ACCENT2 else 0x55FFFFFF)
                }
            }, lp(if (k == idx) dp(30) else dp(10), dp(4), 0, 0, dp(6), 0))
        }
        heroKick?.text = "FREE  \u00B7  " + kindOf(t).uppercase()
        heroTitle?.text = t.name
        fun fill(rating: Double?, year: String, kind: String) {
            heroMeta?.text = listOfNotNull(rating?.let { "\u2605 " + String.format("%.1f", it) }, kind, year.takeIf { it.isNotEmpty() }).joinToString("  \u00B7  ")
        }
        fun chips(genre: List<String>) {
            val g = heroGenres ?: return
            g.removeAllViews()
            for (x in genre.take(6)) g.addView(TextView(this).apply {
                this.text = x; textSize = 12f; setTextColor(0xFFE6E6EC.toInt())
                setPadding(dp(10), dp(3), dp(10), dp(3))
                background = GradientDrawable().apply { setColor(0x33FFFFFF); cornerRadius = dp(10).toFloat() }
            }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(6), 0))
        }
        fill(t.rating, t.year, kindOf(t))
        chips(t.genre.split(",").map { it.trim() }.filter { it.isNotEmpty() })
        heroImg?.let { Net.loadImage(it, t.poster, 1280) }
        // the home list often has no rating / year: ask the detail page for them (the website does the same)
        val known = heroMeta2[t.slug]
        if (known != null) {
            fill(known.rating ?: t.rating, known.year.ifEmpty { t.year }, if (known.series) "Series" + (if (known.seasons.size > 1) " \u00B7 " + known.seasons.size + " seasons" else "") else kindOf(t))
            if (t.genre.isEmpty()) chips(known.genres)
        } else if ((t.rating == null || t.year.isEmpty() || t.genre.isEmpty()) && heroAsked.add(t.slug)) {
            Net.async({ Api.detail(t.slug) }, { d ->
                heroMeta2[t.slug] = d
                if (idx == heroIdx && heroItems.getOrNull(idx)?.slug == t.slug) {
                    fill(d.rating ?: t.rating, d.year.ifEmpty { t.year }, if (d.series) "Series" + (if (d.seasons.size > 1) " \u00B7 " + d.seasons.size + " seasons" else "") else kindOf(t))
                    if (t.genre.isEmpty()) chips(d.genres)
                }
            }, { })
        }
    }

    // ------------------------------------------------------------------ GRID (All > and search results)
    private inner class Grid(val perRow: Int = 6) {
        val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
        private var row: LinearLayout? = null
        private var n = 0
        fun clear() { col.removeAllViews(); row = null; n = 0 }
        fun add(items: List<Title>) {
            for (t in items) {
                var r = row
                if (n % perRow == 0 || r == null) {
                    val nr = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                    col.addView(nr)
                    row = nr
                    r = nr
                }
                r!!.addView(card(t, dp(124)) { openDetail(t) })
                n++
            }
        }
        val count get() = n
    }

    private fun header(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(40), dp(16), dp(40), dp(8))
        addView(text(title, 24f, Color.WHITE, true))
    }

    private fun openGrid(title: String, load: (Int) -> List<Title>) {
        val page = intArrayOf(1)
        val grid = Grid()
        val msg = text("Loading\u2026", 16f, MUTED)
        val moreBtn = pill("Load more") { }
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        shell.addView(header(title))
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(40), dp(4), dp(40), dp(40)) }
        inner.addView(grid.col)
        inner.addView(msg)
        inner.addView(moreBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(12), 0, 0))
        moreBtn.visibility = View.GONE
        val sv = scroll(inner)
        shell.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val busyG = booleanArrayOf(false)     // a page is loading
        val endG = booleanArrayOf(false)      // no more pages
        val failG = booleanArrayOf(false)     // last page failed: only the button retries
        fun go() {
            if (busyG[0] || endG[0]) return
            busyG[0] = true
            failG[0] = false
            val p = page[0]
            msg.visibility = View.VISIBLE; msg.text = "Loading\u2026"; moreBtn.visibility = View.GONE
            Net.async({ load(p) }, { items ->
                busyG[0] = false
                grid.add(items)
                if (items.isEmpty()) { endG[0] = true; msg.text = if (grid.count == 0) "Nothing found." else "That is all." }
                else { msg.visibility = View.GONE; moreBtn.visibility = View.VISIBLE; page[0] = p + 1 }
            }, { e -> busyG[0] = false; failG[0] = true; msg.text = Guard.message(e); moreBtn.visibility = View.VISIBLE })
        }
        moreBtn.setOnClickListener { go() }
        // the next page comes by itself when you get near the bottom (the button stays as a fallback)
        sv.viewTreeObserver.addOnScrollChangedListener {
            val c = sv.getChildAt(0)
            if (c != null && !busyG[0] && !endG[0] && !failG[0] && grid.count > 0 && c.height - (sv.scrollY + sv.height) < sv.height) go()
        }
        push(shell)
        go()
    }

    // ------------------------------------------------------------------ BROWSE (same filters as the website)
    private fun openBrowse(pre: String) {
        val st = hashMapOf("tab" to (if (pre == "tv") "5" else if (pre == "anime") "8" else "2"),
            "classify" to "All", "country" to "All", "genre" to "All", "year" to "All", "sort" to "ForYou")
        fun pairs(a: List<String>) = a.map { Pair(it, it) }
        val langs = listOf("All", "English dub", "French dub", "Hindi dub", "Bengali dub", "Urdu dub", "Punjabi dub", "Tamil dub", "Telugu dub", "Malayalam dub", "Kannada dub",
            "Arabic dub", "Arabic sub", "Tagalog dub", "Indonesian dub", "Russian dub", "Kurdish sub", "Spanish dub", "Spanish sub", "SpanishLatam dub")
            .map { Pair(if (it.startsWith("Arabic") || it.startsWith("Spanish")) it else it.removeSuffix(" dub"), it) }
        val groups = listOf(
            Triple("Type", "tab", listOf(Pair("Movies", "2"), Pair("Dramas & series", "5"), Pair("Anime", "8"))),
            Triple("Language", "classify", langs),
            Triple("Genre", "genre", pairs(listOf("All", "Action", "Adventure", "Animation", "Biography", "Comedy", "Crime", "Documentary", "Drama", "Family", "Fantasy", "Film-Noir", "Game-Show", "History", "Horror", "Music", "Musical", "Mystery", "News", "Reality-TV", "Romance", "Sci-Fi", "Short", "Sport", "Talk-Show", "Thriller", "War", "Western", "Other"))),
            Triple("Country", "country", pairs(listOf("All", "India", "United States", "United Kingdom", "Korea", "Japan", "China", "Bangladesh", "Egypt", "France", "Germany", "Indonesia", "Iraq", "Italy", "Ivory Coast", "Kenya", "Lebanon", "Mexico", "Morocco", "Nigeria", "Pakistan", "Philippines", "Russia", "Saudi Arabia", "South Africa", "Spain", "Syria", "Thailand", "Malaysia", "Turkey", "Other"))),
            Triple("Year", "year", pairs(listOf("All", "2026", "2025", "2024", "2023", "2022", "2021", "2020", "2010s", "2000s", "1990s", "1980s", "Other"))),
            Triple("Sort", "sort", listOf(Pair("For you", "ForYou"), Pair("Hottest", "Hottest"), Pair("Latest", "Latest"), Pair("Rating", "Rating"), Pair("Year", "Year")))
        )
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        shell.addView(header("Browse categories"))
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(40), dp(4), dp(40), dp(40)) }
        for ((lbl, key, opts) in groups) {
            inner.addView(text(lbl.uppercase(), 13f, MUTED, true).apply { setPadding(0, dp(12), 0, dp(4)) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
            val chips = ArrayList<Pair<String, TextView>>()
            for ((l, v) in opts) {
                val chip = pill(l, selected = st[key] == v) { }
                chip.setOnClickListener {
                    st[key] = v
                    for ((cv, tv) in chips) tv.background = stateBg(if (cv == v) ACCENT else PANEL, dp(22))
                }
                chips.add(Pair(v, chip))
                row.addView(chip, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(8), 0))
            }
            inner.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        }
        inner.addView(pill("Show results", accent = true) {
            val tl = if (st["tab"] == "5") "Dramas & series" else if (st["tab"] == "8") "Anime" else "Movies"
            val title = listOf(tl, (st["classify"] ?: "").takeIf { it != "All" }?.removeSuffix(" dub") ?: "", (st["genre"] ?: "").takeIf { it != "All" } ?: "",
                (st["country"] ?: "").takeIf { it != "All" } ?: "", (st["year"] ?: "").takeIf { it != "All" } ?: "").filter { it.isNotEmpty() }.joinToString(" \u00B7 ")
            val type = if (st["tab"] == "5") "tv" else if (st["tab"] == "8") "anime" else "movie"
            val g = st["genre"] ?: "All"; val c = st["country"] ?: "All"; val y = st["year"] ?: "All"; val l = st["classify"] ?: "All"; val so = st["sort"] ?: "ForYou"
            openGrid(title) { p -> Api.browse(type, g, c, y, l, so, p) }
        }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(22), 0, 0))
        shell.addView(scroll(inner), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        push(shell)
    }

    // ------------------------------------------------------------------ MY LIST
    private fun openMyList() {
        val m = me
        if (Net.token == null) { toast("Sign in to see your My List."); openAccount(); return }
        if (m == null) { toast("Loading your account\u2026 try again in a moment."); loadMe(); return }
        openGrid("My List") { p -> if (p == 1) m.favs else emptyList() }
    }

    private fun recents(): List<String> = (prefs.getString("recent_q", "") ?: "").split("\n").filter { it.isNotBlank() }
    private fun addRecent(q: String) {
        val l = (listOf(q) + recents().filter { !it.equals(q, true) }).take(8)
        prefs.edit().putString("recent_q", l.joinToString("\n")).apply()
    }

    // ------------------------------------------------------------------ SEARCH
    private fun openSearch() {
        val grid = Grid(6)
        val doSearchRef = arrayOfNulls<() -> Unit>(1)
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = header("Search")
        val input = EditText(this).apply {
            hint = "Type a movie or series name"
            setHintTextColor(MUTED); setTextColor(Color.WHITE); textSize = 20f
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setSingleLine(true)
            background = stateBg(PANEL, dp(10))
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        top.addView(input, lp(dp(420), ViewGroup.LayoutParams.WRAP_CONTENT, dp(20), 0, 0, 0))
        shell.addView(top)
        val msg = text("Type a name and press the keyboard's search key.", 16f, MUTED).apply { setPadding(dp(40), dp(8), dp(40), dp(8)) }
        shell.addView(msg)
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(40), dp(4), dp(40), dp(40)) }
        val sugg = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        inner.addView(sugg)
        inner.addView(grid.col)
        shell.addView(scroll(inner), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val last = arrayOf("")
        fun chipRow(label: String, names: List<String>) {
            if (names.isEmpty()) return
            sugg.addView(text(label.uppercase(), 13f, MUTED, true).apply { setPadding(0, dp(10), 0, dp(4)) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
            for (nm in names) row.addView(pill(nm) { input.setText(nm); input.setSelection(nm.length); input.post { input.requestFocus() }; doSearchRef[0]?.invoke() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(8), 0))
            sugg.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        }
        chipRow("Recent searches", recents())
        chipRow("Trending now", (sections.firstOrNull { it.isBanner }?.items ?: sections.firstOrNull()?.items ?: emptyList()).take(8).map { it.name })
        fun doSearch() {
            val q = input.text.toString().trim()
            if (q.length < 2 || q == last[0]) return
            last[0] = q
            sugg.visibility = View.GONE
            addRecent(q)
            msg.text = "Searching\u2026"
            Net.async({ Api.search(q) }, { items ->
                if (q == last[0]) {
                    grid.clear(); grid.add(items)
                    msg.text = if (items.isEmpty()) "Nothing found for \"$q\"." else ""
                }
            }, { e -> if (q == last[0]) { msg.text = Guard.message(e); last[0] = "" } })
        }
        doSearchRef[0] = { doSearch() }
        input.setOnEditorActionListener { _, _, _ -> doSearch(); true }
        input.setOnKeyListener { _, code, ev ->
            if (ev.action == KeyEvent.ACTION_UP && code == KeyEvent.KEYCODE_ENTER) { doSearch(); true } else false
        }
        push(shell)
        input.post { input.requestFocus() }
    }

    // ------------------------------------------------------------------ DETAIL
    /** All shorts of the home feed (same rules as the website's shortsList), the tapped one first in the feed. */
    private fun openReels(t: Title?) {
        val seen = HashSet<String>()
        val list = ArrayList<Title>()
        val more = ArrayList<Pair<String, String>>()
        for (s in sections) {
            if (s.isBanner) continue
            val shortRow = RE_SHORT.containsMatchIn(s.title)
            var any = false
            for (i in s.items) {
                if (i.slug.isNotEmpty() && (i.type == 7 || shortRow) && seen.add(i.slug)) { list.add(i); any = true }
            }
            val mo = s.moreId
            if (mo != null && (shortRow || any)) more.add(Pair(mo, s.title))
        }
        var start = if (t == null) 0 else list.indexOfFirst { it.slug == t.slug }
        if (t != null && start < 0) { list.add(0, t); start = 0 }
        if (list.isEmpty()) { toast("No shorts on the home feed right now"); return }
        ReelsActivity.open(this, list, start.coerceAtLeast(0), more, HashSet(favIds))
    }

    private fun openDetail(t: Title) {
        if (t.type == 7) { openReels(t); return }
        val shell = FrameLayout(this)
        val msg = text("Loading\u2026", 20f, MUTED).apply { gravity = Gravity.CENTER }
        shell.addView(msg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        push(shell)
        Net.async({ Api.detail(t.slug) }, { d ->
            shell.removeView(msg)
            shell.addView(buildDetail(d, t), 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            shell.post { findPlay(shell)?.requestFocus() }
        }, { e ->
            msg.text = Guard.message(e) + "\nPress Back."
        })
    }

    private var playBtnTag = "play"
    private fun findPlay(v: View): View? = v.findViewWithTag(playBtnTag)

    private fun buildDetail(d: Detail, from: Title): View {
        val dubIdx = intArrayOf(0)
        if (d.dubs.isNotEmpty()) dubIdx[0] = d.dubs.indexOfFirst { it.id == d.id }.coerceAtLeast(0)
        val curSe = intArrayOf(d.seasons.firstOrNull()?.se ?: 0)
        val self = Title(d.slug, d.id, d.title, d.poster, d.rating, d.year, null, if (d.series) 2 else 1, d.genres.joinToString(", "))

        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(40), dp(64), dp(40), dp(30)) }
        val poster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { setColor(0xFF1B1B24.toInt()); cornerRadius = dp(10).toFloat() }
            clipToOutline = true
        }
        root.addView(poster, lp(dp(200), dp(300), 0, 0, dp(30), 0))
        Net.loadImage(poster, d.poster.ifEmpty { from.poster }, 400)

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        right.addView(text(d.title, 30f, Color.WHITE, true))
        val meta = listOfNotNull(d.rating?.let { "\u2605 " + String.format("%.1f", it) }, if (d.series) "Series" else "Movie", d.year.takeIf { it.isNotEmpty() }, d.genres.take(3).joinToString(", ").takeIf { it.isNotEmpty() })
        right.addView(text(meta.joinToString("  \u00B7  "), 15f, MUTED).apply { setPadding(0, dp(4), 0, dp(8)) })
        if (d.genres.isNotEmpty()) {
            val gr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, dp(8)) }
            for (x in d.genres.take(6)) gr.addView(TextView(this).apply {
                this.text = x; textSize = 12f; setTextColor(0xFFE6E6EC.toInt())
                setPadding(dp(10), dp(3), dp(10), dp(3))
                background = GradientDrawable().apply { setColor(0x33FFFFFF); cornerRadius = dp(10).toFloat() }
            }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(6), 0))
            right.addView(gr)
        }
        right.addView(text(d.desc, 15f, 0xFFD0D0D8.toInt()).apply { maxLines = 4; ellipsize = TextUtils.TruncateAt.END })

        // continue watching info for this title
        val resume = me?.progress?.firstOrNull { it.slug == d.slug }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, dp(10)) }
        fun dub(): Dub? = d.dubs.getOrNull(dubIdx[0])
        fun playNow(se: Int, ep: Int) {
            play(d, dubIdx[0], se, ep)
        }
        val firstSe = d.seasons.firstOrNull()?.se ?: 0
        val playLabel = if (resume != null && d.series) "\u25B6 Resume S${resume.se} E${resume.ep}" else "\u25B6 Play"
        val playBtn = pill(playLabel, accent = true) {
            if (resume != null && d.series) playNow(resume.se, resume.ep) else if (d.series) playNow(firstSe, 1) else playNow(0, 0)
        }
        playBtn.tag = playBtnTag
        actions.addView(playBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(10), 0))
        val favBtn = pill("") { }
        fun paintFav() { favBtn.text = if (favIds.contains(d.id)) "\u2713 In My List" else "+ My List" }
        paintFav()
        favBtn.setOnClickListener {
            if (Net.token == null) { openAccount(); return@setOnClickListener }
            val on = !favIds.contains(d.id)
            if (on) favIds.add(d.id) else favIds.remove(d.id)
            paintFav()
            Net.async({ Api.setFav(self, on) }, { loadMe() }, { e -> toast(Guard.message(e)) })
        }
        actions.addView(favBtn)
        right.addView(actions)

        // languages (dubs)
        if (d.dubs.size > 1) {
            right.addView(text("Language", 14f, MUTED))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(8)) }
            fun paintDubs() {
                row.removeAllViews()
                d.dubs.forEachIndexed { i, x ->
                    row.addView(pill(x.lang, selected = i == dubIdx[0]) { dubIdx[0] = i; paintDubs(); row.getChildAt(i)?.requestFocus() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(8), 0))
                }
            }
            paintDubs()
            right.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        }

        // seasons + episodes
        if (d.series) {
            val seasonRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(6)) }
            val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            fun paintEps() {
                grid.removeAllViews()
                val n = d.seasons.firstOrNull { it.se == curSe[0] }?.n ?: 0
                var r: LinearLayout? = null
                for (k in 1..n) {
                    if ((k - 1) % 8 == 0) { r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; grid.addView(r) }
                    val seen = resume != null && resume.se == curSe[0] && resume.ep == k
                    r!!.addView(pill("E$k", selected = seen) { playNow(curSe[0], k) }, lp(dp(78), ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(8), dp(8)))
                }
            }
            fun paintSeasons() {
                seasonRow.removeAllViews()
                if (d.seasons.size > 1) d.seasons.forEach { s ->
                    seasonRow.addView(pill("Season ${s.se}", selected = s.se == curSe[0]) { curSe[0] = s.se; paintSeasons(); paintEps() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(8), 0))
                }
            }
            paintSeasons(); paintEps()
            if (d.seasons.size > 1) right.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(seasonRow) })
            right.addView(text("Episodes", 14f, MUTED).apply { setPadding(0, dp(6), 0, dp(4)) })
            right.addView(grid)
        }
        root.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return scroll(root)
    }

    // ------------------------------------------------------------------ PLAY (links + guard rules, then PlayerActivity)
    private fun play(d: Detail, dubIdx: Int, se: Int, ep: Int) {
        if (busy) return
        busy = true
        toast("Getting the video\u2026")
        val dub = d.dubs.getOrNull(dubIdx)
        val id = dub?.id ?: d.id
        val slug = dub?.slug ?: d.slug
        Net.async({ Guard.watch(id, slug, se, ep) }, { st ->
            busy = false
            if (st.sources.isEmpty()) { toast(st.note.ifEmpty { "No video found for this title." }); return@async }
            // resume: the account's Continue watching position for this exact title / episode (guests: the player remembers it on this TV)
            val saved = me?.progress?.firstOrNull { it.slug == d.slug && it.se == se && it.ep == ep }?.pos ?: 0.0
            PlayerActivity.start(this, d, dubIdx, se, ep, st, saved)
        }, { e ->
            busy = false
            when {
                Guard.isCaptcha(e) -> TvPair.show(this) { ok -> if (ok) play(d, dubIdx, se, ep) }
                Guard.isSignin(e) -> { toast("Free videos finished. Please sign in."); openAccount() }
                else -> toast(Guard.message(e))
            }
        })
    }

    // ------------------------------------------------------------------ ACCOUNT
    private fun loadMe() {
        Net.async({ Api.me() }, { m ->
            val oldSig = me?.progress?.joinToString(",") { it.slug + ":" + it.se + ":" + it.ep + ":" + it.pct }
            val first = me == null
            me = m
            favIds.clear(); m.favs.forEach { favIds.add(it.id) }
            accountBtn?.text = "Account"
            // do not rebuild the whole home (and its scroll position) when nothing in Continue watching changed
            if (stack.size == 1 && (first || oldSig != m.progress.joinToString(",") { it.slug + ":" + it.se + ":" + it.ep + ":" + it.pct })) renderHome()
        }, { e ->
            if (e is ApiException && e.status == 401) { setToken(null); accountBtn?.text = "Sign in" }
        })
    }

    private fun setToken(t: String?) {
        Net.token = t
        prefs.edit().apply { if (t == null) remove("jf_token") else putString("jf_token", t) }.apply()
        if (t == null) { me = null; favIds.clear() }
    }

    private fun openAccount() {
        val m = me
        if (Net.token != null) {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(m?.user ?: "Account")
                .setMessage("You are signed in.")
                .setPositiveButton("Close", null)
                .setNegativeButton("Sign out") { _, _ ->
                    Net.async({ Api.logout() }, { })
                    setToken(null); accountBtn?.text = "Sign in"
                    if (stack.size == 1) renderHome()
                }.show()
        } else signInDialog { }
    }

    private fun signInDialog(done: () -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(12), dp(24), dp(4)) }
        val u = EditText(this).apply { hint = "Username"; setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS }
        val p = EditText(this).apply { hint = "Password"; setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val note = text("New here? Create the account on your phone on the website, then sign in here.", 13f, MUTED)
        box.addView(u); box.addView(p); box.addView(note)
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Sign in")
            .setView(box)
            .setPositiveButton("Sign in") { _, _ -> doLogin(u.text.toString().trim(), p.text.toString(), done) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun doLogin(user: String, pass: String, done: () -> Unit, retried: Boolean = false) {
        if (user.isEmpty() || pass.isEmpty()) { toast("Enter username and password."); return }
        Net.async({ Api.login(user, pass) }, { tok ->
            if (tok.isEmpty()) { toast("Sign in failed."); return@async }
            setToken(tok); accountBtn?.text = "Account"; loadMe(); toast("Signed in"); done()
        }, { e ->
            if (Guard.isCaptcha(e) && !retried) TvPair.show(this) { ok -> if (ok) doLogin(user, pass, done, true) }
            else toast(Guard.message(e))
        })
    }
}


/** Horizontal scroll that tells the row when the user is within about 5 cards of its end. */
private class EndlessScroll(ctx: android.content.Context) : HorizontalScrollView(ctx) {
    var onNearEnd: (() -> Unit)? = null

    /** [initial] = only react when the row does not even fill the screen; otherwise react when about 3-4 cards are left. */
    fun checkEnd(initial: Boolean = false) {
        val c = getChildAt(0) ?: return
        if (width <= 0) return
        val left = c.width - (scrollX + width)
        if (left < (if (initial) 0 else (width * 0.6f).toInt())) onNearEnd?.invoke()
    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        checkEnd()
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (changed) post { checkEnd(true) }
    }
}


/** Frame that notices a horizontal swipe (even when it starts on a button) and reports -1 (swipe right = previous) or +1 (swipe left = next). */
private class SwipeFrame(ctx: android.content.Context) : FrameLayout(ctx) {
    var onSwipe: ((Int) -> Unit)? = null
    private var dx0 = 0f
    private var dy0 = 0f
    private var swiping = false
    private val slop = android.view.ViewConfiguration.get(ctx).scaledTouchSlop

    override fun onInterceptTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { dx0 = e.x; dy0 = e.y; swiping = false }
            android.view.MotionEvent.ACTION_MOVE -> {
                val dx = e.x - dx0
                val dy = e.y - dy0
                if (!swiping && Math.abs(dx) > slop * 2 && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                    swiping = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
            }
        }
        return false
    }

    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_UP -> {
                if (swiping) {
                    val dx = e.x - dx0
                    if (Math.abs(dx) > width / 8f) onSwipe?.invoke(if (dx < 0) 1 else -1)
                    swiping = false
                }
            }
            android.view.MotionEvent.ACTION_CANCEL -> swiping = false
        }
        return true
    }
}
