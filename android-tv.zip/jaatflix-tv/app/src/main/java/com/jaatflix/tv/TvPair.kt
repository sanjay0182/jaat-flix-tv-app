package com.jaatflix.tv

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import org.json.JSONObject

/**
 * The site's "TV pass". When the site asks for a captcha, the TV shows a QR code; a phone opens it,
 * plays the little game, and this TV (asking every 2 s) gets a pass that is good for hours.
 * Same flow as the website on a TV: /api/tv/new -> /api/tv/poll.
 * [onDone] gets true when a pass arrived, false when the person pressed Back.
 */
object TvPair {
    fun show(activity: Activity, onDone: (Boolean) -> Unit) {
        Session(activity, onDone).start()
    }

    private class Session(val act: Activity, val onDone: (Boolean) -> Unit) {
        private val h = Handler(Looper.getMainLooper())
        private var dead = false
        private var ok = false
        private var pid = ""
        private var expAt = 0L
        private lateinit var qr: ImageView
        private lateinit var codeText: TextView
        private lateinit var note: TextView
        private lateinit var dialog: AlertDialog

        private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()

        private fun gone() = dead || act.isFinishing

        private fun text(t: String, size: Float, bold: Boolean): TextView = TextView(act).apply {
            text = t
            textSize = size
            setTextColor(Color.WHITE)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(4))
        }

        fun start() {
            if (act.isFinishing) { onDone(false); return }
            val root = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(28), dp(20), dp(28), dp(8))
            }
            root.addView(text("One quick game on your phone", 24f, true))
            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(12), 0, dp(8))
            }
            qr = ImageView(act).apply {
                setBackgroundColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(dp(250), dp(250))
            }
            val side = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(28), 0, 0, 0)
            }
            side.addView(text("1. Point your phone camera at the QR", 18f, false))
            side.addView(text("2. Win the little game", 18f, false))
            side.addView(text("3. This TV starts by itself", 18f, false))
            codeText = text("", 34f, true)
            side.addView(codeText)
            row.addView(qr)
            row.addView(side)
            root.addView(row)
            note = text("Making the QR code\u2026", 15f, false)
            root.addView(note)

            dialog = AlertDialog.Builder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setView(root)
                .setNegativeButton("Back", null)
                .setOnDismissListener {
                    dead = true
                    h.removeCallbacksAndMessages(null)
                    onDone(ok)
                }
                .create()
            dialog.show()
            fresh()
        }

        private fun fresh() {
            if (gone()) return
            Net.async({ Net.request("/api/tv/new", JSONObject()) }, { j ->
                if (gone()) return@async
                val p = j.optString("pid")
                val code = j.optString("code")
                if (p.isEmpty() || code.isEmpty()) {
                    note.text = "Network problem, trying again\u2026"
                    h.postDelayed({ fresh() }, 4000L)
                    return@async
                }
                pid = p
                expAt = System.currentTimeMillis() + j.optLong("ttl", 120L) * 1000L
                qr.setImageBitmap(makeQr(Net.abs("/tv?c=$code"), dp(250)))
                codeText.text = code
                note.text = "No camera? On your phone open " + Net.siteHost + "/tv and type the code."
                h.postDelayed({ poll() }, 2000L)
            }, { e ->
                if (gone()) return@async
                val st = (e as? ApiException)?.status ?: 0
                note.text = if (st == 429) "Wait a moment, a new QR is coming\u2026" else "Network problem, trying again\u2026"
                h.postDelayed({ fresh() }, if (st == 429) 8000L else 4000L)
            })
        }

        private fun poll() {
            if (gone()) return
            Net.async({ Net.request("/api/tv/poll", JSONObject().put("pid", pid)) }, { r ->
                if (gone()) return@async
                val state = r.optString("state")
                if (state == "ok") {
                    Net.setTvPass(r.optString("token"), r.optLong("ttl", 3600L))
                    ok = true
                    dialog.dismiss()
                    return@async
                }
                if (state == "gone" || System.currentTimeMillis() > expAt) {
                    fresh()
                    return@async
                }
                h.postDelayed({ poll() }, 2000L)
            }, { e ->
                if (gone()) return@async
                val st = (e as? ApiException)?.status ?: 0
                h.postDelayed({ poll() }, if (st == 429) 6000L else 2000L)
            })
        }

        private fun makeQr(content: String, size: Int): Bitmap? = try {
            val hints = hashMapOf<EncodeHintType, Any>(EncodeHintType.MARGIN to 2)
            val m = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
            val pix = IntArray(size * size)
            for (y in 0 until size) for (x in 0 until size) pix[y * size + x] = if (m.get(x, y)) Color.BLACK else Color.WHITE
            Bitmap.createBitmap(pix, size, size, Bitmap.Config.ARGB_8888)
        } catch (e: Throwable) {
            null
        }
    }
}
