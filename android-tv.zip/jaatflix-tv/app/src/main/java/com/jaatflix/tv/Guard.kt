package com.jaatflix.tv

import org.json.JSONObject

/** Helpers for the JaatFlix guard rules (what /api/stream can answer besides the video links). */
object Guard {
    /** 403 + captcha: the site wants a game played (on a TV: the QR code, see [TvPair]). */
    fun isCaptcha(e: Exception) = e is ApiException && e.status == 403 && e.json.optBoolean("captcha")

    /** 403 + login: a guest has used up the free videos, sign-in is needed. */
    fun isSignin(e: Exception) = e is ApiException && e.json.optBoolean("login")

    /** 403 + open: the site wants the title page opened first. */
    fun isOpen(e: Exception) = e is ApiException && e.status == 403 && e.json.optBoolean("open")

    /** 429 + busy: too many videos at once from this network. */
    fun isBusy(e: Exception) = e is ApiException && (e.status == 429 || e.json.optBoolean("busy"))

    /**
     * Blocking (call from a background thread). The video links of one episode / movie.
     * The app finds the CDN links itself ([Mb]); the site says yes / no (captcha, sign-in, limits) and signs the relay links ([Relay]).
     * If the site first wants the title page "opened", that is done quietly and the check is repeated.
     */
    fun watch(id: String, slug: String, se: Int, ep: Int): Streams {
        val r = Mb.resolveCached(id, slug, se, ep)
        var last: Exception = RuntimeException("watch failed")
        for (i in 0..2) {
            try {
                val relay = Api.gate(id, slug, se, ep, r)
                return Api.streamsFrom(r, relay)
            } catch (e: Exception) {
                last = e
                if (!isOpen(e)) break
                try { Net.request("/detail/" + java.net.URLEncoder.encode(slug, "UTF-8")) } catch (x: Exception) { }
            }
        }
        throw last
    }

    /** Short text for an error screen. */
    fun message(e: Exception): String = when {
        isCaptcha(e) -> "A quick check is needed."
        isSignin(e) -> "Free videos finished. Please sign in."
        isBusy(e) -> "Too many videos at once. Try again in a minute."
        e is ApiException && e.status in 500..599 && (e.message ?: "").startsWith("token").not() && (e.message ?: "").contains("MovieBox").not() -> "The server is waking up. Try again in a few seconds."
        e is ApiException -> e.message ?: "Error ${e.status}"
        else -> "Error: " + e.javaClass.simpleName + ": " + (e.message ?: "no message")
    }
}
