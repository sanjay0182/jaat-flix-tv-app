package com.jaatflix.tv

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** One card on the screen (movie / series / short). Comes from the JaatFlix backend (/home, /search, /more). */
class Title(
    val slug: String,
    val id: String,
    val name: String,
    val poster: String,
    val rating: Double?,
    val year: String,
    val badge: String?,
    val type: Int,          // MovieBox subjectType: 1 movie, 2 series, 7 short
    val genre: String,
    val pct: Int = 0,       // continue watching: how much is watched (0..100)
    val se: Int = 0,        // continue watching: season / episode / second to resume from
    val ep: Int = 0,
    val pos: Double = 0.0
)

class HomeData(val sections: List<Section>, val tabs: List<Pair<String, String>>)

/** The signed-in person: name, continue-watching list and My List. */
class Me(val user: String, val progress: List<Title>, val favs: List<Title>)

class Section(val title: String, val items: List<Title>, val moreId: String?, val isBanner: Boolean)

class Dub(val id: String, val slug: String, val lang: String)
class Season(val se: Int, val n: Int)

class Detail(
    val slug: String,
    val id: String,
    val title: String,
    val poster: String,
    val desc: String,
    val rating: Double?,
    val year: String,
    val genres: List<String>,
    val series: Boolean,
    val seasons: List<Season>,
    val dubs: List<Dub>
)

/** A playable link. [url] = relay link while the relay is trusted, [fb] = the direct CDN link of the same video (used when the relay link fails). Empty [fb] = [url] is already direct. */
class Source(val label: String, val res: Int, val url: String, val kind: String, val fb: String, val backup: Boolean)

class Caption(val lang: String, val url: String)

/** [ref] = the Referer the video CDN wants (the player adds it itself for direct links; relay links carry it inside). */
class Streams(val sources: List<Source>, val capId: String, val capFmt: String, val capIds: String, val note: String, val ref: String = "https://netfilm.world/")

/** Everything the app asks the JaatFlix backend. All calls are BLOCKING: use Net.async(...) from the UI. */
object Api {
    private val BRACKETS = Regex("""\s*[\[(][^\])]*[\])]""")

    /** "Title [Hindi]" -> "Title" (the language tag is shown as a badge instead). */
    fun cleanName(n: String): String = n.replace(BRACKETS, "").trim().ifEmpty { n }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun parseTitle(o: JSONObject): Title? {
        val slug = o.optString("slug")
        if (slug.isEmpty() || slug == "null") return null
        val raw = o.optString("name", slug)
        val r = o.optString("rating", "").toDoubleOrNull()
        val badge = o.optString("badge", "").takeIf { it.isNotEmpty() && it != "null" }
        return Title(
            slug = slug,
            id = o.optString("subject_id"),
            name = cleanName(if (raw == "null") slug else raw),
            poster = o.optString("poster_url", "").let { if (it == "null") "" else it },
            rating = if (r != null && r > 0) r else null,
            year = o.optString("year", "").let { if (it == "null") "" else it },
            badge = badge,
            type = o.optInt("type", 0),
            genre = o.optString("genre", "").let { if (it == "null") "" else it }
        )
    }

    private fun parseTitles(a: JSONArray?): List<Title> {
        val out = ArrayList<Title>()
        if (a == null) return out
        for (i in 0 until a.length()) a.optJSONObject(i)?.let { o -> parseTitle(o)?.let(out::add) }
        return out
    }

    /** Home rows (Banner first). [tab] = a top tab id from MovieBox, empty = Trending/home. */
    fun home(tab: String = "", page: Int = 0): List<Section> = homeFull(tab, page).sections

    fun homeFull(tab: String = "", page: Int = 0): HomeData {
        val j = Net.requestCached("/home?tab=" + enc(tab) + "&page=$page", 10 * 60_000L)
        val tabs = ArrayList<Pair<String, String>>()
        val ta = j.optJSONArray("tabs")
        if (ta != null) for (i in 0 until ta.length()) {
            val o = ta.optJSONObject(i) ?: continue
            val n = o.optString("name", ""); val id = o.optString("id", "")
            if (n.isNotEmpty() && n != "null") tabs.add(Pair(n, if (id == "null") "" else id))
        }
        val arr = j.optJSONArray("sections") ?: return HomeData(emptyList(), tabs)
        val out = ArrayList<Section>()
        for (i in 0 until arr.length()) {
            val s = arr.optJSONObject(i) ?: continue
            val items = parseTitles(s.optJSONArray("items"))
            if (items.isEmpty()) continue
            val name = s.optString("section", "")
            val banner = name == "Banner"
            val more = s.optJSONObject("more")?.optString("genreTopId")?.takeIf { it.isNotEmpty() }
                ?: s.optJSONObject("more")?.optString("id")?.takeIf { it.isNotEmpty() }
            out.add(Section(if (banner) "Trending now" else name, items, more, banner))
        }
        return HomeData(out, tabs)
    }

    /** Sign in. Returns the token. Throws ApiException (captcha flag = a TV pass is needed first). */
    fun login(user: String, pass: String): String {
        val j = Net.request("/api/login", JSONObject().put("username", user).put("password", pass))
        return j.optString("token")
    }

    fun logout() { try { Net.request("/api/logout", JSONObject()) } catch (e: Exception) { } }

    fun me(): Me {
        val j = Net.request("/api/me")
        val u = j.optJSONObject("user")
        val name = u?.optString("username")?.takeIf { it.isNotEmpty() && it != "null" } ?: u?.optString("name")?.takeIf { it.isNotEmpty() && it != "null" } ?: "Account"
        val prog = ArrayList<Title>()
        val pa = j.optJSONArray("progress")
        if (pa != null) for (i in 0 until pa.length()) {
            val o = pa.optJSONObject(i) ?: continue
            val slug = o.optString("slug"); if (slug.isEmpty()) continue
            val dur = o.optDouble("dur", 0.0); val pos = o.optDouble("pos", 0.0)
            val pct = if (dur > 0) ((pos / dur) * 100).toInt().coerceIn(0, 100) else 0
            if (pct >= 95) continue
            prog.add(Title(slug, o.optString("sid"), cleanName(o.optString("name", slug)), o.optString("poster_url", ""), null, "", null, 0, "", pct, o.optInt("season"), o.optInt("episode"), pos))
        }
        val favs = ArrayList<Title>()
        val fa = j.optJSONArray("favs")
        if (fa != null) for (i in 0 until fa.length()) {
            val o = fa.optJSONObject(i) ?: continue
            val slug = o.optString("slug"); if (slug.isEmpty()) continue
            favs.add(Title(slug, o.optString("subject_id"), cleanName(o.optString("name", slug)), o.optString("poster_url", ""), null, "", null, 0, ""))
        }
        return Me(name, prog, favs)
    }

    fun setFav(t: Title, on: Boolean) {
        val item = JSONObject().put("subject_id", t.id).put("slug", t.slug).put("name", t.name).put("poster_url", t.poster)
        Net.request("/api/fav", JSONObject().put("sid", t.id).put("on", on).put("item", item))
    }

    fun more(id: String, title: String, page: Int): List<Title> {
        val j = Net.requestCached("/more?id=" + enc(id) + "&title=" + enc(title) + "&page=$page&per=24", 10 * 60_000L)
        return parseTitles(j.optJSONArray("items"))
    }

    /** Website's Browse page: /browse?type=movie|tv|anime + genre / country / year / language / sort. */
    fun browse(type: String, genre: String, country: String, year: String, language: String, sort: String, page: Int): List<Title> {
        val j = Net.requestCached("/browse?type=" + enc(type) + "&genre=" + enc(genre) + "&country=" + enc(country) + "&year=" + enc(year) +
            "&language=" + enc(language) + "&sort=" + enc(sort) + "&page=$page", 10 * 60_000L)
        return parseTitles(j.optJSONArray("items"))
    }

    fun search(q: String, page: Int = 1): List<Title> {
        val j = Net.requestCached("/search?q=" + enc(q) + "&page=$page", 5 * 60_000L)
        return parseTitles(j.optJSONArray("items"))
    }

    /** Title page data. This call also tells the site's guard "the page was opened" (needed before a stream). */
    fun detail(slug: String): Detail {
        val j = Net.request("/detail/" + enc(slug))
        val data = j.optJSONObject("data") ?: JSONObject()
        val s = data.optJSONObject("subject") ?: JSONObject()
        val r = data.optJSONObject("resource") ?: JSONObject()
        val type = s.optInt("subjectType", 0)
        val short = type == 7
        val seasons = ArrayList<Season>()
        val sa = r.optJSONArray("seasons")
        if (sa != null) for (i in 0 until sa.length()) {
            val o = sa.optJSONObject(i) ?: continue
            val se = o.optInt("se", 0)
            if (if (short) se < 0 else se <= 0) continue
            var n = o.optInt("maxEp", 0)
            if (n == 0) n = o.optInt("allEp", 0)
            seasons.add(Season(se, if (n > 0) n else 12))
        }
        val series = type == 2 || short || seasons.isNotEmpty()
        if (series && seasons.isEmpty()) seasons.add(Season(1, 12))

        // dubs (languages): the API often lists only the OTHER dubs, so this title itself is added too
        val dubs = ArrayList<Dub>()
        val seen = HashSet<String>()
        fun addDubs(a: JSONArray?) {
            if (a == null) return
            for (i in 0 until a.length()) {
                val x = a.optJSONObject(i) ?: continue
                val id = x.optString("subjectId")
                val sl = x.optString("detailPath")
                if (id.isEmpty() || sl.isEmpty() || !seen.add(id)) continue
                val lang = x.optString("lanName").ifEmpty { x.optString("lanCode").ifEmpty { x.optString("name").ifEmpty { "Dub" } } }
                dubs.add(Dub(id, sl, lang))
            }
        }
        addDubs(data.optJSONArray("dubs")); addDubs(s.optJSONArray("dubs")); addDubs(r.optJSONArray("dubs"))
        val myId = s.optString("subjectId")
        if (dubs.isNotEmpty() && myId.isNotEmpty() && !seen.contains(myId)) {
            val m = Regex("""\[([^\]]+)\]""").find(s.optString("title"))
            dubs.add(0, Dub(myId, s.optString("detailPath", slug), m?.groupValues?.get(1) ?: "Original"))
        }
        val rating = s.optString("imdbRatingValue", "").toDoubleOrNull()
        return Detail(
            slug = slug,
            id = myId,
            title = cleanName(s.optString("title", slug)),
            poster = s.optJSONObject("cover")?.optString("url", "") ?: "",
            desc = s.optString("description", ""),
            rating = if (rating != null && rating > 0) rating else null,
            year = s.optString("releaseDate", "").take(4),
            genres = s.optString("genre", "").split(",").map { it.trim() }.filter { it.isNotEmpty() },
            series = series,
            seasons = seasons,
            dubs = dubs
        )
    }

    /**
     * The site's guard (captcha / sign-in / guest limit / "open the page first") still decides if this video may be watched:
     * the links found by [Mb] are sent to /api/sign. The answer's status is the guard decision; the links it signs (carried by the
     * relay) are returned as "label|kind" -> relay link, so [streamsFrom] can put them first (see [Relay]).
     * Blocking. Throws ApiException with the guard flags (see [Guard]).
     */
    fun gate(id: String, slug: String, se: Int, ep: Int, r: Mb.Resolved): Map<String, String> {
        val items = JSONArray()
        for (x in r.items.take(40)) items.put(JSONObject().put("u", x.url).put("res", x.res).apply { if (x.auto) put("auto", 1) })
        val cap = JSONObject().put("id", r.capId).put("fmt", r.capFmt).put("ids", JSONArray(r.capIds))
        val out = LinkedHashMap<String, String>()
        try {
            val j = Net.request("/api/sign", JSONObject().put("id", id).put("detail_path", slug).put("se", se).put("ep", ep).put("hj", 0).put("items", items).put("cap", cap))
            val a = j.optJSONArray("sources")
            if (a != null) for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val u = o.optString("url")
                if (u.isEmpty() || u == "null") continue
                out.putIfAbsent(o.optString("label") + "|" + o.optString("kind"), u)   // first one wins, like the direct list
            }
        } catch (e: ApiException) {
            if (e.status == 404 && !e.json.optBoolean("captcha") && !e.json.optBoolean("open")) return out   // site has client-resolve switched off: no gate to pass, direct only
            throw e
        }
        return out
    }

    /** Best first: Auto (HLS), then 1080p, 720p ... With [relay] links (and while [Relay.wanted]) the relay link is [Source.url] and the direct CDN link is [Source.fb]. */
    fun streamsFrom(r: Mb.Resolved, relay: Map<String, String> = emptyMap()): Streams {
        val useRelay = relay.isNotEmpty() && Relay.wanted()
        val out = ArrayList<Source>()
        for (x in r.items.sortedByDescending { it.res }) {
            val m3 = x.url.substringBefore("?").lowercase().endsWith(".m3u8")
            val label = if (x.auto) "Auto (HLS)" else "${x.res}p"
            if (out.any { it.label == label && it.kind == (if (m3) "hls" else "mp4") }) continue
            val kind = if (m3) "hls" else "mp4"
            val rl = if (useRelay) relay[label + "|" + kind] else null
            if (rl != null) { Relay.remember(rl); out.add(Source(label, x.res, rl, kind, x.url, false)) }
            else out.add(Source(label, x.res, x.url, kind, "", false))
        }
        return Streams(out, r.capId, r.capFmt, r.capIds.joinToString(","), if (out.isEmpty()) "No stream was found for this title." else "", r.dom.trimEnd('/') + "/")
    }

    /** ALL subtitle languages of the title (English / Hindi first). */
    fun captions(id: String, slug: String, s: Streams): List<Caption> {
        if (s.capId.isEmpty() && s.capIds.isEmpty()) return emptyList()
        val j = Net.request("/api/captions/" + enc(id) + "?detail_path=" + enc(slug) + "&id=" + enc(s.capId) + "&fmt=" + enc(s.capFmt) + "&ids=" + enc(s.capIds))
        val a = j.optJSONArray("captions") ?: return emptyList()
        val out = ArrayList<Caption>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val u = o.optString("url")
            if (u.isNotEmpty()) out.add(Caption(o.optString("lang", "Subtitle"), u))
        }
        return out
    }
}
