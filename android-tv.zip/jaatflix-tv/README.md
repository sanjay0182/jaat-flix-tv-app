# JaatPlay TV (Android TV, native)

Anime-TV app ka same base, JaatFlix backend (Render) ke saath. WebView nahi hai.

## Parts
- Part 1: project base, Net/Guard/TvPair (QR TV pass), Api.kt.
- Part 2: full UI: home tabs, hero, rows, Continue watching, My List, All grid, search, detail (language, seasons, episodes), sign-in.
- **Part 3 (ye zip):** PlayerActivity: Language, Quality, Audio, Subtitles (sab languages), resume, auto-next, progress save. App ab poora hai.

## Backend (Render) - ZAROORI
`backend/` folder ki 3 files apni repo me replace/add karo: `api.py`, `protect.py`, `tv.html`. Phir Render redeploy.
Ye `/api/tv/new|poll|peek|finish` aur phone page `/tv` jodta hai, aur TV pass ko stream gate me maanta hai.

## Build
1. Is folder ko GitHub repo me daalo (`.github/workflows/build.yml` bhi).
2. `gradle.properties` me `SITE_URL` = Render ka link (abhi `https://jaatflex.onrender.com`).
3. Actions -> "Build Android TV APK" -> artifact `jaatflix-tv-debug-apk`.

## Test (part 3)
Detail page -> Play (ya episode). Player me:
- **OK** = play/pause. **Left/Right** = 10 sec seek (dabaye rakho = tez). **Up** = controls. **Down** = neeche ki button row me jao.
- **Language** (jab 2+ dub ho): dub badalta hai, usi second se chalta hai.
- **Quality**: Auto (HLS), 1080p, 720p... Link fail ho to khud server route / backup / dusri quality try karta hai.
- **Subtitles**: Off + sab languages (English, Hindi upar). Chuni hui language yaad rahti hai.
- **Audio**: sirf tab dikhta hai jab video me 2+ audio track hon.
- **Prev / Next / Episodes / Auto-next** (series). Episode khatam hone par 5 sec ka countdown: OK = abhi chalao, Back = cancel.
- Resume: sign-in ho to account ka Continue watching; guest ke liye isi TV par yaad rakhta hai. Har 10 sec me save hota hai.
- Player se Back dabao to home par Continue watching apne aap refresh hoti hai.

Note: gradle.properties me SITE_URL ko Render ka sahi link rakho. Backend files `backend/` pehle jaisi hi hain.

## Relay hata diya (part 3b)
App ab relay / Wispbyte / Render ke video links use NAHI karta, backup ke taur par bhi nahi.
- `Mb.kt`: app khud MovieBox se token + video links nikalta hai (website ke client-resolve jaisa), to links TV ke apne internet ke liye bante hain.
- Site ka guard (captcha / sign-in / limit) abhi bhi `/api/sign` se chalta hai, par uske diye hue relay links fenk diye jaate hain, sirf haan/na liya jaata hai.
- `PlayerActivity.kt` CDN ko seedha chalata hai aur relay wala kaam khud karta hai: Referer, Origin, User-Agent lagana, 426/427/403 par dusre CDN host (cacdn, sbcdn5) aur dusra User-Agent try karna, aur purane TV par https handshake fail ho to plain http.
- Isliye Wispbyte relay is app ke liye band bhi ho to koi fark nahi (website ke liye wo chalta rahe).

## Update (JaatFlix)
- App name JaatFlix, site wala logo (JAAT blue + FLIX), blue theme, site ka icon.
- Home site jaisa: hero me Watch now + Details + rating/year/genre, "Free Now" aur Midnight rows/tabs hidden, Shorts sabse neeche.
- Mb.kt: wisper relay jaise headers (Referer videoPlayPage, India headers, Accept-Language), 429 wait, fresh token retry. Error ab exact dikhta hai (kaunsa step, HTTP code).

## Update 2 (site jaisa poora UI)
- Category bar: Home / Movies / TV Shows / Anime / Shorts + Browse (site ke same kindOf rules, home feed se).
- Hero ke neeche segment dots, rows me "See all →", Trending/Top rows me Top-10 numbers, card pe kind+year, gold rating, genre.
- Browse screen: Type, Language, Genre, Country, Year, Sort (site ka /browse). My List button. Search me Recent + Trending.
- Detail me genre chips. Poora blue theme (focus ring bhi blue). Midnight kahin nahi.

## Relay + direct fallback (v0.5.0)
Video links are signed by the site (/api/sign) and carried by the Wisper relay (Render needs VIDEO_WORKER set). The TV plays the relay link first.
If a relay link fails, that video plays the same quality direct from the CDN and the failure is counted. After 10 failures in a row the app
plays direct only; every 5 minutes one video tries the relay again, and when it plays the relay is back. See `Relay.kt`.

## v0.5.1 - light on data
- Posters download only for cards on / next to the screen (not whole rows, not covered screens, nothing while the app is in background).
- Home / more / browse / search lists are cached in memory (10 / 5 min), so going back never re-downloads them.
- Hero asks the detail page once per title (was every slide change). Fewer parallel image downloads (4), fewer extra pages per row (2).
- Home is not rebuilt after every account refresh unless Continue watching really changed.
- v0.5.2: posters ask the CDN for the right size (x-oss-process resize): ~95% less data per poster.
