"""
JaatFlix API (MovieBox backend)
- token auto-refresh; the token is also sent with stream calls
- banner items are normalized (the hero image used to break)
- India headers (Asia/Kolkata + IN)
- /p = video proxy: sends the correct Referer to the CDN and rewrites m3u8 playlists
  (direct browser playback used to stall at 0:00 for this reason)
- Optional: env IN_PROXY=http://user:pass@indian-proxy:port routes all calls through an Indian IP
"""
import asyncio, hmac, json, os, re, time
from urllib.parse import quote, urljoin, urlsplit
import httpx
import accounts
import captcha
import protect
from fastapi import FastAPI, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse

app = FastAPI(title="JaatFlix API", version="3.0")
app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip()], allow_methods=["*"], allow_headers=["*", "X-Device", "X-VIP-Key", "X-Captcha", "X-Admin-Key"])
protect.start()

# ---- direct mode: the browser loads pictures / video straight from the CDN, this server only does the small JSON work ----
PUBLIC_BASE = os.getenv("PUBLIC_BASE", "").rstrip("/")      # https://your-app.onrender.com (needed when the page is hosted on Firebase)
STREAM_RELAY = os.getenv("STREAM_RELAY", "").rstrip("/")   # https://xxx.hf.space  -> that Space fetches stream.url instead of this server
RELAY_KEY = os.getenv("RELAY_KEY", "")                      # must match RELAY_KEY on the Space


async def _relay_play(subject_id, detail_path, se, ep):
    """When STREAM_RELAY is set, ask the Space to call the play API with the full
    blitz-style headers (Referer/Origin/India-IP). Falls back to None on any problem,
    so the caller does the old direct call instead."""
    if not STREAM_RELAY:
        return None
    try:
        async with httpx.AsyncClient(timeout=40) as c:
            r = await c.get(
                f"{STREAM_RELAY}/stream",
                params={"subjectId": subject_id, "se": se, "ep": ep, "detailPath": detail_path},
                headers=({"X-Relay-Key": RELAY_KEY} if RELAY_KEY else {}),
            )
        j = r.json()
        if j.get("ok") and j.get("data"):
            return j["data"], (j.get("domain") or "").rstrip("/")
        print("[RELAY] Space answered but no stream: http=%s ok=%s" % (r.status_code, j.get("ok")), flush=True)
    except Exception as e:
        print("[RELAY] Space call FAILED (sleeping / wrong STREAM_RELAY / wrong RELAY_KEY?):", repr(e)[:150], flush=True)
    return ({}, "")   # relay is set: NEVER ask MovieBox for the video from this server (empty = "no stream")
async def _relay_download(subject_id, detail_path, se, ep):
    """Same as _relay_play but for the download API (bcdnw links). The Space asks for them, so the
    links are issued to the Space's IP - the same IP that will fetch them later through /p."""
    if not STREAM_RELAY:
        return None
    try:
        async with httpx.AsyncClient(timeout=25) as c:
            r = await c.get(
                f"{STREAM_RELAY}/download",
                params={"subjectId": subject_id, "se": se, "ep": ep, "detailPath": detail_path},
                headers=({"X-Relay-Key": RELAY_KEY} if RELAY_KEY else {}),
            )
        j = r.json()
        if j.get("ok") and j.get("data"):
            return {"data": j["data"]}
        print("[RELAY] Space /download answered but no links: http=%s ok=%s" % (r.status_code, j.get("ok")), flush=True)
    except Exception as e:
        print("[RELAY] Space /download FAILED:", repr(e)[:150], flush=True)
    return None


DIRECT_IMG = os.getenv("DIRECT_IMG", "1") != "0"            # 0 = pictures go through /img again
DIRECT_VIDEO = os.getenv("DIRECT_VIDEO", "1") != "0"        # 0 = video goes through /p again

_DEBUG = ("/lab", "/shape", "/diag", "/discover", "/peek", "/raw", "/probe")   # developer tools: admin key only


# ---- anti-leak: nothing from MovieBox (hosts, raw errors, image CDN) may reach the browser; every byte goes through this server ----
_IMG_EXT = re.compile(r"\.(jpe?g|png|webp|avif|gif|bmp)(\?|#|$)", re.I)
_IMG_KEYS = {"cover", "image", "avatar", "stills", "thumbnail", "poster", "poster_url", "banner", "icon", "logo", "backdrop", "stillPath"}
_UP_HOST = re.compile(r"(moviebox|aoneroom|netfilm|hakunaymatata|mbcdn|movieboxpro|h5-api)", re.I)
_DROP_KEYS = {"_debug", "_domain", "tried", "via", "_http", "_body", "_err"}
_SKIP_CLEAN = ("/p", "/sub", "/dl", "/img", "/lab", "/shape", "/diag", "/discover", "/peek", "/raw", "/probe")
if DIRECT_VIDEO:
    _SKIP_CLEAN = _SKIP_CLEAN + ("/api/stream",)


def _pimg(u):
    """Signed same-site link for an upstream picture (served by /img, cached)."""
    if DIRECT_IMG:
        return u
    return PUBLIC_BASE + "/img?u=%s&t=%s" % (quote(u, safe=""), protect._sig("img", u))


def _worker_bases():
    """VIDEO_WORKER urls (comma separated), always with https:// - these links are ours and must NOT be blanked by _clean."""
    ws = [w.strip().rstrip("/") for w in os.environ.get("VIDEO_WORKER", "").split(",") if w.strip()]
    return [w if w.lower().startswith(("http://", "https://")) else "https://" + w.lstrip("/") for w in ws]


def _clean(o, key=""):
    if isinstance(o, dict):
        return {k: _clean(v, key if (k == "url" and key in _IMG_KEYS) else k) for k, v in o.items() if k not in _DROP_KEYS}
    if isinstance(o, list):
        return [_clean(v, key) for v in o]
    if isinstance(o, str) and o[:4].lower() == "http":
        if any(o.startswith(w + "/") for w in _worker_bases()):   # signed link to our own Worker (its ?u= holds the encoded upstream url)
            return o
        if _IMG_EXT.search(o) or key in _IMG_KEYS:
            return _pimg(o) if protect.safe_url(o) else ""
        if _UP_HOST.search(o):
            return ""
    return o


def _is_admin(request):
    k = request.headers.get("x-admin-key") or request.query_params.get("key") or ""
    ak = os.getenv("ADMIN_KEY", "")
    return bool(ak) and hmac.compare_digest(k.encode(), ak.encode())


_IMGC = {}   # tiny in-memory picture cache: url -> (time, bytes, content-type)


@app.get("/img")
async def img(u: str, t: str = ""):
    if not t or not hmac.compare_digest(t, protect._sig("img", u)) or not protect.safe_url(u):
        return Response("not found", status_code=404, headers={"Cache-Control": "no-store"})
    hit = _IMGC.get(u)
    if hit and time.time() - hit[0] < 21600:
        return Response(hit[1], media_type=hit[2], headers={"Cache-Control": "public, max-age=604800, immutable"})
    try:
        async with httpx.AsyncClient(follow_redirects=True, timeout=20, **CK) as c:
            r = await c.get(u, headers={"User-Agent": UA, "Referer": _ref["v"], "Accept": "image/*,*/*;q=0.8"})
    except Exception:
        return Response("bad gateway", status_code=502, headers={"Cache-Control": "no-store"})
    ct = r.headers.get("content-type", "").split(";")[0].strip().lower()
    if r.status_code != 200 or not ct.startswith("image/") or len(r.content) > 8_000_000:
        return Response("not found", status_code=404, headers={"Cache-Control": "no-store"})
    if len(_IMGC) > 400:
        for k_ in sorted(_IMGC, key=lambda x: _IMGC[x][0])[:100]:
            _IMGC.pop(k_, None)
    _IMGC[u] = (time.time(), r.content, ct)
    return Response(r.content, media_type=ct, headers={"Cache-Control": "public, max-age=604800, immutable"})


@app.middleware("http")
async def _protect_mw(request: Request, call_next):
    path = request.url.path
    if path.startswith(_DEBUG):
        if not _is_admin(request):
            return JSONResponse({"error": "not found"}, status_code=404)
    try:
        r = protect.middleware_check(request)
    except Exception:
        r = None
    if r is not None:
        return JSONResponse(r[1], status_code=r[0])
    resp = await call_next(request)
    try:
        if path.startswith(_SKIP_CLEAN) or "application/json" not in resp.headers.get("content-type", "") or _is_admin(request):
            return resp
        body = b"".join([ch async for ch in resp.body_iterator])
        hd = {k: v for k, v in resp.headers.items() if k.lower() not in ("content-length", "content-type")}
        try:
            out = json.dumps(_clean(json.loads(body)), ensure_ascii=False).encode()
        except Exception:
            out = body
        return Response(out, status_code=resp.status_code, headers=hd, media_type="application/json")
    except Exception:
        return resp

API = "https://h5-api.aoneroom.com/wefeed-h5api-bff"
UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
XCI = '{"timezone":"Asia/Kolkata"}'
PROXY = os.getenv("IN_PROXY") or None
CK = {"proxy": PROXY} if PROXY else {}

H = {
    "User-Agent": UA, "Referer": "https://moviebox.ph/", "Origin": "https://moviebox.ph",
    "Accept": "application/json", "Content-Type": "application/json",
    "X-Request-Lang": "en", "X-Client-Info": XCI, "Accept-Language": "en-IN,en;q=0.9",
}
HOST = os.getenv("MB_HOST", "moviebox.ph")          # /home?host=... (mirror site)
HBASE = dict(H)  # without the India headers (used only by /probe)
# Confirmed via /probe: these IP headers return Indian content (now the default; no env var needed)
IN_IP = os.getenv("IN_FAKE_IP", "49.205.120.45")
INH = {"X-Forwarded-For": IN_IP, "X-Real-IP": IN_IP, "CF-Connecting-IP": IN_IP, "CF-IPCountry": "IN"}
H.update(INH)
H.update(json.loads(os.getenv("MB_HEADERS", "{}")))  # extra headers can be supplied as JSON via the environment
_tok = {"v": "", "t": 0}
_ref = {"v": "https://netfilm.world/"}

# Extra CDN hosts seen in real traffic captures (Reqable). When the primary stream host (bcdnxw/bcdnw)
# answers 426/427 to our IP, we swap the host for one of these and retry with the same path+query -
# some of these CDN edges do not block datacenter IPs the way bcdnxw does.
_FALLBACK_CDN_HOSTS = [h.strip() for h in os.environ.get(
    "FALLBACK_CDN_HOSTS", "cacdn.hakunaymatata.com,sbcdn5.hakunaymatata.com"
).split(",") if h.strip()]
_ALT_UA = ("com.community.oneroom/50020131 (Linux; U; Android 10; en_IN; Redmi Note 7; "
           "Build/QKQ1.190910.002; Cronet/156.0.8078.25)")


async def _try_fallback_hosts(u, headers, timeout=15):
    """Re-fetch a stream url (HEAD-ish, only first bytes) on each fallback CDN host, same path+query,
    with the alternate UA too. Returns (working_url, working_headers) or (None, None)."""
    from urllib.parse import urlparse as _up, urlunparse as _uup
    p = _up(u)
    for host in _FALLBACK_CDN_HOSTS:
        if host == p.netloc.split(":")[0]:
            continue
        cand = _uup((p.scheme, host, p.path, p.params, p.query, p.fragment))
        for ua in (headers.get("User-Agent"), _ALT_UA):
            h2 = {**headers, "User-Agent": ua, "Range": "bytes=0-15"}
            try:
                async with httpx.AsyncClient(timeout=timeout, follow_redirects=True, **CK) as c:
                    r = await c.get(cand, headers=h2)
                if r.status_code in (200, 206):
                    print("[FALLBACK] %s -> %s ok (ua=%s)" % (p.netloc, host, "alt" if ua == _ALT_UA else "orig"), flush=True)
                    return cand, {**headers, "User-Agent": ua}
            except Exception as e:
                print("[FALLBACK] %s -> %s failed: %r" % (p.netloc, host, e), flush=True)
    return None, None


def _grab(r):
    xu = r.headers.get("x-user")
    if xu:
        try:
            t = json.loads(xu).get("token")
            if t:
                _tok["v"], _tok["t"] = t, time.time()
        except Exception:
            pass


async def ensure_token(force=False):
    if not force and _tok["v"] and time.time() - _tok["t"] < 900:
        return _tok["v"]
    async with httpx.AsyncClient(follow_redirects=True, timeout=25, **CK) as c:
        try:
            _grab(await c.get(f"{API}/home?host={HOST}", headers=H))
        except Exception:
            pass
    return _tok["v"]


async def call(url, payload=None, hdr=None, retry=True):
    await ensure_token()
    h = dict(hdr or H)
    if _tok["v"]:
        h["Authorization"] = "Bearer " + _tok["v"]  # this was previously missing from player calls
    async with httpx.AsyncClient(follow_redirects=True, timeout=30, **CK) as c:
        try:
            r = await (c.post(url, headers=h, content=json.dumps(payload)) if payload is not None else c.get(url, headers=h))
        except Exception as e:
            return {"_err": str(e)}
        _grab(r)
        if r.status_code == 429:  # rate limit: wait and retry (up to 2 times)
            for wait in (2.5, 5):
                await asyncio.sleep(wait)
                try:
                    r = await (c.post(url, headers=h, content=json.dumps(payload)) if payload is not None else c.get(url, headers=h))
                except Exception as e:
                    return {"_err": str(e)}
                if r.status_code != 429:
                    break
            _grab(r)
        if r.status_code in (401, 403) and retry:
            await ensure_token(True)
            return await call(url, payload, hdr, retry=False)
        if r.status_code != 200:
            return {"_http": r.status_code, "_body": r.text[:200]}
        try:
            return r.json()
        except Exception:
            return {}


# ---------------- logo / icons (embedded, so no separate file is needed) ----------------
import base64
_ICONS = {
    "icon-192.png": base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAADUklEQVR42u3dMVLDQBBE0ZXKVQQKFHAA3dEHIPABdEcO4IBQkckJbW+h2X4/J2Cmv3qEoZiWZX00IJTZCEAAgAAAAQACAAQACAAQACAAQACAAAABAAIABAAIABAAIABAAIAAAAEAAgAEAAgAEAAgAEAAgAAAAQACAAQACAAQACAAQACAAAABAAIA7+JiBH35uH6/9PXHvhliRyb/JvU8YScFAQSeEAQQejIQQPCJQAChJwMBBJ8I3fA5QEj4R//eNIBwaAMCCD4RnEDCbwYEsHizcAJZtpNIAwi/GRFA+M0qVwDhN7NYAYTf7GIFEH4zjBVA+M0yVgDhN9NYAYTfbGMFEH4zjhVA+M3aCQQkCuDpb+axAvz3Iu63lQQEyF7A/bbGilBdAu8A2sA7gCePNkhtAQ1ABA3gieMsSm2B2aC1QfJunEDawAnkCaMNUnekAYigAeAsIoBq1QaBu9IARNAAnijOotSdaQBtoAFABAKoUmdR4O40gDbQANAGBIA2IIAbkghZO9QAziINAG1AABCBAHAWEcDLkzaI2aUGIIIGgLOIANAGBIA2IAC0AQFABALAWUQAaINxuVg3/vL59aMBIPwaAIJPAAi+EwjCrwEg+ASA4BOgP8e++ZuAQYJ/7Jt3AHjqawAIPgEg+E4gCL8G8CI8fvDP/ALsBBJ8J5ARCL8TCIJPAO8Bgp91/zuBhF8DGIHgE8AZJPiB548TSPg1QKUnysgtMFLwqzz9vQMIvgYwAsFPptQ7QKVqTQ1/tR1pAMF3AlV7wlR7GU4JfsWGng1a+JPPUyeQ4DuBqj5xzngKJQa/8g8nfBIs/BpACwh+4tO/tdamZVkf1Zfg7wWEP/oEGuUDMjMnAEAALWDWBCCBGRPAgsyWABZlpgSwMLMkgMWZIQEs0OwIYJFmRgALNSsCWKwZvcAQvwz3DH6BzsMhrgEs3CwIYPFm4ARyEpGfAJEiCL4TKDYgwq8BIttA8AkQJ4PQEyBSBMEnQJwMQk+AKCEEngAxUgg7AYBu+BwABAAIABAAIABAAIAAAAEAAgAEAAgAEAAgAEAAgAAAAQACAAQACAAQACAAQACAAAABAAIABAAIABAAIABAAIAAAAEAAgAEAAgAEAAgAPA2fgH5VHVzeUiomAAAAABJRU5ErkJggg=="),
    "icon-512.png": base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAALKUlEQVR42u3csXHyWhCAUWCYIbiBAhdAjxTgwAXQowpw4JBIjpzZRjYSurt7TgEvYNDux8r/27c2TDsAoJSDjwAABAAAIAAAAAEAAAgAAEAAAAACAAAQAACAAAAABAAAIAAAAAEAAAgAAEAAAAACAAAQAACAAAAABAAACAAAQAAAAAIAABAAAIAAAAAEAAAgAAAAAQAACAAAQAAAAAIAABAAAIAAAAAEAAAgAAAAAQAACAAAEAAAgAAAAAQAACAAAAABAAAIAABAAAAAAgAAEAAAgAAAAAQAACAAAAABAAAIAABAAAAAAgAAEAAAIAAAAAEAAAgAAEAAAAACAAAQAACAAAAABAAAIAAAAAEAAAgAAEAAAAACAAAQAACAAAAABAAAIAAAQAAAAAIAABAAAIAAAAAEAAAgAAAAAQAACAAAQAAAAAIAABAAAIAAAAAEAAAgAAAAAQAACAAAQAAAgADwEQCAAAAABAAAIAAAAAEAAAgAAEAAAAACAAAQAACAAAAABAAAIAAAAAEAAAgAAEAAAAD3HH0EkMfpMq76379dzz5kSGLf2jD5GMByFwkgAABLXhyAAAAse1EAAgCw8AUBCADAwhcEIADA0kcMgAAASx8xAAIALH3EAAgAsPQRAyAAwNJHDIAAAIsfIQACACx9xAAIALD4EQIgAMDiRwiAAACLHyEAAgAsfoQACAAsfhACCAABgMUPQgABABY/CAEEAFj8IARI6OAjwPIH3zVcAMAwBtcABABY/CAEyMgrACx/8J3EBQAMWXANwAUALH/wXcUFAAxTcA3ABQAsf/AdRgCAwQm+y0ThFQCGJTyJVwK4AIDlj+84CAAwGPFdh+fyCgDDEDbilQAuAFj+4BkAAYDBB54FEAAYeOCZgIX5GwAMOeiIvwvABQDLHzwrIAAw0MAzAwIAgww8OyAAMMDAMwQCAIMLPEsgADCwwDMFAgCDCjxbCAAfAQYUeMYQAGAwgWcNAQAGEnjmEABgEIFnDwGAAQR4BhEAGDyAZxEBgIEDeCYRABg0gGcTAYABA3hGEQAAgADALwvAs4oAwEABPLMIAAwSwLOLAMAAATzDCAAAQADglwN4lkEAYGCAZxoEAAYFeLYRAACAAMAvBMAzjgDAYAA86wgADAR+9f42+BDwzCMAoGoECAFAAOCXgGsAePYRABgArgFgBiAAwDUAQACg/F0DwCxAAOCBFwJgJiAAIFsIAAgAlL5rAJgNCAAQAgACAIVfJgTAjEAA4MF2DQCzAgEArgEAAgBF7xoAZgYCAIQAgABQ8iQNATA7EADgGgAgAFDwQgDMEAQAlAkBAAGg3HENALMEAQCuAQACQLHjGgBmigAAhAAgAFDqJA0BMFsQAOAaAAgAFDpCAMwYAQCUCQFAAKDMcQ0As0YAAK4BgAAAXAMAAUAfnOQQApg5CABg8RAABABKHNcAMHsEACAEAAEAlAkBQACwESc4XAMwgxAAgGsAIAAA1wBAAKTj9IYQwCxCAADdhQAgAADXAEAA8CgnN4QAZhICAAgTAoAAAFwDAAHAXE5tuAZgNiEAANcAQAAAQgAQAOk4sZE9BDCjEACAawAgAAAhAAgAoEwIAAKgNO/WcA3ArEIAAK4BgAAAXAMAAQAIAUAAxOedGvwcAphZCADANQAQAIAQAAQAUCYEAAEAuAYAAiAef0wDrgFmFwIAwDUABACAEAABADArBAABALgGgAAAEAIgAADKhAAIALrhn9GAa4AZhgAAcA0AAQDgGgACAEAIgAAAWDYEQAAAuAaAAAAQAiAAAMqEAAgAANcAEAA8zv9AA1wDzDIEAIBrAAgAACEAAgCgyxAAAQDgGgACAEAIgAAAKBMCIAAAXANAAAC4BoAAAHANAAEAIARAAAAkDQEQAACuAbCao48AoB8vrx8+BFwAACx/cAEAsPhBAABY/PBfXgEAWP64AABg8SMAALD4SckrAADLHxcAACx+XAAAsPxxAQDA4kcAsKLb9bw7XUYfBFj84WcZffIKAMDyxwUAAIsfAQCAxU9KXgEAWP64AABg8SMAACx+HwIpeQUAYPnjAgCAxY8AYFP+Z0Bg8UefYfTLKwAAyx8XAACLH1wAACx/cAEAsPhBAABY/BCUVwCA5Q8uAPTGPwUEiz/q7EIAAFj80BmvAADLH1wAACx+EAAAFj+k5BVAAP6YBix/MwsXAACLHwQAYPEDf+cVAGD5gwsAvfI/BMLiJ8qswgUAwPIHFwAAix8EAIDFD5vxCiAQ79aw/DGjcAEALH5AAAAWPzCfVwDBOLFh+WM24QIAWPyAAAAsfmAerwACcmrD8sdMwgUAsPgBAQBY/MB9XgEE5eSG5Y9ZhAsAYPEDLgCA5Q+4AKR1u553p8vog8DiZ7MZhAAALH4gEK8AAMsfXACIxmsALH62mj0IAMDiB4LxCkCJg+WPmeMCAGDxgwAALH4gJa8AknCSw/LHrMEFALD4AQFQqcz9k0Asfvz6Zw6vAMDyB1wAcAXA4ge//l0AAMsfcAHAFQCLH7/+EQCAxQ8E5RWAYsfyB7PEBQCw+AEBQPhy97cAFj/49c93vAIAyx9wAcAVAIsf/PoXAIDFD6TkFYCSx/IHM8MFALD4AQFAqqL3twAWP/j1zxevADzYWP5gRrgAABY/4AKAwsfyx2zABQCw+AEBQODS9weBFj/49V+bVwAeeCx/zAJcAACLHxAApC9/rwIsfvz6pyavAAwAH4Llj2cfFwDA4gcq2Lc2TD4GvAoAv/6pxSsADATwrCMAMBgAzzgCAAAQAPiFAHi2EQAYFIBnGgGAgQF4lhEAAIAAwC8HwDOMAMAAATy7CAAMEsAziwDAQAE8qwgAAEAA4JcF4BlFAGDAAJ5NBAAGDXgmQQBg4IBnEQQABg94BkEAYACBZw8BAAYReOYQAGAggWcNAQAGE3jGEABgQIFnCwEABhV4phAAGFgGFniWEAAYXIBnCAGAAQZ4dhAAGGSAZwYBgIEGnhVY2761YfIx8Eyny+hDAIsfFwAMOvBMgADAwAPPAggADD7wDMDy/A0AXfB3AVj84AKAgQi+6yAAMBjBdxyW5hUAXfJKAIsfXAAwMMF3GQQABif4DsOjvAIgBK8EsPjBBQADFXxXwQUA1wCw+MEFAIMWfCfBBQDXALD4QQAgBMDih51XABjI4LuGCwC4BoDFjwAAIYDFb/EjAEAIYPGDAAAhgMUPAgCEABY/CAAQAlj8IABACGDxgwAAIYDFDwIAxACWPggAEAJY/CAAQAxg6YMAADGApQ8CAMSApQ8IABADlj4gAEAMWPqAAABBYOEDAgAEgYUPAgAQBZY9CABAHFjyIAAAkWC5gwAAACI7+AgAQAAAAAIAABAAAIAAAAAEAAAgAAAAAQAACAAAQAAAAAIAABAAAIAAAAAEAAAgAAAAAQAACAAAQAAAgAAAAAQAACAAAAABAAAIAABAAAAAAgAAEAAAgAAAAAQAACAAAAABAAAIAABAAAAAAgAAEAAAgAAAAAEAAAgAAEAAAAACAAAQAACAAAAABAAAIAAAAAEAAAgAAEAAAAACAAAQAACAAAAABAAAIAAAAAEAAAIAABAAAIAAAAAEAAAgAAAAAQAACAAAQAAAAAIAABAAAIAAAAAEAAAgAAAAAQAACAAAQAAAAAIAAAQAACAAAAABAAAIAABAAAAAAgAAEAAAgAAAAAQAACAAAAABAAAIAABAAAAAAgAAEAAAgAAAAAQAAAgAHwEACAAAQAAAAAIAABAAAIAAAAAEAAAgAAAAAQAACAAAQAAAAAIAABAAAIAAAAAEAABwzycsV9EZ+eIwtgAAAABJRU5ErkJggg=="),
}
_MANIFEST = {"name": "JaatFlix", "short_name": "JaatFlix", "start_url": "/", "display": "standalone",
             "background_color": "#0a0a0d", "theme_color": "#0a0a0d",
             "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
                       {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"}]}


def _icon(name):
    return Response(_ICONS[name], media_type="image/png", headers={"Cache-Control": "public, max-age=86400"})


@app.get("/icon-192.png")
async def icon192():
    return _icon("icon-192.png")


@app.get("/icon-512.png")
async def icon512():
    return _icon("icon-512.png")


@app.get("/logo.png")
async def logo_png():
    return _icon("icon-512.png")


@app.get("/favicon.ico")
async def favicon():
    return _icon("icon-192.png")


@app.get("/app.webmanifest")
async def webmanifest():
    return Response(json.dumps(_MANIFEST), media_type="application/manifest+json")


@app.get("/config.js")
async def config_js():
    return Response('window.API_BASE="";', media_type="application/javascript", headers={"Cache-Control": "no-cache"})


@app.get("/")
async def ui():
    return FileResponse("index.html", headers={"Cache-Control": "no-cache"})


def _item(s):
    s = s or {}
    t = s.get("title") or ""
    cn = s.get("corner")
    badge = cn if isinstance(cn, str) and cn else ("Hindi" if "[hindi]" in t.lower() else None)  # "Hindi" tag shown on the card
    return {"name": t or None, "poster_url": (s.get("cover") or {}).get("url"),
            "slug": s.get("detailPath"), "subject_id": s.get("subjectId"), "rating": s.get("imdbRatingValue"),
            "badge": badge, "type": s.get("subjectType"), "genre": s.get("genre"), "country": s.get("countryName"),
            "year": str(s.get("releaseDate") or "")[:4]}


# ===== MovieBox's real home / tabs / "All" (not search-based: MovieBox updates trending itself every day) =====
_TAB_KEYS = ("tabList", "tabs", "navList", "homeTabs", "topTabs", "navigation", "categoryList", "channelList")
_SUB_KEYS = ("tabs", "tabList", "subTabs", "categoryList", "categories", "filters", "genres")
_ID_KEYS = ("genreTopId", "rankingId", "rankId", "opId", "id", "url", "jumpUrl", "path", "link")


def _nm(d):
    return d.get("name") or d.get("title") or d.get("tabName") or d.get("categoryName") or d.get("label") or d.get("lanName")


def _tid(d):
    for k in ("tabId", "id", "categoryId", "rankingId", "opId", "path", "url"):
        if d.get(k) not in (None, ""):
            return str(d[k])
    return None


def _banner_items(op):
    items = []
    for b in (op.get("banner") or {}).get("items") or []:
        sub = b.get("subject") or {}
        items.append({
            "name": b.get("title") or sub.get("title"),
            "poster_url": (b.get("image") or {}).get("url") or (sub.get("cover") or {}).get("url"),
            "slug": b.get("detailPath") or sub.get("detailPath"),
            "subject_id": b.get("subjectId") or sub.get("subjectId"),
        })
    return [i for i in items if i["slug"]]


def _subtabs(op):
    """Tabs inside a section (Asian Drama / Western TV / Turkish Drama / New ...) as provided by MovieBox."""
    for k in _SUB_KEYS:
        v = op.get(k)
        if isinstance(v, list) and v and isinstance(v[0], dict):
            tabs = []
            for t in v:
                n = _nm(t)
                if not n:
                    continue
                subs = t.get("subjects")
                img = t.get("image")
                tabs.append({"name": n, "id": _tid(t), "query": t.get("query") or "", "image": img.get("url") if isinstance(img, dict) else None,
                             "items": [_item(s) for s in subs] if isinstance(subs, list) else None})
            if tabs:
                return tabs
    return None


def _sections(d):
    out = []
    for op in (d.get("data") or {}).get("operatingList") or []:
        if op.get("type") == "BANNER":
            out.append({"section": "Banner", "items": _banner_items(op)})
            continue
        more = {k: op[k] for k in _ID_KEYS if op.get(k) not in (None, "")}
        out.append({"section": op.get("title") or op.get("type"),
                    "items": [i for i in (_item(s) for s in op.get("subjects") or []) if i["slug"]],
                    "more": more or None, "tabs": _subtabs(op),
                    "kind": "filter" if op.get("type") == "FILTER" else None})
    return out


def _toptabs(d):
    """Top-level tabs (Trending / Movie / Anime / ...) as provided in the MovieBox home response."""
    data = d.get("data") or {}
    for k in _TAB_KEYS:
        v = data.get(k)
        if isinstance(v, list) and v and isinstance(v[0], dict):
            tabs = [{"name": _nm(t), "id": _tid(t)} for t in v if _nm(t)]
            if tabs:
                return tabs
    return []


def _platforms(d):
    """Streaming services row (Netflix / Prime ...) = `platformList` of the home response."""
    out = []
    for p in (d.get("data") or {}).get("platformList") or []:
        if not isinstance(p, dict):
            continue
        n = p.get("name") or p.get("platform") or p.get("platformName") or p.get("title")
        if not n:
            continue
        img = p.get("image") or p.get("logo") or p.get("icon") or p.get("cover")
        if isinstance(img, dict):
            img = img.get("url")
        out.append({"name": n, "by": p.get("uploadBy") or "", "image": img if isinstance(img, str) else None})
    return out


def _sentinel(d):
    """MovieBox answers a guest's /subject/filter with total=1000000 and a junk default list (kids songs, music videos)."""
    x = (d.get("data") or {}) if isinstance(d, dict) else {}
    for src in (x, x.get("pager") if isinstance(x.get("pager"), dict) else {}):
        for k in ("totalCount", "total", "count"):
            if str(src.get(k)) == "1000000":
                return True
    return False


def _extract(d):
    x = d.get("data") if isinstance(d, dict) else None
    if isinstance(x, list):
        lst = x
    elif isinstance(x, dict):
        lst = next((x[k] for k in ("subjectList", "subjects", "items", "list", "contents", "records") if isinstance(x.get(k), list)), [])
    else:
        lst = []
    its = (_item(s.get("subject") if isinstance(s.get("subject"), dict) else s) for s in lst if isinstance(s, dict))
    return [i for i in its if i["slug"]]


def _home_url(tab="", page=0):
    u = f"{API}/home?host={HOST}"
    if tab:
        u += "&tabId=" + quote(tab, safe="")
    if page:
        u += f"&page={page}"
    return u


@app.get("/home")
async def home(tab: str = "", page: int = 0):
    d = await call(_home_url(tab, page))
    return {"sections": _sections(d), "tabs": _toptabs(d), "platforms": _platforms(d), "_debug": d.get("_http") or d.get("_err")}


@app.get("/more")
async def more(id: str = "", url: str = "", title: str = "", page: int = 1, per: int = 24):
    """Full list for 'All >' / a sub-tab. MovieBox's own endpoints are tried one by one."""
    cands = []
    if id:  # verified: ranking-list/content (id = genreTopId) pages correctly for every home row
        cands.append(f"{API}/ranking-list/content?id={quote(id, safe='')}&page={page}&perPage={per}")
    if url.startswith("/") and not url.startswith("//") and ".." not in url and "@" not in url and re.match(r"^/(ranking-list|subject|tab-operating|operating|home)\b", url):
        cands.append(f"{API}{url}{'&' if '?' in url else '?'}page={page}&perPage={per}")
    if re.search(r"trending", title, re.I):
        cands.append(f"{API}/subject/trending?page={max(page - 1, 0)}&perPage={per}")
    tried = []
    for u in cands:
        d = await call(u)
        its = _extract(d)
        tried.append({"url": u, "n": len(its), "err": d.get("_http") or d.get("_err")})
        if its:
            return {"items": its, "page": page, "via": u, "tried": tried}
    return {"items": [], "page": page, "tried": tried}


@app.get("/filter")
async def filter_list(query: str, page: int = 1, per: int = 24):
    """Category lists (All Movies / All Dramas / Punjabi / Bengali ...). `query` is the raw query string MovieBox supplies for each filter.
    The real API path is not documented, so several likely endpoints (POST and GET) are tried one by one."""
    from urllib.parse import parse_qsl, urlencode
    prm = dict(parse_qsl(query, keep_blank_values=True))
    prm.pop("type", None)
    try:
        ft = json.loads(prm.pop("filterType", "{}"))
    except Exception:
        ft = {}
    tab = prm.get("tabId", "")
    # The web API numbers its channels 1 = movies, 2 = TV, 4 = anime; the "Categories" widget uses the app's ids (2 / 5 / 8).
    chan = {"2": "1", "5": "2", "8": "4"}.get(tab, tab)
    # Verified by testing the real API: /subject/filter takes channelId + genre/country/year/sort/classify.
    # Language = classify ("Hindi dub" etc.); a separate `language` field is ignored.
    # total=1000000 is MovieBox's normal total, NOT junk, so no sentinel filtering is done.
    base = {"channelId": chan, "page": page, "perPage": per, "genre": "All", "country": "All", "year": "All", "sort": "ForYou", "classify": "All"}
    b1 = {**base, **{k: v for k, v in ft.items() if v not in (None, "")}}
    body = {**ft, "tabId": tab, "channelId": tab, "page": page, "perPage": per}
    flat = urlencode(body)
    cands = [("POST", f"{API}/subject/filter", b1),
             ("POST", f"{API}/subject/filter", {**b1, "country": "India"} if b1.get("country") == "All" else b1)]
    if cands[0][2] == cands[1][2]:
        cands = cands[:1]
    tried = []
    for method, u, payload in cands:
        d = await call(u, payload) if method == "POST" else await call(u)
        its = _extract(d)
        sen = False
        err = d.get("_http") or d.get("_err")
        row = {"m": method, "url": u[:140], "n": len(its), "err": err, "sentinel": sen,
               "chan": (payload or {}).get("channelId")}
        if not its and not err:
            row["head"] = json.dumps(d, ensure_ascii=False)[:300]
        tried.append(row)
        if its:
            return {"items": its, "page": page, "via": row, "tried": tried}
    return {"items": [], "page": page, "tried": tried}


_LAB_HTML = r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MovieBox lab</title>
<style>body{font:14px system-ui,sans-serif;background:#0d0d10;color:#eee;margin:0;padding:12px}
button,select,input,textarea{font:inherit;background:#1d1d24;color:#eee;border:1px solid #333;border-radius:8px;padding:8px}
.row{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0;align-items:center}
textarea{width:100%;box-sizing:border-box;height:120px;font-family:monospace;font-size:12px}
input.p{width:100%;box-sizing:border-box;font-family:monospace;font-size:12px}
pre{white-space:pre-wrap;word-break:break-all;background:#15151a;padding:10px;border-radius:8px;font-size:12px}
.go{background:#e50914;border-color:#e50914}h3{margin:4px 0}small{color:#999}</style></head><body>
<h3>MovieBox lab</h3><small>Requests go from your server to MovieBox (token added automatically).</small>
<div class="row" id="pre"></div>
<small>Home rows (tap = open that row's full list via genreTopId):</small>
<div class="row" id="ids"></div>
<div class="row"><select id="m"><option>GET</option><option>POST</option></select><button class="go" id="run">Run</button><label><input type="checkbox" id="rawc"> raw JSON</label></div>
<input class="p" id="path"><textarea id="body" placeholder="POST body (JSON)"></textarea>
<pre id="out">Tap a preset, then Run.</pre>
<script>
const $=i=>document.getElementById(i);
const F=(ch,x)=>JSON.stringify(Object.assign({channelId:ch,page:1,perPage:12,genre:"All",country:"All",year:"All",sort:"ForYou",classify:"All"},x||{}));
const PRE=[["Home","GET","/home?host=moviebox.ph",""],
["Movies ch1","POST","/subject/filter",F("1")],["TV ch2","POST","/subject/filter",F("2")],["Anime ch4","POST","/subject/filter",F("4")],
["Movies Action 2025","POST","/subject/filter",F("1",{genre:"Action",year:"2025"})],
["Movies Hindi (classify)","POST","/subject/filter",F("1",{classify:"Hindi dub"})],
["Movies Hindi (language)","POST","/subject/filter",F("1",{language:"Hindi dub"})],
["Old: TV ch5","POST","/subject/filter",F("5")],
["Trending","GET","/subject/trending?page=0&perPage=12",""],
["Midnight","GET","/tab-operating?tabId=ONEROOM_MIDNIGHT",""],
["Bottom tabs","GET","/tab/get-bottom-tab-list",""],
["Search","POST","/subject/search",JSON.stringify({keyword:"avatar",page:1,perPage:12})]];
function find(o,d){if(d>6||!o||typeof o!=="object")return null;
 if(Array.isArray(o)){if(o.length&&o[0]&&typeof o[0]==="object"&&("title" in o[0]||"subject" in o[0]))return o;for(const x of o){const r=find(x,d+1);if(r)return r}return null}
 for(const k of Object.keys(o)){const r=find(o[k],d+1);if(r)return r}return null}
function summ(d){let s="";if(d._http||d._err)s+="HTTP/ERR: "+(d._http||d._err)+" "+(d._body||"")+"\n";
 const x=d.data||{},pg=x.pager||{},tot=pg.totalCount!==undefined?pg.totalCount:(x.total!==undefined?x.total:pg.total);
 if(tot!==undefined)s+="total: "+tot+(String(tot)==="1000000"?"  <- SENTINEL (filter ignored)":"")+"\n";
 const a=find(d.data||d,0);
 if(a)s+="items: "+a.length+"\n"+a.slice(0,12).map(i=>"- "+((i.subject&&i.subject.title)||i.title)+(i.subjectType!=null?" ["+i.subjectType+"]":"")).join("\n");
 else s+="no item list found. data keys: "+Object.keys(x).join(", ");return s}
async function run(){$("out").textContent="...";let body=null;
 if($("m").value==="POST"){try{body=JSON.parse($("body").value||"{}")}catch(e){$("out").textContent="Body is not valid JSON";return}}
 try{const r=await fetch("/lab/run",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({method:$("m").value,path:$("path").value,body:body})});
  const d=await r.json();$("out").textContent=$("rawc").checked?JSON.stringify(d,null,1).slice(0,20000):summ(d)}catch(e){$("out").textContent="Error: "+e}}
function setReq(m,p,b,go){$("m").value=m;$("path").value=p;$("body").value=b;if(go)run()}
PRE.forEach(([n,m,p,b])=>{const e=document.createElement("button");e.textContent=n;e.onclick=()=>setReq(m,p,b,true);$("pre").append(e)});
$("run").onclick=run;
fetch("/lab/ids").then(r=>r.json()).then(L=>L.forEach(o=>{const e=document.createElement("button");e.textContent=o.title;
 e.onclick=()=>setReq("GET","/ranking-list/content?id="+o.id+"&page=1&perPage=12","",true);$("ids").append(e)})).catch(()=>{});
</script></body></html>'''


@app.get("/lab")
async def lab_page():
    """Test page: send any request to MovieBox from the browser and see the answer, without changing code."""
    return Response(_LAB_HTML, media_type="text/html")


@app.post("/lab/run")
async def lab_run(req: Request):
    j = await req.json()
    path = j.get("path") or ""
    if not path.startswith("/"):
        return JSONResponse({"_err": "path must start with /"})
    post = (j.get("method") or "GET").upper() == "POST"
    return JSONResponse(await call(API + path, (j.get("body") or {}) if post else None))


@app.get("/lab/ids")
async def lab_ids():
    d = await call(_home_url())
    return [{"title": op.get("title") or op.get("type"), "id": op.get("genreTopId")}
            for op in (d.get("data") or {}).get("operatingList") or [] if op.get("genreTopId")]


@app.get("/shape")
async def shape(tab: str = ""):
    """Open in the browser: /shape -> structure of the MovieBox home response (tabs, section ids). For debugging."""
    d = await call(_home_url(tab))
    data = d.get("data") or {}
    return {"status": d.get("_http") or d.get("_err") or "ok",
            "data_keys": {k: type(v).__name__ + (f"[{len(v)}]" if isinstance(v, (list, dict)) else "") for k, v in data.items()},
            "top_tabs_found": _toptabs(d),
            "ops": [{"type": op.get("type"), "title": op.get("title"), "keys": sorted(op.keys()), "n": len(op.get("subjects") or []),
                     "ids": {k: op[k] for k in _ID_KEYS if k in op}, "sub_tabs": [t["name"] for t in (_subtabs(op) or [])]}
                    for op in data.get("operatingList") or []]}


@app.get("/diag")
async def diag():
    """Debug: open /diag in the browser for a one-page health check (token, home, detail of the first title)."""
    out = {"token_ok": bool(await ensure_token(True))}
    d = await call(_home_url())
    out["home"] = d.get("_http") or d.get("_err") or "ok"
    first = next((i for sec in _sections(d) for i in sec["items"] if i.get("slug")), None)
    out["first_item"] = first
    if first:
        dd = await call(f"{API}/detail?detailPath={first['slug']}")
        data = dd.get("data") or {}
        out["detail"] = {"status": dd.get("_http") or dd.get("_err") or "ok", "code": dd.get("code"),
                         "message": dd.get("message") or dd.get("msg"), "has_subject": bool(data.get("subject")),
                         "body": dd.get("_body"), "keys": list(dd.keys())[:10]}
    return out


@app.get("/discover")
async def discover():
    """Debug: probes home tabs 0-12, filter variants (genre / platform) and a few candidate endpoints in one go."""
    async def tab(t):
        d = await call(_home_url(str(t)))
        ops = (d.get("data") or {}).get("operatingList") or []
        return str(t), {"err": d.get("_http") or d.get("_err"), "n_ops": len(ops),
                        "titles": [(op.get("title") or op.get("type")) for op in ops][:9],
                        "filters": [f.get("title") for op in ops if op.get("type") == "FILTER" for f in (op.get("filters") or [])][:25]}

    base = {"classify": "All", "country": "All", "genre": "All", "sort": "ForYou", "year": "All", "page": 1, "perPage": 6}

    async def flt(name, extra):
        body = {**base, **extra}
        d = await call(f"{API}/subject/filter", body)
        its = _extract(d)
        return name, {"n": len(its), "err": d.get("_http") or d.get("_err"), "names": [i["name"] for i in its[:4]]}

    async def probe(path):
        d = await call(API + path)
        return path, d.get("_http") or ("ok:" + json.dumps(d, ensure_ascii=False)[:160])

    tabs = dict(await asyncio.gather(*[tab(t) for t in range(0, 13)]))
    tests = dict(await asyncio.gather(
        flt("tv_romance", {"tabId": "5", "channelId": "5", "genre": "Romance"}),
        flt("tv_all", {"tabId": "5", "channelId": "5"}),
        flt("tab3_all", {"tabId": "3", "channelId": "3"}),
        flt("tab4_all", {"tabId": "4", "channelId": "4"}),
        flt("tv_platform_netflix", {"tabId": "5", "channelId": "5", "platform": "Netflix"}),
        flt("tv_classify_netflix", {"tabId": "5", "channelId": "5", "classify": "Netflix"}),
    ))
    paths = ["/subject/filter-options", "/subject/filter/options", "/home/filter", "/subject/genres", "/subject/platform", "/subject/platform-list", "/subject/filter/config"]
    probes = dict(await asyncio.gather(*[probe(p) for p in paths]))
    return {"tabs": tabs, "filter_tests": tests, "probes": probes}


@app.get("/peek")
async def peek(tab: str = ""):
    """Debug: open /peek in the browser to see the raw platformList, the Categories (FILTER) block and one sample section."""
    d = await call(_home_url(tab))
    data = d.get("data") or {}
    ops = data.get("operatingList") or []
    flt = next((op for op in ops if op.get("type") == "FILTER"), {})
    smp = next((op for op in ops if op.get("type") == "SUBJECTS_MOVIE"), {})
    trim = lambda op: {k: (v[:1] if k == "subjects" and isinstance(v, list) else v) for k, v in op.items()}
    out = {"platformList": data.get("platformList"), "filter_block": trim(flt), "sample_section": trim(smp)}
    return Response(json.dumps(out, ensure_ascii=False)[:30000], media_type="application/json")


@app.get("/raw")
async def raw(p: str):
    """Debug: view any MovieBox API path directly. /raw?p=%2Fhome%3Fhost%3Dmoviebox.ph"""
    if not p.startswith("/"):
        return JSONResponse({"error": "p must start with '/'"}, status_code=400)
    d = await call(API + p)
    s = json.dumps(d, ensure_ascii=False)
    return Response(s[:60000], media_type="application/json")


# ===== Content-type endpoints (modelled on the real MovieBox site: TV show / Movie / Animation / Most Watched / ...) =====
# Filter values below are copied from the real site's /web/film and /web/tv-series filter panels.
TYPES = {"movie": "1", "tv": "2", "anime": "4"}  # web API channelId (verified earlier by the phone test)
FILTERS = {
    "genre": ["All", "Action", "Adventure", "Animation", "Biography", "Comedy", "Crime", "Documentary", "Drama", "Family", "Fantasy", "Film-Noir", "Game-Show", "History", "Horror", "Music", "Musical", "Mystery", "News", "Reality-TV", "Romance", "Sci-Fi", "Short", "Sport", "Talk-Show", "Thriller", "War", "Western", "Other"],
    "country": ["All", "United States", "United Kingdom", "Korea", "Japan", "Bangladesh", "China", "Egypt", "France", "Germany", "India", "Indonesia", "Iraq", "Italy", "Ivory Coast", "Kenya", "Lebanon", "Mexico", "Morocco", "Nigeria", "Pakistan", "Philippines", "Russia", "Saudi Arabia", "South Africa", "Spain", "Syria", "Thailand", "Malaysia", "Turkey", "Other"],
    "year": ["All", "2026", "2025", "2024", "2023", "2022", "2021", "2020", "2010s", "2000s", "1990s", "1980s", "Other"],
    "language": ["All", "English dub", "French dub", "Hindi dub", "Bengali dub", "Urdu dub", "Punjabi dub", "Tamil dub", "Telugu dub", "Malayalam dub", "Kannada dub", "Arabic dub", "Arabic sub", "Tagalog dub", "Indonesian dub", "Russian dub", "Kurdish sub", "Spanish dub", "Spanish sub", "SpanishLatam dub"],
    "sort": ["ForYou", "Hottest", "Latest", "Rating"],
}


@app.get("/meta/filters")
async def meta_filters():
    """All filter options + content types, so the frontend does not need to hard-code them."""
    return {"types": list(TYPES), "filters": FILTERS,
            "pages": {"movie": "/web/movie", "tv": "/web/tv-series", "anime": "/web/animated-series",
                      "midnight": "/web/midnight (18+, disabled unless ENABLE_MIDNIGHT=1)", "most_watched": "/ranking-list"}}


@app.get("/browse")
async def browse(type: str = "movie", genre: str = "All", country: str = "All", year: str = "All",
                 language: str = "All", sort: str = "ForYou", page: int = 1, per: int = 24):
    """One clean endpoint for every video type: type = movie | tv | anime."""
    ch = TYPES.get(type)
    if not ch:
        return JSONResponse({"error": "type must be one of " + ", ".join(TYPES)}, status_code=400)
    if type == "anime":  # channel 4 is not anime (phone test); anime = series channel + Japan
        ch = "2"
        if country == "All":
            country = "Japan"
    body = {"channelId": ch, "page": page, "perPage": per, "genre": genre, "country": country,
            "year": year, "sort": sort, "classify": language}
    d = await call(f"{API}/subject/filter", body)
    return {"type": type, "items": _extract(d), "page": page, "pager": (d.get("data") or {}).get("pager"),
            "_debug": d.get("_http") or d.get("_err")}


@app.get("/ranking")
async def ranking(id: str = "", page: int = 1, per: int = 24):
    """Most Watched (/ranking-list). With id -> that ranking's titles; without -> the list of rankings."""
    if id:
        d = await call(f"{API}/ranking-list/content?id={quote(id, safe='')}&page={page}&perPage={per}")
        return {"items": _extract(d), "page": page, "_debug": d.get("_http") or d.get("_err")}
    # Verified on the live server: GET /ranking-list -> data.rankingList = [{name, id, path}, ...] (TOP Movies, Cinema, Bollywood, South Indian, Hollywood, ...)
    d = await call(f"{API}/ranking-list")
    rl = (d.get("data") or {}).get("rankingList") or []
    return {"rankings": [{"name": r.get("name"), "id": str(r.get("id")), "path": r.get("path")} for r in rl if isinstance(r, dict) and r.get("id")],
            "_debug": d.get("_http") or d.get("_err")}


# ===== Real MovieBox tabs: Movie / TV Show / Anime (rows like the MovieBox site) =====
# Scan result: tab-operating?tabId=ONEROOM_MOVIE works (14 rows). ONEROOM_TV / ONEROOM_ANIME give HTTP 400,
# so TV and Anime rows are built from /subject/filter (channelId 2 and 4) + the matching home rows.
_TABCACHE = {}


async def _frow(title, ch, **kw):
    body = {"channelId": ch, "page": 1, "perPage": 18, "genre": "All", "country": "All", "year": "All", "sort": "ForYou", "classify": "All"}
    body.update(kw)
    d = await call(f"{API}/subject/filter", body)
    its = _extract(d)
    q = "type=/home/movieFilter&tabId=%s&filterType=%s" % ({"1": "2", "2": "5", "4": "8"}[ch], json.dumps(
        {"classify": body["classify"], "country": body["country"], "genre": body["genre"], "sort": body["sort"], "year": body["year"]}))
    return {"section": title, "items": its, "more": {"query": q}, "tabs": None, "kind": None, "query": q}


# Phone test result: channelId 4 is NOT anime (returns random films/shows), and "Top Rated" sort returns junk.
# Anime = channel 2 (series) + country Japan (verified: Naruto, Demon Slayer, Spy x Family, Tokyo Revengers),
# anime movies = channel 1 + country Japan. Rows that come back empty are dropped automatically.
_TAB_ROWS = {
    "tv": [("Hottest TV Shows", "2", {"sort": "Hottest"}), ("Hindi Dubbed Series", "2", {"classify": "Hindi dub"}),
           ("Latest Releases", "2", {"sort": "Latest"}), ("Korean Dramas", "2", {"country": "Korea"}),
           ("Indian Series", "2", {"country": "India"}), ("US Series", "2", {"country": "United States"}),
           ("Crime", "2", {"genre": "Crime", "sort": "Hottest"}), ("Romance", "2", {"genre": "Romance", "sort": "Hottest"}),
           ("Comedy", "2", {"genre": "Comedy", "sort": "Hottest"}), ("Thriller", "2", {"genre": "Thriller", "sort": "Hottest"}),
           ("Sci-Fi", "2", {"genre": "Sci-Fi", "sort": "Hottest"})],
    "anime": [("Hottest Anime", "2", {"country": "Japan", "sort": "Hottest"}),
              ("Hindi Dubbed Anime", "2", {"country": "Japan", "classify": "Hindi dub", "sort": "Hottest"}),
              ("Latest Anime", "2", {"country": "Japan", "sort": "Latest"}),
              ("Anime Movies", "1", {"country": "Japan", "sort": "Hottest"}),
              ("Hindi Dubbed Anime Movies", "1", {"country": "Japan", "classify": "Hindi dub"}),
              ("Animation (Cartoons)", "2", {"genre": "Animation", "sort": "Hottest"}),
              ("Anime Action", "2", {"country": "Japan", "genre": "Action", "sort": "Hottest"}),
              ("Anime Adventure", "2", {"country": "Japan", "genre": "Adventure", "sort": "Hottest"}),
              ("Anime Comedy", "2", {"country": "Japan", "genre": "Comedy", "sort": "Hottest"}),
              ("Anime Romance", "2", {"country": "Japan", "genre": "Romance", "sort": "Hottest"}),
              ("Anime Fantasy", "2", {"country": "Japan", "genre": "Fantasy", "sort": "Hottest"})],
}
_TAB_HOME_ROWS = {"tv": re.compile(r"series|drama|tv|show", re.I), "anime": re.compile(r"anime|animation", re.I)}


@app.get("/tab/{name}")
async def tab_page(name: str):
    """name = movie | tv | anime. Same shape as /home ({sections: [...]}), so the frontend draws it with the same code."""
    name = name.lower()
    if name not in ("movie", "tv", "anime"):
        return JSONResponse({"error": "name must be movie, tv or anime"}, status_code=400)
    c = _TABCACHE.get(name)
    if c and time.time() - c[0] < 300:
        return c[1]
    secs = []
    if name == "movie":
        d = await call(f"{API}/tab-operating?tabId=ONEROOM_MOVIE")
        seen = set()
        for s_ in _sections(d):   # MovieBox's own rows; the same row (e.g. Trending in Cinema) comes twice -> keep once
            key = (s_["section"], str((s_.get("more") or {}).get("genreTopId") or ""))
            if key in seen or (not s_["items"] and s_.get("kind") != "filter"):
                continue
            seen.add(key)
            if s_.get("kind") == "filter" and s_.get("tabs"):
                s_["tabs"] = [t for t in s_["tabs"] if t.get("query")]
            secs.append(s_)
        if not any(x["items"] for x in secs):  # fallback if the tab call fails
            res = await asyncio.gather(*[_frow(t, "1", **kw) for t, kw in [("Hottest Movies", {"sort": "Hottest"}), ("Hindi Dubbed Movies", {"classify": "Hindi dub"}), ("Latest Releases", {"sort": "Latest"})]])
            secs = [r for r in res if r["items"]]
    else:
        res = await asyncio.gather(*[_frow(t, ch, **kw) for t, ch, kw in _TAB_ROWS[name]])
        secs = [r for r in res if r["items"]]
        h = await call(_home_url())   # plus the matching rows of MovieBox's own home (Top Anime, Best Asian Series, Western TV ...)
        extra = [s_ for s_ in _sections(h) if s_.get("kind") != "filter" and s_["section"] != "Banner" and s_["items"]
                 and _TAB_HOME_ROWS[name].search(str(s_["section"])) and "short" not in str(s_["section"]).lower()]
        secs = extra + secs
    out = {"sections": secs, "tabs": [], "platforms": [], "type": name}
    if secs:
        _TABCACHE[name] = (time.time(), out)
    return out


@app.get("/midnight/status")
async def midnight_status():
    return {"enabled": os.getenv("ENABLE_MIDNIGHT") == "1"}


@app.get("/midnight")
async def midnight(page: int = 0):
    """MovieBox's 'Midnight' section is adult (18+) content. Off by default; the site owner must set ENABLE_MIDNIGHT=1."""
    if os.getenv("ENABLE_MIDNIGHT") != "1":
        return JSONResponse({"error": "Midnight (18+) is disabled. Set ENABLE_MIDNIGHT=1 to enable it."}, status_code=403)
    # Verified on the phone scan: /tab-operating?tabId=ONEROOM_MIDNIGHT -> HTTP 200 with ~19 rows.
    # (The old code looked for a "Midnight" tab inside the /home response; that tab does not exist there.)
    d = await call(f"{API}/tab-operating?tabId=ONEROOM_MIDNIGHT")
    secs = [x for x in _sections(d) if x["items"]]
    return {"sections": secs, "tabs": [], "platforms": [], "_debug": d.get("_http") or d.get("_err")}


@app.get("/search")
async def search(q: str = Query(..., min_length=1), page: int = 1):
    d = await call(f"{API}/subject/search", {"keyword": q, "page": page, "perPage": 24})
    inner = d.get("data") or {}
    return {"items": [_item(s) for s in inner.get("items") or inner.get("list") or []]}


@app.get("/detail/{slug}")
async def detail(request: Request, slug: str):
    protect.after_detail(request, slug)
    urls = [f"{API}/detail?detailPath={slug}", f"{API}/detail?detailPath={slug}&host={HOST}"]
    d = await call(urls[0])
    if not (d.get("data") or {}).get("subject"):  # retry with a fresh token, then with the host parameter
        await ensure_token(True)
        for u in urls:
            d = await call(u)
            if (d.get("data") or {}).get("subject"):
                break
    return d


def _pick_worker(c):
    """VIDEO_WORKER can hold several Worker URLs, comma separated (e.g. one per Cloudflare account).
    A viewer always gets the same one (hash of device id / IP), so the load is split evenly."""
    import hashlib
    ws = _worker_bases()
    if not ws:
        return ""
    k = (c.get("dev") or c.get("ip") or "") if c else ""
    return ws[int(hashlib.md5(k.encode("utf-8", "ignore")).hexdigest(), 16) % len(ws)]


def _px(u, c, sess=None, bind=False):
    """Signed video link.  VIDEO_WORKER=https://xxx.workers.dev -> the Worker carries the bytes (not this server).
    bind=True also ties the link to the browser (X-Device) - only for hls.js, a plain <video> cannot send that header."""
    l = protect.link(u, c, sess, bind_dev=bind)
    w = _pick_worker(c)
    return (w + l + "&q=" + protect.enc(_ref["v"])) if w else PUBLIC_BASE + l      # referer is hidden too (q=)


def _mbw(spec, c, sess=None, bind=False):
    """WORKER_RESOLVE=1: the link carries only WHAT to play (subject / episode / quality). The Worker asks MovieBox for the
    signed video link itself, so the link and the video request come from the same Cloudflare IP."""
    u = "mb:" + json.dumps(spec, separators=(",", ":"))
    return _pick_worker(c) + protect.link(u, c, sess, bind_dev=bind) + "&q=" + protect.enc(_ref["v"])


async def _dbg_probe(items):
    """DEBUG_STREAM=1: ask the video server for EVERY mp4 quality (same urls the player gets), with and without Referer,
    and log DNS ips + final host + headers -> [STREAM-DBG]."""
    import socket
    from urllib.parse import urlparse as _up, parse_qs as _pq
    for label, u in items:
        try:
            p = _up(u)
            try:
                ips = sorted({a[4][0] for a in await asyncio.get_running_loop().getaddrinfo(p.hostname, 443, proto=socket.IPPROTO_TCP)})
            except Exception as e:
                ips = ["dns-err " + repr(e)[:40]]
            info = "%s host=%s ips=%s qkeys=%s" % (label, p.netloc, ",".join(ips), ",".join(sorted(_pq(p.query).keys())))
            for vname, h in (
                ("ref+origin", {"User-Agent": UA, "Referer": _ref["v"], "Origin": _ref["v"].rstrip("/"), "Accept": "*/*", "Range": "bytes=0-15"}),
                ("no-referer", {"User-Agent": UA, "Accept": "*/*", "Range": "bytes=0-15"}),
            ):
                async with httpx.AsyncClient(follow_redirects=True, timeout=20, **CK) as c:
                    r = await c.get(u, headers=h)
                hh = ";".join("%s=%s" % (k, r.headers.get(k)) for k in ("server", "cf-ray", "via", "x-cache", "retry-after", "content-range") if r.headers.get(k))
                print("[STREAM-DBG] %s | %s -> %s final=%s redirects=%d ctype=%s hdr=[%s] first=%r IN_PROXY=%s"
                      % (info, vname, r.status_code, _up(str(r.url)).netloc, len(r.history), r.headers.get("content-type"), hh, r.content[:12], bool(PROXY)), flush=True)
        except Exception as e:
            print("[STREAM-DBG] probe failed", label, repr(e)[:200], flush=True)


@app.get("/api/stream/{subject_id}")
async def stream(request: Request, subject_id: str, detail_path: str, se: int = 0, ep: int = 0, hj: int = 0):
    c = protect.ctx(request)
    user = await _me(request)
    refuse = protect.stream_gate(request, user, subject_id, detail_path, se, ep)
    if refuse is not None:
        return JSONResponse(refuse[1], status_code=refuse[0])
    sess = protect.new_session(c)
    dd = await call(f"{API}/media-player/get-domain")
    dom = (dd.get("data") if isinstance(dd.get("data"), str) else "") or "https://netfilm.world"
    dom = dom.rstrip("/")
    ref = f"{dom}/spa/videoPlayPage/movies/{detail_path}?id={subject_id}&type=/movie/detail&detailSe={se}&detailEp={ep}&lang=en"
    _ref["v"] = dom + "/"
    play = f"{dom}/wefeed-h5api-bff/subject/play?subjectId={subject_id}&se={se}&ep={ep}&detailPath={detail_path}"
    PH = {"User-Agent": UA, "Accept": "application/json", "Referer": ref, "X-Client-Info": XCI, "Accept-Language": "en-IN,en;q=0.9", **INH}
    _relayed = await _relay_play(subject_id, detail_path, se, ep)
    _via_relay = bool(_relayed)   # stream url was issued to the Space's IP -> only the Space may fetch it
    pr = {}
    if _relayed:
        pd, _rdom = _relayed
        if _rdom:
            dom = _rdom
    else:
        pr = await call(play, hdr=PH)
        pd = pr.get("data") or {}
        if not pd.get("hasResource"):  # retry once with a fresh token
            await ensure_token(True)
            pr = await call(play, hdr=PH)
            pd = pr.get("data") or {}
    used = (se, ep)
    if not pd.get("hasResource"):
        # Shorts (short dramas) and some series number their episodes differently (season 0 or 1, episode 0 or 1):
        # try the other numberings before giving up
        alts = []
        if ep == 0:
            alts += [(1, 1), (0, 1)]
        if se == 0 and ep > 0:
            alts.append((1, ep))
        if se > 0:
            alts.append((0, ep))
        for se2, ep2 in alts[:3]:
            if (se2, ep2) == (se, ep):
                continue
            ref2 = f"{dom}/spa/videoPlayPage/movies/{detail_path}?id={subject_id}&type=/movie/detail&detailSe={se2}&detailEp={ep2}&lang=en"
            play2 = f"{dom}/wefeed-h5api-bff/subject/play?subjectId={subject_id}&se={se2}&ep={ep2}&detailPath={detail_path}"
            _relayed2 = await _relay_play(subject_id, detail_path, se2, ep2)
            r2 = {}
            if _relayed2:
                d2 = _relayed2[0]
            else:
                r2 = await call(play2, hdr={**PH, "Referer": ref2})
                d2 = r2.get("data") or {}
            if d2.get("hasResource"):
                pr, pd, used = r2, d2, (se2, ep2)
                break
    src = []
    _rs = os.environ.get("WORKER_RESOLVE") == "1" and bool(_worker_bases())
    _base = {"s": subject_id, "d": detail_path, "se": used[0], "ep": used[1], "dom": dom}
    for i, x in enumerate(pd.get("hls") or []):  # hls items can be dicts or strings
        u = x.get("url") if isinstance(x, dict) else x
        if u:
            _l = _mbw({**_base, "l": "hls", "n": i}, c, sess, bind=bool(hj)) if _rs else _px(u, c, sess, bind=bool(hj))
            src.append({"kind": "hls", "label": "Auto (HLS)", "res": 9999, "url": _l})
    for j, s in enumerate(pd.get("streams") or []):
        if s.get("url"):
            res = int(s.get("resolutions") or 0)
            _m3 = ".m3u8" in s["url"]
            _l = _mbw({**_base, "l": "streams", "n": j, "r": res, "m": _m3}, c, sess, bind=bool(hj) and _m3) if _rs else _px(s["url"], c, sess, bind=bool(hj) and _m3)
            src.append({"kind": "hls" if _m3 else "mp4", "label": f"{res}p", "res": res, "url": _l})
    # The "streams" links are on the bcdnxw host, which answers 427 to Cloudflare IPs (= the Worker).  The download API gives the same
    # movie on bcdnw, which Cloudflare IPs can fetch.  With a Worker, use those links for the qualities that have one (others stay as they are).
    # DL_LINKS=0 turns this off.
    if _worker_bases() and os.environ.get("DL_LINKS") != "0":
        try:
            if _via_relay:
                _dl = await _relay_download(subject_id, detail_path, used[0], used[1]) or {}
            else:
                _dl = await call(f"{dom}/wefeed-h5api-bff/subject/download?subjectId={subject_id}&se={used[0]}&ep={used[1]}&detailPath={detail_path}", hdr={**PH, "Referer": ref})
            _dsrc = []
            for x in ((_dl.get("data") or {}).get("downloads") or []):
                if isinstance(x, dict) and x.get("url"):
                    _r = int(x.get("resolution") or 0)
                    if _r:
                        _dsrc.append({"kind": "mp4", "label": f"{_r}p", "res": _r, "url": _px(x["url"], c, sess, bind=False)})
            if _dsrc:
                _have = {d_["res"] for d_ in _dsrc}
                src = [x for x in src if not (x["kind"] == "mp4" and x["res"] in _have)]
                # qualities with no download link (usually 1080p) can not be fetched by the Worker (bcdnxw answers 427 to Cloudflare IPs),
                # so they go through THIS server instead (uses this server's bandwidth, only when a viewer picks that quality).  DL_DIRECT=0 = keep them on the Worker.
                if _via_relay and os.environ.get("DL_KEEP_STREAMS") != "1":
                    src = [x for x in src if x["kind"] != "mp4"]   # bcdnxw answers 426 to server IPs, only the bcdnw links are playable
                if os.environ.get("DL_DIRECT") != "0" and not _via_relay and not _rs:   # _rs (WORKER_RESOLVE=1): Wispbyte resolves these itself, they must NOT go back through this server
                    for s_ in (pd.get("streams") or []):
                        _r = int(s_.get("resolutions") or 0)
                        if s_.get("url") and ".m3u8" not in s_["url"] and _r not in _have:
                            src = [x for x in src if not (x["kind"] == "mp4" and x["res"] == _r)]
                            src.append({"kind": "mp4", "label": f"{_r}p", "res": _r, "url": protect.link(s_["url"], c, sess, bind_dev=False)})
                src += _dsrc
        except Exception:
            pass
    src.sort(key=lambda x: -x["res"])
    if DIRECT_VIDEO and not _via_relay:
        # direct links first (the browser talks to the CDN itself); the same qualities again as "backup" (through this server)
        _d, _b = [], []
        for x_ in (pd.get("hls") or []):
            u_ = x_.get("url") if isinstance(x_, dict) else x_
            if u_:
                _fb = _px(u_, c, sess, bind=bool(hj))
                _d.append({"kind": "hls", "label": "Auto (HLS)", "res": 9999, "url": u_, "fb": _fb})
                _b.append({"kind": "hls", "label": "Auto (HLS) backup", "res": 9999, "url": _fb, "backup": True})
        for s_ in (pd.get("streams") or []):
            u_ = s_.get("url")
            if u_:
                r_ = int(s_.get("resolutions") or 0)
                m_ = ".m3u8" in u_
                k_ = "hls" if m_ else "mp4"
                _fb = _px(u_, c, sess, bind=bool(hj) and m_)
                _d.append({"kind": k_, "label": "%sp" % r_, "res": r_, "url": u_, "fb": _fb})
                _b.append({"kind": k_, "label": "%sp backup" % r_, "res": r_, "url": _fb, "backup": True})
        _d.sort(key=lambda x: -x["res"])
        _b.sort(key=lambda x: -x["res"])
        src = _d + _b
    if os.environ.get("DEBUG_STREAM") == "1":
        _items = [("%sp" % (x_.get("resolutions") or "?"), x_["url"]) for x_ in (pd.get("streams") or []) if x_.get("url") and ".m3u8" not in x_["url"]]
        if _items:
            asyncio.create_task(_dbg_probe(_items))
    st = (pd.get("streams") or pd.get("dash") or [None])[0] or {}
    cap = {"id": st.get("id"), "fmt": st.get("format") or "MP4",
           "ids": list(dict.fromkeys(str(x_.get("id")) for x_ in ((pd.get("streams") or []) + (pd.get("dash") or [])) if isinstance(x_, dict) and x_.get("id")))[:8]}
    why = None
    if not src:   # the real reason, shown in the player (urls / upstream host names are masked)
        def _m(x):
            return _UP_HOST.sub("upstream", re.sub(r"https?://\S+", "<url>", str(x)))[:160]
        try:
            why = "play(se=%s,ep=%s tried alts) http=%s err=%s code=%s msg=%s hasResource=%s keys=%s hls=%d streams=%d dash=%d" % (se, ep, 
                pr.get("_http") or 200, _m(pr.get("_err") or "-"), pr.get("code", "-"), _m(pr.get("message") or pr.get("msg") or pr.get("_body") or "-"),
                pd.get("hasResource"), ",".join(sorted(map(str, pd.keys())))[:80] or "-",
                len(pd.get("hls") or []), len(pd.get("streams") or []), len(pd.get("dash") or []))
        except Exception as e:
            why = "diag failed: " + _m(e)
    return {"has_resource": bool(src), "sources": src, "note": None if src else "No stream was found for this title.", "why": why, "cap": cap, "_domain": dom}


# ---- client-side resolve: the PHONE asks MovieBox itself (token + play links) and this server only SIGNS the links ----
# (so the token / play request does not cost this server anything, and is faster for the viewer).  The links are then carried by the
# Wispbyte relay as before (Referer swap).  Only https CDN hosts listed in CLIENT_CDN_HOSTS are signed (default hakunaymatata.com and
# its sub-domains), so /api/sign can never turn this site into an open proxy.  The same stream_gate (captcha / limits) runs first.
# CLIENT_RESOLVE=0 switches it off (the page then uses /api/stream as before).
CLIENT_RESOLVE = os.getenv("CLIENT_RESOLVE", "1") != "0"
CLIENT_CDN_HOSTS = [h.strip().lower() for h in os.getenv("CLIENT_CDN_HOSTS", "hakunaymatata.com").split(",") if h.strip()]


def _cdn_ok(u):
    try:
        sp = urlsplit(u)
        h = (sp.hostname or "").lower()
        return sp.scheme == "https" and bool(h) and protect.safe_url(u) and any(h == d or h.endswith("." + d) for d in CLIENT_CDN_HOSTS)
    except Exception:
        return False


@app.post("/api/sign")
async def sign_links(request: Request):
    if not CLIENT_RESOLVE:
        return JSONResponse({"error": "off"}, status_code=404)
    try:
        b = await request.json()
        assert isinstance(b, dict)
    except Exception:
        return JSONResponse({"error": "bad request"}, status_code=400)
    subject_id, detail_path = str(b.get("id") or ""), str(b.get("detail_path") or "")
    try:
        se, ep = int(b.get("se") or 0), int(b.get("ep") or 0)
    except Exception:
        se, ep = 0, 0
    items = b.get("items")
    if not subject_id or not detail_path or not isinstance(items, list):
        return JSONResponse({"error": "bad request"}, status_code=400)
    c = protect.ctx(request)
    user = await _me(request)
    refuse = protect.stream_gate(request, user, subject_id, detail_path, se, ep)
    if refuse is not None:
        return JSONResponse(refuse[1], status_code=refuse[0])
    sess = protect.new_session(c)
    hj = bool(b.get("hj"))
    src = []
    for x in items[:40]:
        u = x.get("u") if isinstance(x, dict) else None
        if not isinstance(u, str) or not _cdn_ok(u):
            continue
        m3 = ".m3u8" in u.split("?")[0].lower()
        try:
            res = int(x.get("res") or 0)
        except Exception:
            res = 0
        if m3 and x.get("auto"):
            src.append({"kind": "hls", "label": "Auto (HLS)", "res": 9999, "url": _px(u, c, sess, bind=hj)})
        else:
            src.append({"kind": "hls" if m3 else "mp4", "label": "%sp" % res, "res": res, "url": _px(u, c, sess, bind=hj and m3)})
    src.sort(key=lambda y: -y["res"])
    cp = b.get("cap") if isinstance(b.get("cap"), dict) else {}
    cap = {"id": (str(cp.get("id"))[:64] if cp.get("id") is not None else None), "fmt": str(cp.get("fmt") or "MP4")[:16],
           "ids": [str(i)[:64] for i in (cp.get("ids") or [])[:8]] if isinstance(cp.get("ids"), list) else []}
    return {"has_resource": bool(src), "sources": src, "note": None if src else "No stream was found for this title.", "why": None, "cap": cap, "_domain": _ref["v"].rstrip("/")}


# ---- http first for /p: if the CDN accepts plain http:// this server needs no TLS decrypt for the video bytes ----
# HTTP_FIRST=1 (default) / 0 = always https.  Result remembered per CDN host for HTTP_TTL seconds (default 24 h):
#   works -> http for 24 h ; refused -> https for 24 h ; then ONE new test.  One failed http request while http is
#   marked "works" is repeated over https only for that request (the mark stays).
HTTP_FIRST = os.getenv("HTTP_FIRST", "1") != "0"
HTTP_TTL = int(os.getenv("HTTP_TTL", "86400"))
_HTTP_MEM = {}          # host -> (True/False, time of the test)


def _http_mode(host):
    m = _HTTP_MEM.get(host)
    if not m or time.time() - m[1] > HTTP_TTL:
        return "test"
    return "http" if m[0] else "https"


def _to_http(u):
    sp = urlsplit(u)
    host = sp.hostname or ""
    if ":" in host:
        host = "[" + host + "]"
    port = sp.port
    return "http://" + host + (":%d" % port if port and port != 443 else "") + (sp.path or "/") + (("?" + sp.query) if sp.query else "")


async def _try_http(u, h):
    """-> (client, response) when the CDN answers a plain 200/206 body over http://, else None"""
    host = urlsplit(u).hostname or ""
    mode = _http_mode(host)
    if mode == "https":
        return None
    c2 = httpx.AsyncClient(follow_redirects=False, timeout=30, **CK)
    ok = False
    r2 = None
    try:
        r2 = await c2.send(c2.build_request("GET", _to_http(u), headers=h), stream=True)
        ok = r2.status_code in (200, 206) and "mpegurl" not in r2.headers.get("content-type", "").lower()
    except Exception:
        ok = False
    if mode == "test":
        _HTTP_MEM[host] = (ok, time.time())
        print("[proxy] http test %s: %s" % (host, "works (no TLS decrypt)" if ok else "refused - https"), flush=True)
    if ok:
        return c2, r2
    try:
        if r2 is not None:
            await r2.aclose()
    finally:
        await c2.aclose()
    return None


@app.get("/p")
async def proxy(request: Request, u: str = "", t: str = "", e: str = ""):
    if e:
        u = protect.dec(e)
    if not u:
        return Response("forbidden", status_code=403, headers={"Cache-Control": "no-store"})
    pc = protect.ctx(request)
    if not pc["vip"]:
        ok, why = protect.verify(pc, u, t, "s")
        if not ok or not protect.safe_url(u):
            return Response("forbidden", status_code=403, headers={"Cache-Control": "no-store"})
    h = {"User-Agent": UA, "Referer": _ref["v"], "Origin": _ref["v"].rstrip("/"), "Accept": "*/*"}
    if request.headers.get("range"):
        h["Range"] = request.headers["range"]
    c = r = None
    if HTTP_FIRST and u.lower().startswith("https://") and ".m3u8" not in u.split("?")[0].lower():
        got = await _try_http(u, h)
        if got:
            c, r = got
    if r is None:
        c = httpx.AsyncClient(follow_redirects=True, timeout=30, **CK)
        try:
            r = await c.send(c.build_request("GET", u, headers=h), stream=True)
        except Exception as e:
            await c.aclose()
            return Response("bad gateway", status_code=502, headers={"Cache-Control": "no-store"})
    ct = r.headers.get("content-type", "").lower()
    if "mpegurl" in ct or u.split("?")[0].endswith(".m3u8"):
        text = (await r.aread()).decode("utf-8", "ignore")
        base = str(r.url)
        await r.aclose(); await c.aclose()
        fix = lambda x: protect.link_like(urljoin(base, x.strip()), pc, t)
        lines = []
        for ln in text.splitlines():
            if ln.startswith("#"):
                ln = re.sub(r'URI="([^"]+)"', lambda m: 'URI="' + fix(m.group(1)) + '"', ln)
            elif ln.strip():
                ln = fix(ln)
            lines.append(ln)
        return Response("\n".join(lines), media_type="application/vnd.apple.mpegurl", headers={"Cache-Control": "no-store"})
    keep = {k: v for k, v in r.headers.items() if k.lower() in ("content-type", "content-length", "content-range", "accept-ranges")}

    async def gen():
        try:
            async for chunk in r.aiter_raw():
                yield chunk
        finally:
            await r.aclose(); await c.aclose()
    return StreamingResponse(gen(), status_code=r.status_code, headers=keep)


@app.get("/api/captions/{subject_id}")
async def captions(request: Request, subject_id: str, detail_path: str, id: str = "", fmt: str = "MP4", ids: str = ""):
    """ALL subtitle languages: the caption list is asked for every stream id of the title (each quality can carry a
    different set) and merged; the same language is listed once."""
    c = protect.ctx(request)
    idl = list(dict.fromkeys([i for i in ([id] + ids.split(",")) if i.strip()]))[:8]
    if not idl:
        return {"captions": []}
    from urllib.parse import quote
    res = await asyncio.gather(*[call(f"{API}/subject/caption?format={quote(fmt)}&id={quote(i)}&subjectId={quote(subject_id)}&detailPath={quote(detail_path)}") for i in idl])
    out, seen = [], set()
    for d in res:
        cd = d.get("data") if isinstance(d, dict) else None
        caps = (cd.get("captions") if isinstance(cd, dict) else cd) or []
        for cap in caps:
            if not (isinstance(cap, dict) and cap.get("url")):
                continue
            lang = cap.get("lanName") or cap.get("lan") or "Subtitle"
            key = (str(cap.get("lan") or lang)).lower()
            if key in seen:
                continue
            seen.add(key)
            out.append({"lang": lang, "url": PUBLIC_BASE + protect.link(cap["url"], c, None, "s", "/sub")})
    out.sort(key=lambda x: (x["lang"].lower() not in ("english", "hindi"), x["lang"]))
    return {"captions": out}


@app.get("/sub")
async def sub(request: Request, u: str = "", t: str = "", e: str = ""):
    if e:
        u = protect.dec(e)
    if not u:
        return Response("forbidden", status_code=403)
    pc = protect.ctx(request)
    if not pc["vip"]:
        ok, why = protect.verify(pc, u, t, "s")
        if not ok or not protect.safe_url(u):
            return Response("forbidden", status_code=403)
    """Fetch subtitles and convert SRT -> WebVTT (the browser <track> element only understands VTT)."""
    async with httpx.AsyncClient(follow_redirects=True, timeout=30, **CK) as c:
        try:
            r = await c.get(u, headers={"User-Agent": UA, "Referer": _ref["v"]})
        except Exception:
            return Response("bad gateway", status_code=502)
    t = r.content.decode("utf-8-sig", "ignore").replace("\r", "")
    if not t.lstrip().startswith("WEBVTT"):
        t = "WEBVTT\n\n" + re.sub(r"(\d\d:\d\d:\d\d),(\d{3})", r"\1.\2", t)
    return Response(t, media_type="text/vtt; charset=utf-8")


# ---------------- /dl : download ----------------
def _dh():
    return {"User-Agent": UA, "Referer": _ref["v"], "Origin": _ref["v"].rstrip("/"), "Accept": "*/*"}


def _fname(name, ext):
    n = re.sub(r"[^\w\- ]+", "", name or "").strip().replace(" ", "_") or "video"
    return n + ext


async def _hls_plan(c, u):
    """master/media playlist -> (segments, init, error). For a master playlist, the highest-bandwidth variant is used."""
    t, base = "", u
    for _ in range(3):
        r = await c.get(u, headers=_dh())
        if r.status_code != 200:
            return None, None, f"Playlist returned {r.status_code}"
        t, base = r.text, str(r.url)
        if "#EXT-X-STREAM-INF" not in t:
            break
        lines, best, bw = t.splitlines(), None, -1
        for i, ln in enumerate(lines):
            if ln.startswith("#EXT-X-STREAM-INF"):
                m = re.search(r"BANDWIDTH=(\d+)", ln)
                b = int(m.group(1)) if m else 0
                nx = next((x.strip() for x in lines[i + 1:] if x.strip() and not x.startswith("#")), None)
                if nx and b > bw:
                    best, bw = urljoin(base, nx), b
        if not best:
            return None, None, "No variant found in the playlist"
        u = best
    lines = t.splitlines()
    if any(l.startswith("#EXT-X-KEY") and "METHOD=NONE" not in l for l in lines):
        return None, None, "This stream is encrypted and cannot be downloaded."
    m = re.search(r'#EXT-X-MAP:.*?URI="([^"]+)"', t)
    init = urljoin(base, m.group(1)) if m else None
    segs = [urljoin(base, x.strip()) for x in lines if x.strip() and not x.startswith("#")]
    if not segs:
        return None, None, "The playlist is empty"
    return segs, init, None


async def _dl_hls(u, name, check, done=None):
    async with httpx.AsyncClient(follow_redirects=True, timeout=30, **CK) as c:
        try:
            segs, init, err = await _hls_plan(c, u)
        except Exception as e:
            segs, init, err = None, None, "download failed"
    if err:
        return JSONResponse({"ok": False, "error": err}, status_code=400)
    if check:
        return {"ok": True, "segments": len(segs)}
    ext = ".mp4" if init else ".ts"

    async def gen():
        try:
            async with httpx.AsyncClient(follow_redirects=True, timeout=40, **CK) as c:
                for s in ([init] if init else []) + segs:
                    for _ in range(3):
                        try:
                            r = await c.get(s, headers=_dh())
                            if r.status_code == 200:
                                yield r.content
                                break
                        except Exception:
                            pass
                        await asyncio.sleep(1)
                    else:
                        return  # segment failed 3 times: stop the download here
        finally:
            if done:
                done()
    return StreamingResponse(gen(), media_type="application/octet-stream",
                             headers={"Content-Disposition": f'attachment; filename="{_fname(name, ext)}"'})


@app.get("/dl")
async def download(request: Request, u: str = "", name: str = "video", check: int = 0, t: str = "", e: str = ""):
    if e:
        u = protect.dec(e)
    if not u.startswith("http"):
        return JSONResponse({"ok": False, "error": "Invalid link"}, status_code=400)
    pc = protect.ctx(request)
    if not pc["vip"]:
        ok, why = protect.verify(pc, u, t, "d")
        if not ok or not protect.safe_url(u):
            return JSONResponse({"ok": False, "error": "This download link has expired. Please press Download again."}, status_code=403)
    did = None
    if not check:
        did, n = protect.dl_begin(pc["ip"])
        if n > protect.guard.DL_MAX and not pc["vip"] and protect.guard.violation("dl_many", pc["ip"], "%d downloads at once" % n, dev=pc["dev"]):
            protect.dl_end(pc["ip"], did)
            return JSONResponse({"ok": False, "error": "Too many downloads at the same time. Please wait for one to finish."}, status_code=429)
    _done = (lambda: protect.dl_end(pc["ip"], did)) if did else None
    if ".m3u8" in u.split("?")[0].lower():
        r = await _dl_hls(u, name, check, _done)
        if _done and not isinstance(r, StreamingResponse):
            _done()
        return r
    c = httpx.AsyncClient(follow_redirects=True, timeout=30, **CK)
    try:
        r = await c.send(c.build_request("GET", u, headers=_dh()), stream=True)
    except Exception as e:
        await c.aclose()
        if _done:
            _done()
        return JSONResponse({"ok": False, "error": "download failed"}, status_code=502)
    ct = r.headers.get("content-type", "").lower()
    if r.status_code != 200 or "mpegurl" in ct:
        code = r.status_code
        await r.aclose(); await c.aclose()
        if "mpegurl" in ct:
            rr = await _dl_hls(u, name, check, _done)
            if _done and not isinstance(rr, StreamingResponse):
                _done()
            return rr
        if _done:
            _done()
        return JSONResponse({"ok": False, "error": f"Server returned {code}"}, status_code=502)
    if check:
        await r.aclose(); await c.aclose()
        return {"ok": True}
    hd = {"Content-Disposition": f'attachment; filename="{_fname(name, ".mp4")}"', "Content-Type": ct or "video/mp4"}
    if r.headers.get("content-length"):
        hd["Content-Length"] = r.headers["content-length"]

    async def gen():
        try:
            async for chunk in r.aiter_raw():
                yield chunk
        finally:
            await r.aclose(); await c.aclose()
            if _done:
                _done()
    return StreamingResponse(gen(), headers=hd)


@app.post("/api/dltok")
async def api_dltok(request: Request):
    """Download ticket: only for a signed-in user, only for a url this page was given (its stream link proves that)."""
    b = await _body(request)
    u, t = str(b.get("u", "")), str(b.get("t", ""))
    if u and not u.startswith("http"):      # the page sends the opaque e= text of its stream link
        u = protect.dec(u)
    user = await _me(request)
    if not user:
        return JSONResponse({"error": "Please sign in to download.", "login": True}, status_code=401)
    pc = protect.ctx(request)
    if not pc["vip"]:
        ok, why = protect.verify(pc, u, t, "s")
        if not ok or not protect.safe_url(u):
            return JSONResponse({"error": "This video link has expired. Please reload the video."}, status_code=403)
    nm = str(b.get("name", "video"))[:120]
    return {"url": PUBLIC_BASE + protect.link(u, pc, None, "d", "/dl") + "&name=" + quote(nm, safe="")}


# ===================== ACCOUNTS (JaatFlix's own database) =====================
import hmac, threading
ADMIN_KEY = os.getenv("ADMIN_KEY", "")


def _token(request: Request):
    a = request.headers.get("authorization") or ""
    return a[7:] if a.lower().startswith("bearer ") else ""


async def _body(request: Request):
    try:
        b = await request.json()
        return b if isinstance(b, dict) else {}
    except Exception:
        return {}


async def _me(request: Request):
    return await asyncio.to_thread(accounts.user_for, _token(request))


def _err(msg, code=400):
    return JSONResponse({"error": msg}, status_code=code)


@app.post("/api/signup")
async def api_signup(request: Request):
    b = await _body(request)
    uname = str(b.get("username", "")).strip()
    g = await asyncio.to_thread(protect.login_gate, request, uname, True)      # captcha every time + accounts per IP (DB)
    if g:
        return JSONResponse(g[1], status_code=g[0])
    tok, err = await asyncio.to_thread(accounts.signup, uname, str(b.get("password", "")), protect.signup_ipk(request))
    protect.login_note(request, uname, not err)
    if err:
        return _err(err)
    protect.signup_done(request)
    return {"token": tok, "user": await asyncio.to_thread(accounts.user_for, tok)}


@app.post("/api/login")
async def api_login(request: Request):
    b = await _body(request)
    uname = str(b.get("username", "")).strip()
    g = protect.login_gate(request, uname)
    if g:
        return JSONResponse(g[1], status_code=g[0])
    tok, err = await asyncio.to_thread(accounts.login, uname, str(b.get("password", "")))
    protect.login_note(request, uname, not err)
    if err:
        return _err(err)
    return {"token": tok, "user": await asyncio.to_thread(accounts.user_for, tok)}


# ---------------------------------------------------------------- captcha ----
# /api/captcha/new     -> {id, ttl, game:{mode:"text", img:"data:image/png;base64,..."}, pow:{salt,bits}}
# /api/captcha/verify  {id, pow, text} -> {ok:true, token, ttl} | {ok:false, why, retry:true}
# /api/captcha/status  -> {pass: bool, mode}
# The page sends the token in header X-Captcha; protect.ctx() checks it (signed, bound to the IP).
@app.get("/sw.js")
async def sw_js():
    """service worker: opens the relay's locked video bytes on the phone (see sw.js).  SW_OFF=1 = removes itself from every phone"""
    if os.getenv("SW_OFF", "0") == "1":
        off = "self.addEventListener('install',()=>self.skipWaiting());self.addEventListener('activate',e=>e.waitUntil(self.registration.unregister()));"
        return Response(off, media_type="application/javascript", headers={"Cache-Control": "no-cache"})
    return FileResponse("sw.js", media_type="application/javascript", headers={"Cache-Control": "no-cache"})


@app.get("/tlsdec.js")
async def tlsdec_js():
    return FileResponse("tlsdec.js", media_type="application/javascript", headers={"Cache-Control": "no-cache"})


@app.get("/captcha.js")
async def captcha_js():
    return FileResponse("captcha.js", media_type="application/javascript", headers={"Cache-Control": "public, max-age=3600"})


@app.get("/api/captcha/status")
async def captcha_status(request: Request):
    c = protect.ctx(request)
    return {"pass": bool(c["pass"]), "vip": bool(c["vip"]), "mode": protect.guard.mode(), "captcha": captcha.MODE}


@app.post("/api/captcha/{action}")
async def api_captcha(action: str, request: Request):
    if action not in ("new", "verify"):
        return _err("not found", 404)
    c = protect.ctx(request)
    b = await _body(request)
    if action == "new":
        g = await asyncio.to_thread(captcha.new, c["ip"], c["dev"])      # the picture is drawn with Pillow: off the event loop
        if not g:
            return _err("captcha error", 500)
        return g
    res = await asyncio.to_thread(captcha.verify, b.get("id"), c["ip"], b)
    if res.get("ok"):
        protect.after_captcha(request)           # a passed captcha wipes the bot score: no second one for the same old reason
    return res


# ---- TV pass (QR): the TV cannot play the captcha game, a phone plays it for the TV (see captcha.py "TV pass") ----
@app.get("/tv")
async def tv_page():
    return FileResponse("tv.html", media_type="text/html", headers={"Cache-Control": "no-cache"})


@app.post("/api/tv/new")
async def api_tv_new(request: Request):
    c = protect.ctx(request)
    r = await asyncio.to_thread(captcha.tv_new, c["ip"])
    if not r:
        return _err("TV pairing is busy, try again.", 429)
    return r


@app.post("/api/tv/poll")
async def api_tv_poll(request: Request):
    c = protect.ctx(request)
    b = await _body(request)
    return captcha.tv_poll(b.get("pid"), c["ip"])


@app.get("/api/tv/peek")
async def api_tv_peek(code: str = ""):
    return {"ok": bool(captcha.tv_peek(code))}


@app.post("/api/tv/finish")
async def api_tv_finish(request: Request):
    c = protect.ctx(request)
    b = await _body(request)
    ok, why = await asyncio.to_thread(captcha.tv_finish, b.get("code"), c["ip"], request.headers.get("x-captcha"))
    if not ok:
        return _err(why or "failed", 400)
    return {"ok": True}


@app.post("/api/logout")
async def api_logout(request: Request):
    await asyncio.to_thread(accounts.logout, _token(request))
    return {"ok": True}


@app.get("/api/me")
async def api_me(request: Request):
    u = await _me(request)
    if not u:
        return _err("Please sign in first.", 401)
    favs, prog = await asyncio.gather(asyncio.to_thread(accounts.get_favs, u["id"]),
                                      asyncio.to_thread(accounts.get_progress, u["id"]))
    return {"user": u, "progress": prog, "favs": favs}


_CLOG = {"t": 0.0, "n": 0}


@app.post("/api/clog")
async def clog(request: Request):
    """The browser reports a player error here -> it shows up in the server log as [CLIENT-ERR] (40 per minute at most)."""
    now = time.time()
    if now - _CLOG["t"] > 60:
        _CLOG["t"], _CLOG["n"] = now, 0
    _CLOG["n"] += 1
    if _CLOG["n"] <= 40:
        try:
            body = (await request.body())[:2500].decode("utf-8", "ignore")
            print("[CLIENT-ERR] ip=%s %s" % (protect.ctx(request)["ip"], re.sub(r"\s+", " ", body)), flush=True)
        except Exception:
            pass
    return {"ok": True}


@app.post("/api/progress")
async def api_progress(request: Request):
    u = await _me(request)
    if not u:
        return _err("Please sign in first.", 401)
    b = await _body(request)
    sid = str(b.get("sid", ""))[:60]
    if not sid:
        return _err("sid is required.")

    def _save():
        try:
            accounts.save_progress(u["id"], sid, b.get("season"), b.get("episode"), b.get("pos"), b.get("dur"), b)
            if float(b.get("dur") or 0) > 0 and float(b.get("pos") or 0) / float(b["dur"]) >= 0.85:
                accounts.mark_seen(u["id"], sid, b.get("season"), b.get("episode"))
        except Exception as e:
            print("[jf] progress save failed:", e, flush=True)
    threading.Thread(target=_save, daemon=True).start()
    return {"ok": True}


@app.post("/api/fav")
async def api_fav(request: Request):
    u = await _me(request)
    if not u:
        return _err("Please sign in first.", 401)
    b = await _body(request)
    it = b.get("item") if isinstance(b.get("item"), dict) else {}
    sid = str(it.get("subject_id") or b.get("sid") or "")[:60]
    if not sid:
        return _err("subject_id is required.")
    await asyncio.to_thread(accounts.set_fav, u["id"], sid, bool(b.get("on")), it)
    return {"ok": True}


@app.get("/api/seen/{sid}")
async def api_seen(sid: str, request: Request):
    u = await _me(request)
    return {"seen": await asyncio.to_thread(accounts.get_seen, u["id"], sid) if u else []}


@app.post("/api/password")
async def api_password(request: Request):
    u = await _me(request)
    if not u:
        return _err("Please sign in first.", 401)
    b = await _body(request)
    err = await asyncio.to_thread(accounts.change_password, u["id"], _token(request), str(b.get("old", "")), str(b.get("new", "")))
    return _err(err) if err else {"ok": True}


@app.get("/admin")
async def admin_page():
    return FileResponse("admin.html")


_admin_fails = {}


@app.post("/api/admin/{action}")
async def api_admin(action: str, request: Request):
    """Header X-Admin-Key = env ADMIN_KEY. actions: stats | password | delete"""
    ip = (request.headers.get("x-forwarded-for") or (request.client.host if request.client else "")).split(",")[0].strip()
    bad = _admin_fails.get(ip, (0, 0))
    if bad[0] >= 5 and time.time() - bad[1] < 600:
        return _err("Too many attempts. Please try again in 10 minutes.", 429)
    given = request.headers.get("x-admin-key") or ""
    if not ADMIN_KEY or not hmac.compare_digest(given.encode(), ADMIN_KEY.encode()):
        _admin_fails[ip] = (bad[0] + 1, time.time())
        return _err("Invalid admin key.", 403)
    _admin_fails.pop(ip, None)
    b = await _body(request)
    pr = await asyncio.to_thread(protect.admin_action, action, b, request)
    if pr is not None:
        if isinstance(pr, dict) and "_status" in pr:
            return JSONResponse({k: v for k, v in pr.items() if k != "_status"}, status_code=pr["_status"])
        return pr
    if action == "stats":
        try:
            st = await asyncio.to_thread(accounts.admin_stats)
            return {**st, "sql": accounts.sql_state()}
        except Exception as e:
            return {"total": 0, "users": [], "error": str(e)[:200], "sql": accounts.sql_state()}
    if action == "db":
        act = str(b.get("action", ""))
        if act not in ("info", "check", "sync", "discard"):
            return _err("bad action")
        if act == "discard" and b.get("confirm") is not True:
            return _err("confirm required")
        return await asyncio.to_thread(accounts.db_admin, act)
    if action == "password":
        err = await asyncio.to_thread(accounts.admin_set_password, str(b.get("username", "")), str(b.get("password", "")))
    elif action == "delete":
        err = await asyncio.to_thread(accounts.admin_delete, str(b.get("username", "")))
    else:
        return _err("not found", 404)
    return _err(err) if err else {"ok": True}


PROBES = {
    "base": ({}, "moviebox.ph"),
    "lang_hi": ({"Accept-Language": "hi-IN,hi;q=0.9", "X-Request-Lang": "hi"}, "moviebox.ph"),
    "ip_headers": ({"X-Forwarded-For": IN_IP, "X-Real-IP": IN_IP, "CF-Connecting-IP": IN_IP, "CF-IPCountry": "IN"}, "moviebox.ph"),
    "host_h5": ({}, "h5.aoneroom.com"),
    "all_signals": ({"Accept-Language": "hi-IN,hi;q=0.9", "X-Forwarded-For": IN_IP, "X-Real-IP": IN_IP, "CF-IPCountry": "IN"}, "h5.aoneroom.com"),
}


@app.get("/probe")
async def probe(cdn: int = 0, u: str = ""):
    """Open in the browser: /probe -> shows which variant returns Indian/Hindi titles.
    /probe?cdn=1 -> ALSO shows this server's own public IP and whether that IP can fetch a
    real CDN video url (bcdnxw/bcdnw) with the usual headers - this is the test to run on
    Render to confirm whether Render's IP is still accepted by the CDN or not.
    /probe?cdn=1&u=<a stream url copied from /api/stream's response> tests that exact url."""
    out = {}
    async with httpx.AsyncClient(follow_redirects=True, timeout=25, **CK) as c:
        try:
            out["server_ip_info"] = (await c.get("https://ipinfo.io/json")).json()
        except Exception as e:
            out["server_ip_info"] = str(e)
        for k, (extra, host) in PROBES.items():
            try:
                r = await c.get(f"{API}/home?host={host}", headers={**HBASE, **extra})
                try:
                    info = {a: b for a, b in json.loads(r.headers.get("x-user", "{}")).items() if a != "token"}
                except Exception:
                    info = {}
                ops = (r.json().get("data") or {}).get("operatingList") or []
                out[k] = {"status": r.status_code, "x_user": info,
                          "sample": [s.get("title") for op in ops for s in (op.get("subjects") or [])][:12]}
            except Exception as e:
                out[k] = {"err": str(e)}
        if cdn:
            test_url = u
            if not test_url:
                try:
                    j = await call(f"{API}/subject/search", payload={"keyword": "pattas", "page": 1, "perPage": 1})
                    items = ((j.get("data") or {}).get("items") or (j.get("data") or {}).get("list") or [])
                    if items:
                        dd = await call(f"{API}/media-player/get-domain")
                        dom = (dd.get("data") if isinstance(dd.get("data"), str) else "") or "https://netfilm.world"
                        dom = dom.rstrip("/")
                        it = items[0]
                        ref = f"{dom}/spa/videoPlayPage/movies/{it['detailPath']}?id={it['subjectId']}&type=/movie/detail&detailSe=0&detailEp=0&lang=en"
                        play = f"{dom}/wefeed-h5api-bff/subject/play?subjectId={it['subjectId']}&se=0&ep=0&detailPath={it['detailPath']}"
                        pr = await call(play, hdr={"User-Agent": UA, "Accept": "application/json", "Referer": ref, "X-Client-Info": XCI, **INH})
                        pd = pr.get("data") or {}
                        us = [x.get("url") for x in (pd.get("streams") or []) if x.get("url")]
                        test_url = us[0] if us else ""
                        out["_auto_picked_movie"] = it.get("title")
                except Exception as e:
                    out["_auto_pick_err"] = str(e)[:150]
            if not test_url:
                out["cdn_test"] = {"err": "no stream url found/given - pass ?u=<url> manually"}
            else:
                rows = {}
                combos = [
                    ("no-headers", {}),
                    ("ua-only", {"User-Agent": UA}),
                    ("ua+ref-netfilm", {"User-Agent": UA, "Referer": "https://netfilm.world/", "Origin": "https://netfilm.world"}),
                    ("ua+ref-moviebox", {"User-Agent": UA, "Referer": "https://moviebox.ph/", "Origin": "https://moviebox.ph"}),
                ]
                for label, hh in combos:
                    try:
                        rr = await c.get(test_url, headers={**hh, "Range": "bytes=0-15"})
                        rows[label] = {"status": rr.status_code, "first_bytes": rr.content[:40].decode("utf-8", "ignore")}
                    except Exception as e:
                        rows[label] = {"err": str(e)[:120]}
                from urllib.parse import urlparse as _up
                out["cdn_test"] = {"tested_host": _up(test_url).netloc, "results": rows}
    return out
