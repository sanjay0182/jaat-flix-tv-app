package com.jaatflix.tv

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** One card on the screen (movie / series / short). Comes from the JaatFlix backend (/home, /search, /more). */
class Title(
    val slug: String,
    val id: String,
    val name: String,
    val poster: String,
    val rating: Double?,
    val year: String,
    val badge: String?,
    val type: Int,          // MovieBox subjectType: 1 movie, 2 series, 7 short
    val genre: String,
    val pct: Int = 0,       // continue watching: how much is watched (0..100)
    val se: Int = 0,        // continue watching: season / episode / second to resume from
    val ep: Int = 0,
    val pos: Double = 0.0
)

class HomeData(val sections: List<Section>, val tabs: List<Pair<String, String>>)

/** The signed-in person: name, continue-watching list and My List. */
class Me(val user: String, val progress: List<Title>, val favs: List<Title>)

class Section(val title: String, val items: List<Title>, val moreId: String?, val isBanner: Boolean)

class Dub(val id: String, val slug: String, val lang: String)
class Season(val se: Int, val n: Int)

class Detail(
    val slug: String,
    val id: String,
    val title: String,
    val poster: String,
    val desc: String,
    val rating: Double?,
    val year: String,
    val genres: List<String>,
    val series: Boolean,
    val seasons: List<Season>,
    val dubs: List<Dub>
)

/** A playable link from /api/stream. [fb] is the same video through the server (used when the direct link fails). */
class Source(val label: String, val res: Int, val url: String, val kind: String, val fb: String, val backup: Boolean)

class Caption(val lang: String, val url: String)

class Streams(val sources: List<Source>, val capId: String, val capFmt: String, val capIds: String, val note: String)

/** Everything the app asks the JaatFlix backend. All calls are BLOCKING: use Net.async(...) from the UI. */
object Api {
    private val BRACKETS = Regex("""\s*[\[(][^\])]*[\])]""")

    /** "Title [Hindi]" -> "Title" (the language tag is shown as a badge instead). */
    fun cleanName(n: String): String = n.replace(BRACKETS, "").trim().ifEmpty { n }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun parseTitle(o: JSONObject): Title? {
        val slug = o.optString("slug")
        if (slug.isEmpty() || slug == "null") return null
        val raw = o.optString("name", slug)
        val r = o.optString("rating", "").toDoubleOrNull()
        val badge = o.optString("badge", "").takeIf { it.isNotEmpty() && it != "null" }
        return Title(
            slug = slug,
            id = o.optString("subject_id"),
            name = cleanName(if (raw == "null") slug else raw),
            poster = o.optString("poster_url", "").let { if (it == "null") "" else it },
            rating = if (r != null && r > 0) r else null,
            year = o.optString("year", "").let { if (it == "null") "" else it },
            badge = badge,
            type = o.optInt("type", 0),
            genre = o.optString("genre", "").let { if (it == "null") "" else it }
        )
    }

    private fun parseTitles(a: JSONArray?): List<Title> {
        val out = ArrayList<Title>()
        if (a == null) return out
        for (i in 0 until a.length()) a.optJSONObject(i)?.let { o -> parseTitle(o)?.let(out::add) }
        return out
    }

    /** Home rows (Banner first). [tab] = a top tab id from MovieBox, empty = Trending/home. */
    fun home(tab: String = "", page: Int = 0): List<Section> = homeFull(tab, page).sections

    fun homeFull(tab: String = "", page: Int = 0): HomeData {
        val j = Net.request("/home?tab=" + enc(tab) + "&page=$page")
        val tabs = ArrayList<Pair<String, String>>()
        val ta = j.optJSONArray("tabs")
        if (ta != null) for (i in 0 until ta.length()) {
            val o = ta.optJSONObject(i) ?: continue
            val n = o.optString("name", ""); val id = o.optString("id", "")
            if (n.isNotEmpty() && n != "null") tabs.add(Pair(n, if (id == "null") "" else id))
        }
        val arr = j.optJSONArray("sections") ?: return HomeData(emptyList(), tabs)
        val out = ArrayList<Section>()
        for (i in 0 until arr.length()) {
            val s = arr.optJSONObject(i) ?: continue
            val items = parseTitles(s.optJSONArray("items"))
            if (items.isEmpty()) continue
            val name = s.optString("section", "")
            val banner = name == "Banner"
            val more = s.optJSONObject("more")?.optString("genreTopId")?.takeIf { it.isNotEmpty() }
                ?: s.optJSONObject("more")?.optString("id")?.takeIf { it.isNotEmpty() }
            out.add(Section(if (banner) "Trending now" else name, items, more, banner))
        }
        return HomeData(out, tabs)
    }

    /** Sign in. Returns the token. Throws ApiException (captcha flag = a TV pass is needed first). */
    fun login(user: String, pass: String): String {
        val j = Net.request("/api/login", JSONObject().put("username", user).put("password", pass))
        return j.optString("token")
    }

    fun logout() { try { Net.request("/api/logout", JSONObject()) } catch (e: Exception) { } }

    fun me(): Me {
        val j = Net.request("/api/me")
        val u = j.optJSONObject("user")
        val name = u?.optString("username")?.takeIf { it.isNotEmpty() && it != "null" } ?: u?.optString("name")?.takeIf { it.isNotEmpty() && it != "null" } ?: "Account"
        val prog = ArrayList<Title>()
        val pa = j.optJSONArray("progress")
        if (pa != null) for (i in 0 until pa.length()) {
            val o = pa.optJSONObject(i) ?: continue
            val slug = o.optString("slug"); if (slug.isEmpty()) continue
            val dur = o.optDouble("dur", 0.0); val pos = o.optDouble("pos", 0.0)
            val pct = if (dur > 0) ((pos / dur) * 100).toInt().coerceIn(0, 100) else 0
            if (pct >= 95) continue
            prog.add(Title(slug, o.optString("sid"), cleanName(o.optString("name", slug)), o.optString("poster_url", ""), null, "", null, 0, "", pct, o.optInt("season"), o.optInt("episode"), pos))
        }
        val favs = ArrayList<Title>()
        val fa = j.optJSONArray("favs")
        if (fa != null) for (i in 0 until fa.length()) {
            val o = fa.optJSONObject(i) ?: continue
            val slug = o.optString("slug"); if (slug.isEmpty()) continue
            favs.add(Title(slug, o.optString("subject_id"), cleanName(o.optString("name", slug)), o.optString("poster_url", ""), null, "", null, 0, ""))
        }
        return Me(name, prog, favs)
    }

    fun setFav(t: Title, on: Boolean) {
        val item = JSONObject().put("subject_id", t.id).put("slug", t.slug).put("name", t.name).put("poster_url", t.poster)
        Net.request("/api/fav", JSONObject().put("sid", t.id).put("on", on).put("item", item))
    }

    fun more(id: String, title: String, page: Int): List<Title> {
        val j = Net.request("/more?id=" + enc(id) + "&title=" + enc(title) + "&page=$page&per=24")
        return parseTitles(j.optJSONArray("items"))
    }

    fun search(q: String, page: Int = 1): List<Title> {
        val j = Net.request("/search?q=" + enc(q) + "&page=$page")
        return parseTitles(j.optJSONArray("items"))
    }

    /** Title page data. This call also tells the site's guard "the page was opened" (needed before a stream). */
    fun detail(slug: String): Detail {
        val j = Net.request("/detail/" + enc(slug))
        val data = j.optJSONObject("data") ?: JSONObject()
        val s = data.optJSONObject("subject") ?: JSONObject()
        val r = data.optJSONObject("resource") ?: JSONObject()
        val type = s.optInt("subjectType", 0)
        val short = type == 7
        val seasons = ArrayList<Season>()
        val sa = r.optJSONArray("seasons")
        if (sa != null) for (i in 0 until sa.length()) {
            val o = sa.optJSONObject(i) ?: continue
            val se = o.optInt("se", 0)
            if (if (short) se < 0 else se <= 0) continue
            var n = o.optInt("maxEp", 0)
            if (n == 0) n = o.optInt("allEp", 0)
            seasons.add(Season(se, if (n > 0) n else 12))
        }
        val series = type == 2 || short || seasons.isNotEmpty()
        if (series && seasons.isEmpty()) seasons.add(Season(1, 12))

        // dubs (languages): the API often lists only the OTHER dubs, so this title itself is added too
        val dubs = ArrayList<Dub>()
        val seen = HashSet<String>()
        fun addDubs(a: JSONArray?) {
            if (a == null) return
            for (i in 0 until a.length()) {
                val x = a.optJSONObject(i) ?: continue
                val id = x.optString("subjectId")
                val sl = x.optString("detailPath")
                if (id.isEmpty() || sl.isEmpty() || !seen.add(id)) continue
                val lang = x.optString("lanName").ifEmpty { x.optString("lanCode").ifEmpty { x.optString("name").ifEmpty { "Dub" } } }
                dubs.add(Dub(id, sl, lang))
            }
        }
        addDubs(data.optJSONArray("dubs")); addDubs(s.optJSONArray("dubs")); addDubs(r.optJSONArray("dubs"))
        val myId = s.optString("subjectId")
        if (dubs.isNotEmpty() && myId.isNotEmpty() && !seen.contains(myId)) {
            val m = Regex("""\[([^\]]+)\]""").find(s.optString("title"))
            dubs.add(0, Dub(myId, s.optString("detailPath", slug), m?.groupValues?.get(1) ?: "Original"))
        }
        val rating = s.optString("imdbRatingValue", "").toDoubleOrNull()
        return Detail(
            slug = slug,
            id = myId,
            title = cleanName(s.optString("title", slug)),
            poster = s.optJSONObject("cover")?.optString("url", "") ?: "",
            desc = s.optString("description", ""),
            rating = if (rating != null && rating > 0) rating else null,
            year = s.optString("releaseDate", "").take(4),
            genres = s.optString("genre", "").split(",").map { it.trim() }.filter { it.isNotEmpty() },
            series = series,
            seasons = seasons,
            dubs = dubs
        )
    }

    /** Video links of one movie / episode (movie: se = 0, ep = 0). Use [Guard.watch] so captcha / "open page" rules are handled. */
    fun stream(id: String, slug: String, se: Int, ep: Int): Streams {
        val j = Net.request("/api/stream/" + enc(id) + "?detail_path=" + enc(slug) + "&se=$se&ep=$ep")
        val arr = j.optJSONArray("sources") ?: JSONArray()
        val out = ArrayList<Source>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val u = o.optString("url")
            if (u.isEmpty()) continue
            out.add(Source(o.optString("label", ""), o.optInt("res", 0), u, o.optString("kind", "mp4"), o.optString("fb", ""), o.optBoolean("backup", false)))
        }
        val cap = j.optJSONObject("cap")
        val ids = cap?.optJSONArray("ids")
        val idList = ArrayList<String>()
        if (ids != null) for (i in 0 until ids.length()) idList.add(ids.optString(i))
        return Streams(out, cap?.optString("id", "") ?: "", cap?.optString("fmt", "MP4") ?: "MP4", idList.joinToString(","), j.optString("note", ""))
    }

    /** ALL subtitle languages of the title (English / Hindi first). */
    fun captions(id: String, slug: String, s: Streams): List<Caption> {
        if (s.capId.isEmpty() && s.capIds.isEmpty()) return emptyList()
        val j = Net.request("/api/captions/" + enc(id) + "?detail_path=" + enc(slug) + "&id=" + enc(s.capId) + "&fmt=" + enc(s.capFmt) + "&ids=" + enc(s.capIds))
        val a = j.optJSONArray("captions") ?: return emptyList()
        val out = ArrayList<Caption>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val u = o.optString("url")
            if (u.isNotEmpty()) out.add(Caption(o.optString("lang", "Subtitle"), u))
        }
        return out
    }
}
