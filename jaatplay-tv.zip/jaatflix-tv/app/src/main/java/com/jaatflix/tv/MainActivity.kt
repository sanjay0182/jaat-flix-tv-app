package com.jaatflix.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * PART 2: the full browsing app. Home (tabs, hero, rows, continue watching, My List), All-grid, Search,
 * Detail (language, seasons, episodes, My List), sign-in. Play = gets the video links (captcha QR / sign-in handled);
, Play opens PlayerActivity (part 3).
 */
class MainActivity : Activity() {
    private val ACCENT = 0xFFFF5330.toInt()
    private val BG = 0xFF0A0A0D.toInt()
    private val MUTED = 0xFF9A9AA6.toInt()
    private val PANEL = 0xFF23232D.toInt()

    private class Screen(val view: View, var focus: View? = null)

    private val stack = ArrayList<Screen>()
    private lateinit var content: FrameLayout
    private val h = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences

    // home state
    private var tabs: List<Pair<String, String>> = emptyList()
    private var curTab = ""
    private var sections: List<Section> = emptyList()
    private lateinit var homeBody: FrameLayout
    private lateinit var tabBar: LinearLayout
    private var homeLoadFailed = false

    // account state
    private var me: Me? = null
    private val favIds = HashSet<String>()
    private var busy = false

    // hero
    private var heroItems: List<Title> = emptyList()
    private var heroIdx = 0
    private var heroImg: ImageView? = null
    private var heroTitle: TextView? = null
    private var heroMeta: TextView? = null
    private val heroTick = object : Runnable {
        override fun run() {
            if (heroItems.size > 1 && stack.size == 1) { heroIdx = (heroIdx + 1) % heroItems.size; paintHero() }
            h.postDelayed(this, 7000L)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Net.init(applicationContext)
        Img.init(applicationContext)
        prefs = getSharedPreferences("app", MODE_PRIVATE)
        Net.token = prefs.getString("jf_token", null)
        content = FrameLayout(this).apply { setBackgroundColor(BG) }
        setContentView(content)
        push(buildHomeShell())
        loadHome("")
        if (Net.token != null) loadMe()
    }

    override fun onResume() {
        super.onResume(); h.removeCallbacks(heroTick); h.postDelayed(heroTick, 7000L)
        // back from the player: refresh Continue watching
        if (PlayerEvents.played) { PlayerEvents.played = false; if (Net.token != null) loadMe() }
    }
    override fun onPause() { super.onPause(); h.removeCallbacks(heroTick) }

    override fun onBackPressed() { if (stack.size > 1) pop() else super.onBackPressed() }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) { openAccount(); return true }
        return super.onKeyDown(keyCode, event)
    }

    // ------------------------------------------------------------------ navigation
    private fun push(v: View) {
        if (stack.isNotEmpty()) { stack.last().focus = currentFocus; content.removeAllViews() }
        stack.add(Screen(v))
        content.addView(v)
        v.post { v.requestFocus() }
    }

    private fun pop() {
        if (stack.size <= 1) return
        stack.removeAt(stack.size - 1)
        content.removeAllViews()
        val s = stack.last()
        content.addView(s.view)
        s.view.post { if (s.focus?.requestFocus() != true) s.view.requestFocus() }
    }

    // ------------------------------------------------------------------ small ui helpers
    private fun stateBg(fill: Int, r: Int): StateListDrawable {
        val f = GradientDrawable().apply { setColor(fill); cornerRadius = r.toFloat(); setStroke(dp(3), Color.WHITE) }
        val n = GradientDrawable().apply { setColor(fill); cornerRadius = r.toFloat() }
        return StateListDrawable().apply { addState(intArrayOf(android.R.attr.state_focused), f); addState(intArrayOf(), n) }
    }

    private fun pill(label: String, accent: Boolean = false, selected: Boolean = false, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            isFocusable = true
            isClickable = true
            background = stateBg(if (accent || selected) ACCENT else PANEL, dp(22))
            setOnClickListener { onClick() }
        }

    private fun lp(w: Int, hh: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, hh).apply { setMargins(l, t, r, b) }

    private fun text(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun scroll(inner: View): ScrollView = ScrollView(this).apply {
        isVerticalScrollBarEnabled = false
        isFillViewport = true
        addView(inner)
    }

    /** Poster card (2:3) with rating, language badge and an optional progress bar. */
    private fun card(t: Title, w: Int = dp(140), onClick: () -> Unit): View {
        val ph = (w * 3) / 2
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isFocusable = true
            isClickable = true
            layoutParams = lp(w + dp(8), ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(10), dp(6))
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = stateBg(Color.TRANSPARENT, dp(10))
            setOnClickListener { onClick() }
        }
        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(w, ph)
            background = GradientDrawable().apply { setColor(0xFF1B1B24.toInt()); cornerRadius = dp(8).toFloat() }
            clipToOutline = true
        }
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(w, ph)
        }
        frame.addView(iv)
        t.rating?.let {
            frame.addView(TextView(this).apply {
                this.text = "\u2605 " + String.format("%.1f", it); textSize = 12f; setTextColor(Color.WHITE)
                setPadding(dp(6), dp(2), dp(6), dp(2)); setBackgroundColor(0xAA000000.toInt())
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END)
            })
        }
        t.badge?.let {
            frame.addView(TextView(this).apply {
                this.text = it; textSize = 11f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
                setPadding(dp(6), dp(2), dp(6), dp(2)); setBackgroundColor(ACCENT)
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
            })
        }
        if (t.pct > 0) {
            frame.addView(View(this).apply {
                setBackgroundColor(0x66FFFFFF)
                layoutParams = FrameLayout.LayoutParams(w, dp(4), Gravity.BOTTOM)
            })
            frame.addView(View(this).apply {
                setBackgroundColor(ACCENT)
                layoutParams = FrameLayout.LayoutParams((w * t.pct) / 100, dp(4), Gravity.BOTTOM)
            })
        }
        box.addView(frame)
        box.addView(TextView(this).apply {
            this.text = t.name; maxLines = 2; textSize = 14f; setTextColor(Color.WHITE)
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT)
            setPadding(dp(2), dp(6), dp(2), 0)
        })
        Net.loadImage(iv, t.poster, w)
        return box
    }

    // ------------------------------------------------------------------ HOME
    private fun buildHomeShell(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(40), dp(14), dp(40), dp(6))
        }
        bar.addView(text("JaatPlay", 26f, ACCENT, true), lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(24), 0))
        tabBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabBar)
        }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT).apply { weight = 1f })
        bar.addView(pill("Search") { openSearch() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, dp(10), 0, 0, 0))
        bar.addView(pill(if (Net.token != null) "Account" else "Sign in") { openAccount() }.also { accountBtn = it }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, dp(10), 0, 0, 0))
        col.addView(bar)
        homeBody = FrameLayout(this)
        col.addView(homeBody, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return col
    }

    private var accountBtn: TextView? = null

    private fun paintTabs() {
        tabBar.removeAllViews()
        tabBar.addView(pill("Home", selected = curTab.isEmpty()) { if (curTab.isNotEmpty()) loadHome("") }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(8), 0))
        for ((name, id) in tabs.take(8)) {
            if (id.isEmpty() || name.equals("Home", true)) continue
            tabBar.addView(pill(name, selected = id == curTab) { if (id != curTab) loadHome(id) }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(8), 0))
        }
    }

    private fun loadHome(tab: String) {
        curTab = tab
        homeLoadFailed = false
        homeBody.removeAllViews()
        homeBody.addView(text("Loading\u2026", 20f, MUTED).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        Net.async({ Api.homeFull(tab) }, { d ->
            if (tab == curTab) {
                if (tabs.isEmpty() || tab.isEmpty()) tabs = d.tabs
                sections = d.sections
                paintTabs()
                renderHome()
            }
        }, { e ->
            if (tab == curTab) {
                homeLoadFailed = true
                homeBody.removeAllViews()
                val t = text(Guard.message(e) + "\nPress OK to retry.", 20f, MUTED).apply { gravity = Gravity.CENTER; isFocusable = true; isClickable = true }
                t.setOnClickListener { loadHome(tab) }
                homeBody.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                t.post { t.requestFocus() }
            }
        })
    }

    private fun renderHome() {
        if (homeLoadFailed) return
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(40), dp(4), dp(40), dp(40)) }
        val banner = sections.firstOrNull { it.isBanner }
        heroItems = (banner?.items ?: sections.firstOrNull()?.items ?: emptyList()).take(8)
        heroIdx = 0
        if (heroItems.isNotEmpty()) col.addView(buildHero())
        val m = me
        if (m != null && m.progress.isNotEmpty()) addRow(col, "Continue watching", m.progress, null) { t -> openDetail(t) }
        if (m != null && m.favs.isNotEmpty()) addRow(col, "My List", m.favs, null) { t -> openDetail(t) }
        for (s in sections) {
            if (s.isBanner) continue
            val more = s.moreId
            addRow(col, s.title, s.items, if (more != null) ({ openGrid(s.title) { p -> Api.more(more, s.title, p) } }) else null) { t -> openDetail(t) }
        }
        homeBody.removeAllViews()
        homeBody.addView(scroll(col))
        if (stack.size == 1) homeBody.post { homeBody.requestFocus() }
    }

    private fun addRow(col: LinearLayout, title: String, items: List<Title>, all: (() -> Unit)?, click: (Title) -> Unit) {
        if (items.isEmpty()) return
        col.addView(text(title, 20f, Color.WHITE, true).apply { setPadding(0, dp(16), 0, dp(6)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(4)) }
        for (t in items) row.addView(card(t) { click(t) })
        if (all != null) {
            val more = TextView(this).apply {
                this.text = "All \u203A"; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                isFocusable = true; isClickable = true
                background = stateBg(PANEL, dp(10))
                layoutParams = lp(dp(110), dp(210), 0, dp(4), 0, 0)
                setOnClickListener { all() }
            }
            row.addView(more)
        }
        col.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            addView(row)
        })
    }

    private fun buildHero(): View {
        val box = FrameLayout(this).apply { layoutParams = lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(260), 0, dp(6), 0, dp(6)) }
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { setColor(0xFF1B1B24.toInt()); cornerRadius = dp(14).toFloat() }
            clipToOutline = true
        }
        box.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xEE0A0A0D.toInt(), 0x000A0A0D)).apply { cornerRadius = dp(14).toFloat() }
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(18))
        }
        val title = text("", 28f, Color.WHITE, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
        val meta = text("", 14f, MUTED)
        info.addView(title)
        info.addView(meta)
        info.addView(pill("Details", accent = true) { heroItems.getOrNull(heroIdx)?.let { openDetail(it) } }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(10), 0, 0))
        box.addView(info, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        heroImg = iv; heroTitle = title; heroMeta = meta
        paintHero()
        return box
    }

    private fun paintHero() {
        val t = heroItems.getOrNull(heroIdx) ?: return
        heroTitle?.text = t.name
        heroMeta?.text = listOfNotNull(t.rating?.let { "\u2605 " + String.format("%.1f", it) }, t.year.takeIf { it.isNotEmpty() }, t.genre.takeIf { it.isNotEmpty() }).joinToString("  \u00B7  ")
        heroImg?.let { Net.loadImage(it, t.poster, 1280) }
    }

    // ------------------------------------------------------------------ GRID (All > and search results)
    private inner class Grid(val perRow: Int = 6) {
        val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
        private var row: LinearLayout? = null
        private var n = 0
        fun clear() { col.removeAllViews(); row = null; n = 0 }
        fun add(items: List<Title>) {
            for (t in items) {
                var r = row
                if (n % perRow == 0 || r == null) {
                    val nr = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                    col.addView(nr)
                    row = nr
                    r = nr
                }
                r!!.addView(card(t, dp(124)) { openDetail(t) })
                n++
            }
        }
        val count get() = n
    }

    private fun header(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(40), dp(16), dp(40), dp(8))
        addView(pill("\u2039 Back") { pop() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(16), 0))
        addView(text(title, 24f, Color.WHITE, true))
    }

    private fun openGrid(title: String, load: (Int) -> List<Title>) {
        val page = intArrayOf(1)
        val grid = Grid()
        val msg = text("Loading\u2026", 16f, MUTED)
        val moreBtn = pill("Load more") { }
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        shell.addView(header(title))
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(40), dp(4), dp(40), dp(40)) }
        inner.addView(grid.col)
        inner.addView(msg)
        inner.addView(moreBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(12), 0, 0))
        moreBtn.visibility = View.GONE
        shell.addView(scroll(inner), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        fun go() {
            val p = page[0]
            msg.visibility = View.VISIBLE; msg.text = "Loading\u2026"; moreBtn.visibility = View.GONE
            Net.async({ load(p) }, { items ->
                grid.add(items)
                if (items.isEmpty()) { msg.text = if (grid.count == 0) "Nothing found." else "That is all."; }
                else { msg.visibility = View.GONE; moreBtn.visibility = View.VISIBLE; page[0] = p + 1 }
            }, { e -> msg.text = Guard.message(e); moreBtn.visibility = View.VISIBLE })
        }
        moreBtn.setOnClickListener { go() }
        push(shell)
        go()
    }

    // ------------------------------------------------------------------ SEARCH
    private fun openSearch() {
        val grid = Grid(6)
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = header("Search")
        val input = EditText(this).apply {
            hint = "Type a movie or series name"
            setHintTextColor(MUTED); setTextColor(Color.WHITE); textSize = 20f
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setSingleLine(true)
            background = stateBg(PANEL, dp(10))
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        top.addView(input, lp(dp(420), ViewGroup.LayoutParams.WRAP_CONTENT, dp(20), 0, 0, 0))
        shell.addView(top)
        val msg = text("Type a name and press the keyboard's search key.", 16f, MUTED).apply { setPadding(dp(40), dp(8), dp(40), dp(8)) }
        shell.addView(msg)
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(40), dp(4), dp(40), dp(40)) }
        inner.addView(grid.col)
        shell.addView(scroll(inner), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val last = arrayOf("")
        fun doSearch() {
            val q = input.text.toString().trim()
            if (q.length < 2 || q == last[0]) return
            last[0] = q
            msg.text = "Searching\u2026"
            Net.async({ Api.search(q) }, { items ->
                if (q == last[0]) {
                    grid.clear(); grid.add(items)
                    msg.text = if (items.isEmpty()) "Nothing found for \"$q\"." else ""
                }
            }, { e -> if (q == last[0]) { msg.text = Guard.message(e); last[0] = "" } })
        }
        input.setOnEditorActionListener { _, _, _ -> doSearch(); true }
        input.setOnKeyListener { _, code, ev ->
            if (ev.action == KeyEvent.ACTION_UP && code == KeyEvent.KEYCODE_ENTER) { doSearch(); true } else false
        }
        push(shell)
        input.post { input.requestFocus() }
    }

    // ------------------------------------------------------------------ DETAIL
    private fun openDetail(t: Title) {
        val shell = FrameLayout(this)
        val msg = text("Loading\u2026", 20f, MUTED).apply { gravity = Gravity.CENTER }
        shell.addView(msg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val back = pill("\u2039 Back") { pop() }
        shell.addView(back, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply { setMargins(dp(40), dp(16), 0, 0) })
        push(shell)
        Net.async({ Api.detail(t.slug) }, { d ->
            shell.removeView(msg)
            shell.addView(buildDetail(d, t), 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            shell.post { findPlay(shell)?.requestFocus() }
        }, { e ->
            msg.text = Guard.message(e) + "\nPress Back."
        })
    }

    private var playBtnTag = "play"
    private fun findPlay(v: View): View? = v.findViewWithTag(playBtnTag)

    private fun buildDetail(d: Detail, from: Title): View {
        val dubIdx = intArrayOf(0)
        if (d.dubs.isNotEmpty()) dubIdx[0] = d.dubs.indexOfFirst { it.id == d.id }.coerceAtLeast(0)
        val curSe = intArrayOf(d.seasons.firstOrNull()?.se ?: 0)
        val self = Title(d.slug, d.id, d.title, d.poster, d.rating, d.year, null, if (d.series) 2 else 1, d.genres.joinToString(", "))

        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(40), dp(64), dp(40), dp(30)) }
        val poster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { setColor(0xFF1B1B24.toInt()); cornerRadius = dp(10).toFloat() }
            clipToOutline = true
        }
        root.addView(poster, lp(dp(200), dp(300), 0, 0, dp(30), 0))
        Net.loadImage(poster, d.poster.ifEmpty { from.poster }, 400)

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        right.addView(text(d.title, 30f, Color.WHITE, true))
        val meta = listOfNotNull(d.rating?.let { "\u2605 " + String.format("%.1f", it) }, if (d.series) "Series" else "Movie", d.year.takeIf { it.isNotEmpty() }, d.genres.take(3).joinToString(", ").takeIf { it.isNotEmpty() })
        right.addView(text(meta.joinToString("  \u00B7  "), 15f, MUTED).apply { setPadding(0, dp(4), 0, dp(8)) })
        right.addView(text(d.desc, 15f, 0xFFD0D0D8.toInt()).apply { maxLines = 4; ellipsize = TextUtils.TruncateAt.END })

        // continue watching info for this title
        val resume = me?.progress?.firstOrNull { it.slug == d.slug }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, dp(10)) }
        fun dub(): Dub? = d.dubs.getOrNull(dubIdx[0])
        fun playNow(se: Int, ep: Int) {
            play(d, dubIdx[0], se, ep)
        }
        val firstSe = d.seasons.firstOrNull()?.se ?: 0
        val playLabel = if (resume != null && d.series) "\u25B6 Resume S${resume.se} E${resume.ep}" else "\u25B6 Play"
        val playBtn = pill(playLabel, accent = true) {
            if (resume != null && d.series) playNow(resume.se, resume.ep) else if (d.series) playNow(firstSe, 1) else playNow(0, 0)
        }
        playBtn.tag = playBtnTag
        actions.addView(playBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(10), 0))
        val favBtn = pill("") { }
        fun paintFav() { favBtn.text = if (favIds.contains(d.id)) "\u2713 In My List" else "+ My List" }
        paintFav()
        favBtn.setOnClickListener {
            if (Net.token == null) { openAccount(); return@setOnClickListener }
            val on = !favIds.contains(d.id)
            if (on) favIds.add(d.id) else favIds.remove(d.id)
            paintFav()
            Net.async({ Api.setFav(self, on) }, { loadMe() }, { e -> toast(Guard.message(e)) })
        }
        actions.addView(favBtn)
        right.addView(actions)

        // languages (dubs)
        if (d.dubs.size > 1) {
            right.addView(text("Language", 14f, MUTED))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(8)) }
            fun paintDubs() {
                row.removeAllViews()
                d.dubs.forEachIndexed { i, x ->
                    row.addView(pill(x.lang, selected = i == dubIdx[0]) { dubIdx[0] = i; paintDubs(); row.getChildAt(i)?.requestFocus() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(8), 0))
                }
            }
            paintDubs()
            right.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        }

        // seasons + episodes
        if (d.series) {
            val seasonRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(6)) }
            val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            fun paintEps() {
                grid.removeAllViews()
                val n = d.seasons.firstOrNull { it.se == curSe[0] }?.n ?: 0
                var r: LinearLayout? = null
                for (k in 1..n) {
                    if ((k - 1) % 8 == 0) { r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; grid.addView(r) }
                    val seen = resume != null && resume.se == curSe[0] && resume.ep == k
                    r!!.addView(pill("E$k", selected = seen) { playNow(curSe[0], k) }, lp(dp(78), ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(8), dp(8)))
                }
            }
            fun paintSeasons() {
                seasonRow.removeAllViews()
                if (d.seasons.size > 1) d.seasons.forEach { s ->
                    seasonRow.addView(pill("Season ${s.se}", selected = s.se == curSe[0]) { curSe[0] = s.se; paintSeasons(); paintEps() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(8), 0))
                }
            }
            paintSeasons(); paintEps()
            if (d.seasons.size > 1) right.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(seasonRow) })
            right.addView(text("Episodes", 14f, MUTED).apply { setPadding(0, dp(6), 0, dp(4)) })
            right.addView(grid)
        }
        root.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return scroll(root)
    }

    // ------------------------------------------------------------------ PLAY (links + guard rules, then PlayerActivity)
    private fun play(d: Detail, dubIdx: Int, se: Int, ep: Int) {
        if (busy) return
        busy = true
        toast("Getting the video\u2026")
        val dub = d.dubs.getOrNull(dubIdx)
        val id = dub?.id ?: d.id
        val slug = dub?.slug ?: d.slug
        Net.async({ Guard.watch(id, slug, se, ep) }, { st ->
            busy = false
            if (st.sources.isEmpty()) { toast(st.note.ifEmpty { "No video found for this title." }); return@async }
            // resume: the account's Continue watching position for this exact title / episode (guests: the player remembers it on this TV)
            val saved = me?.progress?.firstOrNull { it.slug == d.slug && it.se == se && it.ep == ep }?.pos ?: 0.0
            PlayerActivity.start(this, d, dubIdx, se, ep, st, saved)
        }, { e ->
            busy = false
            when {
                Guard.isCaptcha(e) -> TvPair.show(this) { ok -> if (ok) play(d, dubIdx, se, ep) }
                Guard.isSignin(e) -> { toast("Free videos finished. Please sign in."); openAccount() }
                else -> toast(Guard.message(e))
            }
        })
    }

    // ------------------------------------------------------------------ ACCOUNT
    private fun loadMe() {
        Net.async({ Api.me() }, { m ->
            me = m
            favIds.clear(); m.favs.forEach { favIds.add(it.id) }
            accountBtn?.text = "Account"
            if (stack.size == 1) renderHome()
        }, { e ->
            if (e is ApiException && e.status == 401) { setToken(null); accountBtn?.text = "Sign in" }
        })
    }

    private fun setToken(t: String?) {
        Net.token = t
        prefs.edit().apply { if (t == null) remove("jf_token") else putString("jf_token", t) }.apply()
        if (t == null) { me = null; favIds.clear() }
    }

    private fun openAccount() {
        val m = me
        if (Net.token != null) {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(m?.user ?: "Account")
                .setMessage("You are signed in.")
                .setPositiveButton("Close", null)
                .setNegativeButton("Sign out") { _, _ ->
                    Net.async({ Api.logout() }, { })
                    setToken(null); accountBtn?.text = "Sign in"
                    if (stack.size == 1) renderHome()
                }.show()
        } else signInDialog { }
    }

    private fun signInDialog(done: () -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(12), dp(24), dp(4)) }
        val u = EditText(this).apply { hint = "Username"; setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS }
        val p = EditText(this).apply { hint = "Password"; setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val note = text("New here? Create the account on your phone on the website, then sign in here.", 13f, MUTED)
        box.addView(u); box.addView(p); box.addView(note)
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Sign in")
            .setView(box)
            .setPositiveButton("Sign in") { _, _ -> doLogin(u.text.toString().trim(), p.text.toString(), done) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun doLogin(user: String, pass: String, done: () -> Unit, retried: Boolean = false) {
        if (user.isEmpty() || pass.isEmpty()) { toast("Enter username and password."); return }
        Net.async({ Api.login(user, pass) }, { tok ->
            if (tok.isEmpty()) { toast("Sign in failed."); return@async }
            setToken(tok); accountBtn?.text = "Account"; loadMe(); toast("Signed in"); done()
        }, { e ->
            if (Guard.isCaptcha(e) && !retried) TvPair.show(this) { ok -> if (ok) doLogin(user, pass, done, true) }
            else toast(Guard.message(e))
        })
    }
}
