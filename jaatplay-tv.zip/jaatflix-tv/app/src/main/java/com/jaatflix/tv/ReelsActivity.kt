package com.jaatflix.tv

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Shorts as a full-screen vertical reels feed (like the website's Shorts):
 *  - one short at a time, it loops, the next one is picked with a swipe up / Down key
 *  - touch: swipe up / down = next / previous, tap = pause, double-tap left / right = -10 s / +10 s,
 *           drag the thin bar at the bottom to seek, side buttons = My List and Sound
 *  - remote: Down / Up = next / previous, Left / Right = -5 s / +5 s, OK = pause, long OK = My List, Menu = Sound
 * Videos are found the same way the normal player does it (Guard.watch -> Mb), the CDN headers are added here.
 */
class ReelsActivity : Activity() {

    companion object {
        /** Filled by MainActivity before the screen is opened. */
        @JvmField var items: MutableList<Title> = ArrayList()
        @JvmField var startIndex = 0
        /** (row id, row title) of the Shorts rows on the home feed: used to load more shorts when the end is near. */
        @JvmField var moreSrc: MutableList<Pair<String, String>> = ArrayList()
        @JvmField var favIds: MutableSet<String> = HashSet()

        private const val CDN_UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        private const val CDN_UA_ALT = "com.community.oneroom/50020131 (Linux; U; Android 10; en_IN; Redmi Note 7; Build/QKQ1.190910.002; Cronet/156.0.8078.25)"
        private const val UA = "Mozilla/5.0 (Linux; Android 7.0; TV) JaatFlixTV/1.0"
        private const val ACCENT = 0xFF0A84FF.toInt()

        fun open(from: Activity, list: List<Title>, startIdx: Int, more: List<Pair<String, String>>, favs: Set<String>) {
            items = ArrayList(list)
            startIndex = startIdx.coerceIn(0, (list.size - 1).coerceAtLeast(0))
            moreSrc = ArrayList(more)
            favIds = HashSet(favs)
            from.startActivity(android.content.Intent(from, ReelsActivity::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: android.content.SharedPreferences
    private var player: ExoPlayer? = null
    private var cur = -1
    private var gen = 0
    private var muted = false
    @Volatile private var curRef = "https://netfilm.world/"
    private val streamAt = HashMap<String, Pair<Long, Streams>>()
    private var curStreams: Streams? = null
    private var tried = HashSet<String>()
    private var curSrcR: Source? = null
    private var relayBad = false   // a relay link failed for this short: its other links play direct

    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var bg: ImageView
    private lateinit var pv: PlayerView
    private lateinit var spinner: ProgressBar
    private lateinit var flash: TextView
    private lateinit var titleTv: TextView
    private lateinit var metaTv: TextView
    private lateinit var hintTv: TextView
    private lateinit var errTv: TextView
    private lateinit var favBtn: TextView
    private lateinit var muteBtn: TextView
    private lateinit var barFill: View
    private lateinit var barZone: FrameLayout
    private lateinit var timeTv: TextView
    private var dragging = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (items.isEmpty()) { finish(); return }
        prefs = getSharedPreferences("reels", Context.MODE_PRIVATE)
        muted = prefs.getBoolean("muted", false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Net.init(applicationContext)
        buildUi()
        cur = -1
    }

    override fun onStart() {
        super.onStart()
        hideSystemUi()
        ensurePlayer()
        show(if (cur >= 0) cur else startIndex, 0)
        handler.post(tick)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(tick)
        gen++
        releasePlayer()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    // ------------------------------------------------------------------ UI (built in code, no layout xml)
    private fun label(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(6f, 0f, 2f, 0xAA000000.toInt())
    }

    private fun sideButton(onClick: () -> Unit) = TextView(this).apply {
        textSize = 14f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = GradientDrawable().apply { setColor(0x66000000); cornerRadius = dp(22).toFloat() }
        isFocusable = false          // the remote's keys are handled by the activity, nothing may take the focus
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        content = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.28f }
        content.addView(bg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        pv = PlayerView(this).apply {
            useController = false
            isFocusable = false
            setShutterBackgroundColor(Color.TRANSPARENT)
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        content.addView(pv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // dark gradient behind the text at the bottom
        val grad = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xCC000000.toInt(), 0x00000000))
        }
        content.addView(grad, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220), Gravity.BOTTOM))

        spinner = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        content.addView(spinner, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))

        flash = TextView(this).apply {
            textSize = 54f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; alpha = 0f
            setShadowLayer(12f, 0f, 2f, 0xAA000000.toInt())
        }
        content.addView(flash, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        errTv = label("", 17f).apply { gravity = Gravity.CENTER; visibility = View.GONE; setPadding(dp(30), 0, dp(30), 0) }
        content.addView(errTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        // title + info (bottom left)
        val cap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleTv = label("", 22f, Color.WHITE, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        metaTv = label("", 14f, 0xFFDDDDDD.toInt())
        hintTv = label("", 12f, 0x99FFFFFF.toInt()).apply { setPadding(0, dp(6), 0, 0) }
        cap.addView(titleTv); cap.addView(metaTv); cap.addView(hintTv)
        content.addView(cap, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(24), 0, dp(150), dp(40))
        })

        // buttons (right side)
        val side = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        favBtn = sideButton { toggleFav() }
        muteBtn = sideButton { toggleMute() }
        side.addView(favBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) })
        side.addView(muteBtn)
        content.addView(side, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(20), dp(56))
        })

        // thin seek bar at the bottom (big touch zone, thin line)
        timeTv = label("", 12f).apply { visibility = View.GONE }
        content.addView(timeTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(34) })
        barZone = FrameLayout(this)
        val track = View(this).apply { setBackgroundColor(0x44FFFFFF) }
        barZone.addView(track, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3), Gravity.BOTTOM).apply { bottomMargin = dp(6) })
        barFill = View(this).apply { setBackgroundColor(ACCENT) }
        barZone.addView(barFill, FrameLayout.LayoutParams(0, dp(3), Gravity.BOTTOM or Gravity.START).apply { bottomMargin = dp(6) })
        content.addView(barZone, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32), Gravity.BOTTOM))
        barZone.setOnTouchListener { v, ev ->
            val p = player
            val dur = p?.duration ?: C.TIME_UNSET
            if (p == null || dur <= 0L || dur == C.TIME_UNSET) return@setOnTouchListener true
            val f = (ev.x / v.width.toFloat()).coerceIn(0f, 1f)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    dragging = true
                    setBar(f); timeTv.visibility = View.VISIBLE
                    timeTv.text = fmt((f * dur).toLong()) + " / " + fmt(dur)
                }
                MotionEvent.ACTION_UP -> { dragging = false; timeTv.visibility = View.GONE; p.seekTo((f * dur).toLong()) }
                MotionEvent.ACTION_CANCEL -> { dragging = false; timeTv.visibility = View.GONE }
            }
            true
        }

        // gestures on the whole screen
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { togglePause(); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val left = e.x < root.width / 3f
                val right = e.x > root.width * 2f / 3f
                if (left) seekBy(-10_000L) else if (right) seekBy(10_000L) else togglePause()
                return true
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (Math.abs(dy) > dp(60) && Math.abs(dy) > Math.abs(dx) * 1.3f && Math.abs(vy) > 500f) {
                    if (dy < 0) next() else prev()
                    return true
                }
                return false
            }
        })
        root.setOnTouchListener { _, ev -> gd.onTouchEvent(ev); true }
        setContentView(root)
    }

    // ------------------------------------------------------------------ player
    private fun ensurePlayer() {
        if (player != null) return
        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .addInterceptor { chain ->
                val req = chain.request()
                if (req.url.host == Net.siteHost) {
                    val b = req.newBuilder()
                    for ((k, v) in Net.guardHeaders()) b.header(k, v)
                    chain.proceed(b.build())
                } else if (Relay.isRelayHost(req.url.host)) {
                    chain.proceed(req)          // relay link: signed, carries its own Referer, must stay https as it is
                } else cdnFetch(chain, req)
            }
            .build()
        val http = OkHttpDataSource.Factory(client).setUserAgent(UA)
        // small buffers: a short is short, and the next one should start fast
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(8_000, 25_000, 800, 1_500)
            .setTargetBufferBytes(24 * 1024 * 1024)
            .build()
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .setLoadControl(load)
            .build()
        p.repeatMode = Player.REPEAT_MODE_ONE
        p.volume = if (muted) 0f else 1f
        p.addListener(listener)
        pv.player = p
        player = p
    }

    private fun releasePlayer() {
        val p = player ?: return
        player = null
        pv.player = null
        p.removeListener(listener)
        p.release()
    }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_BUFFERING) spinner.visibility = View.VISIBLE
            else if (state == Player.STATE_READY) { spinner.visibility = View.GONE; errTv.visibility = View.GONE; if (Relay.isRelay(curSrcR)) Relay.ok() }
        }
        override fun onVideoSizeChanged(size: VideoSize) {
            if (size.width <= 0 || size.height <= 0) return
            // a tall video on a tall screen fills the screen, everything else keeps the whole picture
            val v = size.width.toFloat() / size.height
            val s = root.width.toFloat() / root.height.coerceAtLeast(1)
            pv.resizeMode = if (Math.abs(v - s) < 0.3f) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        override fun onPlayerError(error: PlaybackException) {
            // try the next quality / link of the same short, then give up with a message
            val st = curStreams
            val c = curSrcR
            if (st != null && Relay.isRelay(c)) {
                Relay.fail(); relayBad = true        // relay link failed: the same quality direct, right away
                startSource(Relay.direct(c!!), gen); return
            }
            val nxt = st?.sources?.map { if (relayBad) Relay.direct(it) else it }?.firstOrNull { !tried.contains(it.url) }
            if (st != null && nxt != null) { startSource(nxt, gen); return }
            spinner.visibility = View.GONE
            showErr("This video can not be played.")
        }
    }

    private fun pick(s: Streams): Source? {
        val l = s.sources
        return l.firstOrNull { it.kind == "hls" } ?: l.filter { it.res in 1..720 }.maxByOrNull { it.res } ?: l.firstOrNull()
    }

    private fun startSource(src: Source, g: Int) {
        if (g != gen) return
        val p = player ?: return
        curSrcR = src
        tried.add(src.url)
        val url = Net.abs(src.url)
        val b = MediaItem.Builder().setUri(Uri.parse(url))
        if (src.kind == "hls" || url.contains(".m3u8", ignoreCase = true)) b.setMimeType(MimeTypes.APPLICATION_M3U8)
        p.setMediaItem(b.build())
        p.prepare()
        p.playWhenReady = true
    }

    private fun showErr(m: String) {
        errTv.text = m + "\nSwipe up (or press Down) for the next short."
        errTv.visibility = View.VISIBLE
        spinner.visibility = View.GONE
    }

    // ------------------------------------------------------------------ one short at a time
    private fun show(k: Int, dir: Int) {
        if (k < 0 || k >= items.size) return
        cur = k
        gen++
        val g = gen
        val t = items[k]
        titleTv.text = Api.cleanName(t.name)
        metaTv.text = listOfNotNull(
            t.rating?.takeIf { it > 0 }?.let { "\u2605 " + String.format(java.util.Locale.US, "%.1f", it) },
            t.year.takeIf { it.isNotEmpty() },
            t.genre.split(",").firstOrNull()?.trim()?.takeIf { it.isNotEmpty() }
        ).joinToString("  \u00b7  ")
        hintTv.text = "${k + 1} / ${items.size}   \u25b2\u25bc next   \u25c4\u25ba seek   OK pause"
        paintFav(); paintMute()
        errTv.visibility = View.GONE
        spinner.visibility = View.VISIBLE
        setBar(0f)
        if (t.poster.isNotEmpty()) Net.loadImage(bg, t.poster, 480) else bg.setImageDrawable(null)
        player?.let { it.stop(); it.clearMediaItems() }
        tried = HashSet()
        curSrcR = null
        relayBad = false
        curStreams = null
        if (dir != 0) {
            content.alpha = 0f
            content.translationY = (if (dir > 0) dp(70) else -dp(70)).toFloat()
            content.animate().alpha(1f).translationY(0f).setDuration(180).start()
        }
        val cached = streamAt[t.slug]
        if (cached != null && System.currentTimeMillis() - cached.first < 120_000L) { play(cached.second, g); return }
        Net.async({ Guard.watch(t.id, t.slug, 0, 0) }, { s ->
            if (g == gen) { streamAt[t.slug] = Pair(System.currentTimeMillis(), s); play(s, g) }
        }, { e ->
            if (g == gen) showErr(Guard.message(e))
        })
        if (k >= items.size - 4) loadMoreItems()
    }

    private fun play(s: Streams, g: Int) {
        if (g != gen) return
        val src = pick(s)
        if (src == null) { showErr(s.note.ifEmpty { "No stream was found." }); return }
        curStreams = s
        curRef = s.ref
        startSource(src, g)
        // warm up the next short (only the link search, the site's guard is asked when it is really opened)
        val n = items.getOrNull(cur + 1)
        if (n != null && streamAt[n.slug] == null) Net.async({ Mb.resolveCached(n.id, n.slug, 0, 0) }, { }, { })
    }

    private fun next() {
        if (cur + 1 < items.size) show(cur + 1, 1) else { toast("That was the last short"); loadMoreItems() }
    }

    private fun prev() {
        if (cur > 0) show(cur - 1, -1)
    }

    private var loadingMore = false
    private var moreIdx = 0
    private val morePage = HashMap<String, Int>()
    private fun loadMoreItems() {
        if (loadingMore || moreSrc.isEmpty()) return
        loadingMore = true
        val src = moreSrc[moreIdx % moreSrc.size]
        moreIdx++
        val page = (morePage[src.first] ?: 0) + 1
        morePage[src.first] = page
        Net.async({ Api.more(src.first, src.second, page) }, { list ->
            loadingMore = false
            val have = HashSet<String>()
            for (t in items) have.add(t.slug)
            var added = 0
            for (t in list) if (have.add(t.slug)) { items.add(t); added++ }
            if (added == 0) moreSrc.remove(src)
            val c = cur
            if (c >= 0) hintTv.text = "${c + 1} / ${items.size}   \u25b2\u25bc next   \u25c4\u25ba seek   OK pause"
        }, { loadingMore = false; moreSrc.remove(src) })
    }

    // ------------------------------------------------------------------ controls
    private fun doFlash(sym: String) {
        flash.text = sym
        flash.animate().cancel()
        flash.alpha = 0.95f
        flash.animate().alpha(0f).setDuration(550).start()
    }

    private fun togglePause() {
        val p = player ?: return
        if (p.playWhenReady) { p.playWhenReady = false; doFlash("\u275a\u275a") } else { p.playWhenReady = true; doFlash("\u25b6") }
    }

    private fun seekBy(ms: Long) {
        val p = player ?: return
        val d = p.duration
        val t = p.currentPosition + ms
        p.seekTo(if (d > 0 && d != C.TIME_UNSET) t.coerceIn(0L, d) else t.coerceAtLeast(0L))
        doFlash(if (ms < 0) "\u25c4 ${-ms / 1000}s" else "${ms / 1000}s \u25ba")
    }

    private fun toggleMute() {
        muted = !muted
        prefs.edit().putBoolean("muted", muted).apply()
        player?.volume = if (muted) 0f else 1f
        paintMute()
    }

    private fun paintMute() { muteBtn.text = if (muted) "Sound: off" else "Sound: on" }

    private fun paintFav() {
        val t = items.getOrNull(cur)
        val on = t != null && favIds.contains(t.id)
        favBtn.text = if (on) "\u2665 In My List" else "\u2661 My List"
        favBtn.setTextColor(if (on) 0xFFFF5A7A.toInt() else Color.WHITE)
    }

    private fun toggleFav() {
        val t = items.getOrNull(cur) ?: return
        if (Net.token == null) { toast("Sign in (Account on the home screen) to use My List"); return }
        val on = !favIds.contains(t.id)
        if (on) favIds.add(t.id) else favIds.remove(t.id)
        paintFav()
        Net.async({ Api.setFav(t, on) }, { PlayerEvents.played = true }, {
            if (on) favIds.remove(t.id) else favIds.add(t.id)
            paintFav(); toast("Could not update My List")
        })
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "" + (s / 60) + ":" + (if (s % 60 < 10) "0" else "") + (s % 60)
    }

    private fun setBar(f: Float) {
        val lp = barFill.layoutParams
        lp.width = (barZone.width * f.coerceIn(0f, 1f)).toInt()
        barFill.layoutParams = lp
    }

    private val tick = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && !dragging) {
                val d = p.duration
                if (d > 0 && d != C.TIME_UNSET) setBar(p.currentPosition.toFloat() / d)
            }
            handler.postDelayed(this, 300)
        }
    }

    // remote keys
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_CHANNEL_DOWN -> { next(); return true }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_CHANNEL_UP -> { prev(); return true }
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-5_000L); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(5_000L); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> { event?.startTracking(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_SPACE -> { if ((event?.repeatCount ?: 0) == 0) togglePause(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY -> { player?.playWhenReady = true; return true }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> { player?.playWhenReady = false; return true }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_M -> { toggleMute(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) { toggleFav(); return true }
        return super.onKeyLongPress(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) {
            val canceled = event != null && (event.flags and KeyEvent.FLAG_CANCELED_LONG_PRESS) != 0
            if (!canceled) togglePause()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    // ------------------------------------------------------------------ the CDN's job (same rules as the normal player)
    private val cdnFallbackHosts = listOf("cacdn.hakunaymatata.com", "sbcdn5.hakunaymatata.com")
    private val cdnRefuse = setOf(401, 403, 404, 410, 426, 427, 451)
    private val hostMemory = java.util.concurrent.ConcurrentHashMap<String, Pair<String, String>>()   // refused host -> (host that worked, user-agent)
    @Volatile private var plainHttp = false    // set when this TV cannot do the CDN's https (old TVs): then plain http is used, like the relay's http-first

    private fun cdnReq(r: okhttp3.Request, host: String? = null, ua: String = CDN_UA, http: Boolean = false): okhttp3.Request {
        val ref = curRef
        var u = r.url
        if (host != null) u = u.newBuilder().host(host).build()
        if (http && u.isHttps) u = u.newBuilder().scheme("http").build()
        return r.newBuilder().url(u)
            .header("User-Agent", ua)
            .header("Referer", ref)
            .header("Origin", ref.trimEnd('/'))
            .header("Accept", "*/*")
            .header("Accept-Encoding", "identity")
            .build()
    }

    private fun cdnFetch(chain: okhttp3.Interceptor.Chain, req: okhttp3.Request): okhttp3.Response {
        val orig = req.url.host
        val isCdn = orig.endsWith("hakunaymatata.com")
        val mem = if (isCdn) hostMemory[orig] else null
        if (mem != null) {
            try {
                val r = chain.proceed(cdnReq(req, mem.first, mem.second, plainHttp))
                if (r.code < 400) return r
                r.close()
            } catch (e: java.io.IOException) { }
            hostMemory.remove(orig)
        }
        var resp: okhttp3.Response
        try {
            resp = chain.proceed(cdnReq(req, null, CDN_UA, plainHttp))
        } catch (e: javax.net.ssl.SSLException) {
            if (plainHttp) throw e
            plainHttp = true                      // https handshake failed on this TV -> plain http from now on
            resp = chain.proceed(cdnReq(req, null, CDN_UA, true))
        }
        if (resp.code < 400 || !isCdn || resp.code !in cdnRefuse) return resp
        resp.close()
        // this CDN host refuses this connection (426 / 427 ...): the same path on the other CDN hosts, then the other User-Agent
        for (h in cdnFallbackHosts) {
            if (h == orig) continue
            for (ua in listOf(CDN_UA, CDN_UA_ALT)) {
                try {
                    val r = chain.proceed(cdnReq(req, h, ua, plainHttp))
                    if (r.code < 400) { hostMemory[orig] = Pair(h, ua); return r }
                    r.close()
                } catch (e: java.io.IOException) { }
            }
        }
        return chain.proceed(cdnReq(req, null, CDN_UA, plainHttp))     // give the player the real error
    }

}
