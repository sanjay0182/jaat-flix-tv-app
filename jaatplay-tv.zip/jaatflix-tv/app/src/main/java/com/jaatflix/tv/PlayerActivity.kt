package com.jaatflix.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.media.AudioManager
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.AdaptiveTrackSelection
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import okhttp3.OkHttpClient
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * PART 3: the full-screen player (Media3 ExoPlayer, no WebView).
 *
 *  OK = play / pause          Left / Right = seek 10 s (hold = faster)
 *  Up = show controls         Down = move into the button row (Language, Quality, Audio, Subtitles, Prev, Next, Episodes, Auto-next)
 *  Back = close (or cancel the "next episode" countdown)
 *
 * Language  -> asks the site for the same title in another dub, continues from the same second.
 * Quality   -> relay (Wisper) links first, the direct CDN links found by the app itself (Mb.kt) as fallback (see Relay.kt: 10 failures in a row = direct only):
 *              the player adds Referer / User-Agent itself and, like the relay did, tries the other CDN hosts when one refuses.
 * Subtitles -> ALL languages of /api/captions (English, Hindi first), choice is remembered.
 * Resume    -> position comes from the account (Continue watching) or, for guests, from this TV.
 * Progress  -> saved to /api/progress every 10 s when signed in, so Continue watching works on the website too.
 */
class PlayerActivity : Activity() {

    companion object {
        private var sDetail: Detail? = null
        private var sStreams: Streams? = null
        private const val UA = "Mozilla/5.0 (Linux; Android 7.0; TV) JaatFlixTV/1.0"
        // what the CDN got from the relay before (same values)
        private const val CDN_UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        private const val CDN_UA_ALT = "com.community.oneroom/50020131 (Linux; U; Android 10; en_IN; Redmi Note 7; Build/QKQ1.190910.002; Cronet/156.0.8078.25)"
        private const val ACCENT = 0xFF0A84FF.toInt()

        /** Opens the player. [startSec] > 0 = resume from there. */
        fun start(from: Activity, d: Detail, dubIdx: Int, se: Int, ep: Int, st: Streams, startSec: Double) {
            sDetail = d
            sStreams = st
            from.startActivity(
                Intent(from, PlayerActivity::class.java)
                    .putExtra("dub", dubIdx).putExtra("se", se).putExtra("ep", ep).putExtra("pos", startSec)
            )
        }
    }

    private lateinit var d: Detail
    private lateinit var streams: Streams
    private var dubIdx = 0
    private var se = 0
    private var ep = 0

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: android.content.SharedPreferences

    // player + state
    private var player: ExoPlayer? = null
    private var curSrc: Source? = null
    private val triedUrls = HashSet<String>()
    private var caps: List<Caption> = emptyList()
    private var subIdx = -1
    private var lastPosMs = 0L
    private var lastDurMs = 0L
    private var lastSaveAt = 0L
    private var loadGen = 0
    private var loading = false
    private var ended = false
    private var countdown = 0           // > 0 while "Next episode in N s" is showing

    // views
    private lateinit var playerView: PlayerView
    private lateinit var spinner: ProgressBar
    private lateinit var pauseIcon: ImageView
    private lateinit var seekText: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var infoText: TextView
    private lateinit var seekBar: ProgressBar
    private lateinit var timeCur: TextView
    private lateinit var timeDur: TextView
    private lateinit var nextBox: TextView
    private lateinit var msgText: TextView
    private lateinit var langBtn: TextView
    private lateinit var qualityBtn: TextView
    private lateinit var audioBtn: TextView
    private lateinit var subBtn: TextView
    private lateinit var prevBtn: TextView
    private lateinit var nextBtn: TextView
    private lateinit var epsBtn: TextView
    private lateinit var autoBtn: TextView
    private lateinit var playBtn: TextView
    private lateinit var speedBtn: TextView
    private lateinit var bufBtn: TextView
    private lateinit var fitBtn: TextView
    private var controlsVisible = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dd = sDetail
        val ss = sStreams
        if (dd == null || ss == null) { finish(); return }   // app process was restarted: go back to the list
        d = dd
        streams = ss
        relayBad = false
        dubIdx = intent.getIntExtra("dub", 0)
        se = intent.getIntExtra("se", 0)
        ep = intent.getIntExtra("ep", 0)
        prefs = getSharedPreferences("player", Context.MODE_PRIVATE)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Net.init(applicationContext)
        buildUi()
        initGestures()
        val serverPos = intent.getDoubleExtra("pos", 0.0)
        lastPosMs = if (serverPos > 3.0) (serverPos * 1000).toLong() else prefs.getLong(posKey(), 0L)
        PlayerEvents.reset()
        PlayerEvents.played = true
        chooseSource()
        loadCaptions(loadGen)
        refreshButtons()
    }

    override fun onStart() {
        super.onStart()
        hideSystemUi()
        if (player == null) { initPlayer(); startPlayback(lastPosMs) }
        handler.post(tickRunnable)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(tickRunnable)
        capturePosition()
        saveProgress(false)
        releasePlayer()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (countdown > 0) { cancelCountdown(); return }
        finish()
    }

    // ------------------------------------------------------------------ UI (built in code, no layout xml)
    private fun pill(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(18), 0, dp(18), 0)
        isFocusable = true
        isClickable = true
        setBackgroundResource(R.drawable.pill_btn_bg)
        setOnClickListener { onClick(); showControls() }
    }

    private fun addBtn(row: LinearLayout, b: TextView) {
        row.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { rightMargin = dp(10) })
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        playerView = PlayerView(this).apply {
            useController = false
            isFocusable = false
            resizeMode = resizeModeFor(prefs.getString("fit", "fit"))
            setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
            subtitleView?.apply {
                setApplyEmbeddedStyles(false)
                setStyle(CaptionStyleCompat(Color.WHITE, Color.TRANSPARENT, Color.TRANSPARENT, CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, null))
                setFractionalTextSize(0.058f)
            }
        }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))

        spinner = ProgressBar(this, null, android.R.attr.progressBarStyleLarge)
        root.addView(spinner, FrameLayout.LayoutParams(dp(72), dp(72), Gravity.CENTER))

        pauseIcon = ImageView(this).apply { setImageResource(R.drawable.ic_pause); visibility = View.GONE }
        root.addView(pauseIcon, FrameLayout.LayoutParams(dp(96), dp(96), Gravity.CENTER))

        seekText = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 26f; typeface = Typeface.DEFAULT_BOLD
            setBackgroundResource(R.drawable.pill_bg); setPadding(dp(22), dp(8), dp(22), dp(8)); visibility = View.GONE
        }
        root.addView(seekText, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).apply { bottomMargin = dp(190) })

        msgText = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.pill_bg); setPadding(dp(28), dp(14), dp(28), dp(14)); visibility = View.GONE
        }
        root.addView(msgText, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        nextBox = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD
            setBackgroundResource(R.drawable.pill_bg); setPadding(dp(26), dp(12), dp(26), dp(12)); visibility = View.GONE
        }
        root.addView(nextBox, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { bottomMargin = dp(200); rightMargin = dp(48) })

        // top bar: title + info
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.scrim_top)
            setPadding(dp(48), dp(28), dp(48), dp(40))
            visibility = View.GONE
        }
        titleText = TextView(this).apply { setTextColor(Color.WHITE); textSize = 24f; typeface = Typeface.DEFAULT_BOLD; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        infoText = TextView(this).apply { setTextColor(0xFFCCCCD4.toInt()); textSize = 15f; maxLines = 1 }
        topBar.addView(titleText); topBar.addView(infoText)
        root.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // bottom bar: seek bar, times, buttons
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.scrim_bottom)
            setPadding(dp(48), dp(44), dp(48), dp(28))
            visibility = View.GONE
        }
        seekBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            isIndeterminate = false
            @Suppress("DEPRECATION")
            progressDrawable = resources.getDrawable(R.drawable.seek_progress)
        }
        // touch: a taller area around the thin bar, drag / tap on it to seek
        val seekHit = FrameLayout(this)
        seekHit.addView(seekBar, FrameLayout.LayoutParams(-1, dp(8), Gravity.CENTER_VERTICAL))
        seekHit.setOnTouchListener { v, e -> scrub(v, e) }
        bottomBar.addView(seekHit, LinearLayout.LayoutParams(-1, dp(30)))
        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(10)) }
        timeCur = TextView(this).apply { setTextColor(Color.WHITE); textSize = 18f; text = "0:00" }
        timeDur = TextView(this).apply { setTextColor(0xCCFFFFFF.toInt()); textSize = 18f; text = "0:00"; gravity = Gravity.END }
        times.addView(timeCur, LinearLayout.LayoutParams(0, -2, 1f))
        times.addView(timeDur, LinearLayout.LayoutParams(-2, -2))
        bottomBar.addView(times)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        playBtn = pill("Pause") { player?.let { it.playWhenReady = !it.playWhenReady; refreshPlayState() } }
        speedBtn = pill("Speed: 1x") { showSpeedDialog() }
        bufBtn = pill("Buffer: Auto") { showBufferDialog() }
        fitBtn = pill("Screen: Fit") { cycleFit() }
        langBtn = pill("Language") { showLanguageDialog() }
        qualityBtn = pill("Quality") { showQualityDialog() }
        audioBtn = pill("Audio") { showAudioDialog() }
        subBtn = pill("Subtitles") { showSubtitleDialog() }
        prevBtn = pill("‹ Prev") { goEpisode(prevEp(), false) }
        nextBtn = pill("Next ›") { goEpisode(nextEp(), false) }
        epsBtn = pill("Episodes") { showEpisodesDialog() }
        autoBtn = pill("") { prefs.edit().putBoolean("autonext", !autoNext()).apply(); refreshButtons() }
        for (b in listOf(playBtn, prevBtn, nextBtn, epsBtn, langBtn, qualityBtn, audioBtn, subBtn, speedBtn, bufBtn, fitBtn, autoBtn)) addBtn(row, b)
        bottomBar.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        setContentView(root)
    }

    private fun allBtns(): List<TextView> =
        listOf(playBtn, prevBtn, nextBtn, epsBtn, langBtn, qualityBtn, audioBtn, subBtn, speedBtn, bufBtn, fitBtn, autoBtn).filter { it.visibility == View.VISIBLE }

    private fun autoNext() = prefs.getBoolean("autonext", true)

    private fun refreshButtons() {
        val series = d.series
        langBtn.visibility = if (d.dubs.size > 1) View.VISIBLE else View.GONE
        langBtn.text = "Language: " + (d.dubs.getOrNull(dubIdx)?.lang ?: "Default")
        qualityBtn.visibility = if (visibleSources().size > 1) View.VISIBLE else View.GONE
        qualityBtn.text = "Quality: " + (curSrc?.label ?: "Auto")
        subBtn.text = "Subtitles: " + (caps.getOrNull(subIdx)?.lang ?: "Off")
        prevBtn.visibility = if (series && prevEp() != null) View.VISIBLE else View.GONE
        nextBtn.visibility = if (series && nextEp() != null) View.VISIBLE else View.GONE
        epsBtn.visibility = if (series) View.VISIBLE else View.GONE
        autoBtn.visibility = if (series) View.VISIBLE else View.GONE
        autoBtn.text = if (autoNext()) "✓ Auto-next" else "Auto-next: Off"
        speedBtn.text = "Speed: " + speedLabel(curSpeed())
        fitBtn.text = "Screen: " + when (prefs.getString("fit", "fit")) { "zoom" -> "Fill"; "stretch" -> "Stretch"; else -> "Fit" }
        bufBtn.text = "Buffer: " + when (prefs.getString("buf", "auto")) { "low" -> "Low"; "high" -> "High"; else -> "Auto" }
        refreshAudioBtn()
        titleText.text = d.title + if (series) "   S$se · E$ep" else ""
        infoText.text = listOfNotNull(d.dubs.getOrNull(dubIdx)?.lang, curSrc?.label).joinToString("  ·  ")
    }

    // ------------------------------------------------------------------ controls show / hide
    private val hideRunnable = Runnable {
        val p = player
        // hides after 4s while playing, even if a button has focus (any remote key shows them again)
        if (p == null || !p.playWhenReady || p.playbackState != Player.STATE_READY) handlerReschedule() else setControls(false)
    }

    private fun handlerReschedule() { handler.removeCallbacks(hideRunnable); handler.postDelayed(hideRunnable, 4000) }

    private fun showControls() {
        setControls(true)
        handlerReschedule()
        tick()
    }

    private fun setControls(v: Boolean) {
        controlsVisible = v
        topBar.visibility = if (v) View.VISIBLE else View.GONE
        bottomBar.visibility = if (v) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------------ player
    private fun initPlayer() {
        if (player != null) return
        val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val lowEnd = am.isLowRamDevice || am.memoryClass <= 96 || Runtime.getRuntime().availableProcessors() <= 2
        val bigRam = !lowEnd && am.memoryClass >= 192

        val renderers = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
            .setEnableDecoderFallback(true)
            .forceEnableMediaCodecAsynchronousQueueing()

        // Site host (subtitles): device id + TV pass. Every other host = the video CDN: Referer / User-Agent added here (this replaces the relay).
        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .addInterceptor { chain ->
                val req = chain.request()
                if (req.url.host == Net.siteHost) {
                    val b = req.newBuilder()
                    for ((k, v) in Net.guardHeaders()) b.header(k, v)
                    chain.proceed(b.build())
                } else if (Relay.isRelayHost(req.url.host)) {
                    chain.proceed(req)          // relay link: signed, carries its own Referer, must stay https as it is
                } else cdnFetch(chain, req)
            }
            .build()
        val http = OkHttpDataSource.Factory(client).setUserAgent(UA)

        // Buffer: Low / Auto (by device) / High  (menu "Buffer" in the player; the player is rebuilt when it changes)
        val bufMode = prefs.getString("buf", "auto") ?: "auto"
        val minMs: Int; val maxMs: Int; val maxBytes: Int
        when (bufMode) {
            "low" -> { minMs = 15_000; maxMs = 30_000; maxBytes = 16 * 1024 * 1024 }
            "high" -> { minMs = if (lowEnd) 30_000 else 50_000; maxMs = if (lowEnd) 60_000 else 180_000; maxBytes = if (lowEnd) 32 * 1024 * 1024 else 128 * 1024 * 1024 }
            else -> {
                minMs = if (lowEnd) 20_000 else 30_000
                maxMs = if (lowEnd) 45_000 else if (bigRam) 120_000 else 80_000
                maxBytes = if (lowEnd) 24 * 1024 * 1024 else if (bigRam) 96 * 1024 * 1024 else 56 * 1024 * 1024
            }
        }
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(minMs, maxMs, 2_000, 4_000)
            .setTargetBufferBytes(maxBytes)
            .setPrioritizeTimeOverSizeThresholds(!lowEnd)
            .setBackBuffer(if (lowEnd) 5_000 else 15_000, !lowEnd)
            .build()

        val bandwidth = DefaultBandwidthMeter.Builder(this)
            .setInitialBitrateEstimate(if (lowEnd) 2_000_000L else 3_500_000L)
            .build()
        val selector = DefaultTrackSelector(this, AdaptiveTrackSelection.Factory(15_000, 8_000, 25_000, 0.75f))

        val p = ExoPlayer.Builder(this, renderers)
            .setBandwidthMeter(bandwidth)
            .setTrackSelector(selector)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http).setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(6)))
            .setLoadControl(load)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.setSeekParameters(SeekParameters.CLOSEST_SYNC)
        p.addListener(listener)
        playerView.player = p
        player = p
    }

    // ------------------------------------------------------------------ the relay's job, done by the app
    private val cdnFallbackHosts = listOf("cacdn.hakunaymatata.com", "sbcdn5.hakunaymatata.com")
    private val cdnRefuse = setOf(401, 403, 404, 410, 426, 427, 451)
    private val hostMemory = java.util.concurrent.ConcurrentHashMap<String, Pair<String, String>>()   // refused host -> (host that worked, user-agent)
    @Volatile private var plainHttp = false    // set when this TV cannot do the CDN's https (old TVs): then plain http is used, like the relay's http-first

    private fun cdnReq(r: okhttp3.Request, host: String? = null, ua: String = CDN_UA, http: Boolean = false): okhttp3.Request {
        val ref = streams.ref
        var u = r.url
        if (host != null) u = u.newBuilder().host(host).build()
        if (http && u.isHttps) u = u.newBuilder().scheme("http").build()
        return r.newBuilder().url(u)
            .header("User-Agent", ua)
            .header("Referer", ref)
            .header("Origin", ref.trimEnd('/'))
            .header("Accept", "*/*")
            .header("Accept-Encoding", "identity")
            .build()
    }

    private fun cdnFetch(chain: okhttp3.Interceptor.Chain, req: okhttp3.Request): okhttp3.Response {
        val orig = req.url.host
        val isCdn = orig.endsWith("hakunaymatata.com")
        val mem = if (isCdn) hostMemory[orig] else null
        if (mem != null) {
            try {
                val r = chain.proceed(cdnReq(req, mem.first, mem.second, plainHttp))
                if (r.code < 400) return r
                r.close()
            } catch (e: java.io.IOException) { }
            hostMemory.remove(orig)
        }
        var resp: okhttp3.Response
        try {
            resp = chain.proceed(cdnReq(req, null, CDN_UA, plainHttp))
        } catch (e: javax.net.ssl.SSLException) {
            if (plainHttp) throw e
            plainHttp = true                      // https handshake failed on this TV -> plain http from now on
            resp = chain.proceed(cdnReq(req, null, CDN_UA, true))
        }
        if (resp.code < 400 || !isCdn || resp.code !in cdnRefuse) return resp
        resp.close()
        // this CDN host refuses this connection (426 / 427 ...): the same path on the other CDN hosts, then the other User-Agent
        for (h in cdnFallbackHosts) {
            if (h == orig) continue
            for (ua in listOf(CDN_UA, CDN_UA_ALT)) {
                try {
                    val r = chain.proceed(cdnReq(req, h, ua, plainHttp))
                    if (r.code < 400) { hostMemory[orig] = Pair(h, ua); return r }
                    r.close()
                } catch (e: java.io.IOException) { }
            }
        }
        return chain.proceed(cdnReq(req, null, CDN_UA, plainHttp))     // give the player the real error
    }

    private fun releasePlayer() {
        val p = player ?: return
        player = null
        playerView.player = null
        p.removeListener(listener)
        p.release()
    }

    @Volatile private var relayBad = false   // a relay link failed for this video: everything else of it plays direct

    private fun visibleSources(): List<Source> = if (relayBad) streams.sources.map { Relay.direct(it) } else streams.sources

    /** Picks the remembered quality (by label) or the first (= best / Auto HLS). */
    private fun chooseSource() {
        val vis = visibleSources()
        val want = prefs.getString("q", null)
        val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val weak = am.isLowRamDevice || am.memoryClass <= 96 || Runtime.getRuntime().availableProcessors() <= 2
        curSrc = vis.firstOrNull { it.label == want }
            ?: (if (weak) vis.firstOrNull { it.res in 1..720 } else null)
            ?: vis.firstOrNull()
        triedUrls.clear()
    }

    private fun curUrl(): String = Net.abs(curSrc?.url ?: "")

    private fun buildItem(): MediaItem {
        val u = curUrl()
        val b = MediaItem.Builder().setUri(Uri.parse(u))
        val s = curSrc
        if (s != null && (s.kind == "hls" || u.contains(".m3u8", ignoreCase = true))) b.setMimeType(MimeTypes.APPLICATION_M3U8)
        val c = caps.getOrNull(subIdx)
        if (c != null) {
            b.setSubtitleConfigurations(
                listOf(
                    MediaItem.SubtitleConfiguration.Builder(Uri.parse(Net.abs(c.url)))
                        .setMimeType(MimeTypes.TEXT_VTT)
                        .setLanguage(c.lang)
                        .setLabel(c.lang)
                        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                        .build()
                )
            )
        }
        return b.build()
    }

    private fun startPlayback(posMs: Long) {
        val p = player ?: return
        if (curSrc == null) { fatal(streams.note.ifEmpty { "No video found." }); return }
        ended = false
        cancelCountdown()
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, subIdx < 0)
            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
            .build()
        lastPosMs = posMs
        p.setPlaybackSpeed(curSpeed())
        gotFrame = false
        handler.removeCallbacks(blackRunnable)
        handler.postDelayed(blackRunnable, 12_000L)
        p.setMediaItem(buildItem(), posMs.coerceAtLeast(0L))
        p.prepare()
        p.playWhenReady = true
        spinner.visibility = View.VISIBLE
        msgText.visibility = View.GONE
        refreshButtons()
        showControls()
    }

    private fun posMs(): Long = player?.currentPosition ?: lastPosMs

    /** Source / subtitle changed: continue from the same second. */
    private fun reloadHere() = startPlayback(posMs())

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_BUFFERING -> spinner.visibility = View.VISIBLE
                Player.STATE_READY -> { spinner.visibility = View.GONE; loading = false; refreshPlayState(); if (Relay.isRelay(curSrc)) Relay.ok() }
                Player.STATE_ENDED -> onEnded()
                else -> {}
            }
        }
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = refreshPlayState()
        override fun onTracksChanged(tracks: Tracks) = refreshAudioBtn()
        override fun onPlayerError(error: PlaybackException) = handlePlayerError(error)
        override fun onRenderedFirstFrame() { gotFrame = true; handler.removeCallbacks(blackRunnable) }
    }

    // ---- black screen guard: sound / time run but the TV's decoder draws no picture (typical for 1080p on weak TVs) -> try the next lower quality
    @Volatile private var gotFrame = false
    private val blackRunnable = Runnable {
        val p = player ?: return@Runnable
        if (!gotFrame && p.playbackState != Player.STATE_READY) { handler.postDelayed(blackRunnable, 5_000L); return@Runnable }   // still loading: look again
        if (!gotFrame && p.playWhenReady) {
            val cur = curSrc
            if (cur != null) triedUrls.add(cur.url)
            val next = visibleSources().filter { !triedUrls.contains(it.url) }.let { l -> l.firstOrNull { it.res in 1 until (cur?.res ?: 100000) } ?: l.firstOrNull() }
            if (next != null) { curSrc = next; toast("No picture, trying " + next.label + "\u2026"); startPlayback(posMs()) }
            else fatal("This TV cannot show the video.\nTry another quality in the menu.")
        }
    }

    private fun refreshPlayState() {
        val p = player ?: return
        val paused = !p.playWhenReady && p.playbackState == Player.STATE_READY
        pauseIcon.visibility = if (paused) View.VISIBLE else View.GONE
        playBtn.text = if (p.playWhenReady) "Pause" else "Play"
        if (paused) showControls()
    }

    /** Link failed (the CDN host fallbacks already ran inside the HTTP layer): try the next quality, else give up. */
    private fun handlePlayerError(e: PlaybackException) {
        val cur = curSrc
        if (cur != null) {
            if (Relay.isRelay(cur)) {
                // relay link failed: count it and play the SAME quality direct right away
                Relay.fail()
                relayBad = true
                curSrc = Relay.direct(cur)
                toast("Relay failed, playing direct\u2026")
                startPlayback(posMs())
                return
            }
            triedUrls.add(cur.url)
            val next = visibleSources().firstOrNull { !triedUrls.contains(it.url) }
            if (next != null) {
                curSrc = next
                toast("Trying " + next.label + "\u2026")
                startPlayback(posMs())
                return
            }
        }
        fatal("Video could not be played.\nPress Back, then try again.")
    }

    private fun fatal(msg: String) {
        spinner.visibility = View.GONE
        msgText.text = msg
        msgText.visibility = View.VISIBLE
    }

    // ------------------------------------------------------------------ tick (seek bar, progress)
    private val tickRunnable = object : Runnable {
        override fun run() { tick(); handler.postDelayed(this, 500) }
    }

    private fun capturePosition() {
        val p = player ?: return
        if (p.playbackState == Player.STATE_IDLE) return
        lastPosMs = p.currentPosition
        val du = p.duration
        if (du != C.TIME_UNSET && du > 0) lastDurMs = du
    }

    private fun tick() {
        val p = player ?: return
        capturePosition()
        val shown = if (pendingSeekMs >= 0) pendingSeekMs else lastPosMs
        if (controlsVisible) {
            seekBar.progress = if (lastDurMs > 0) ((shown * 1000L) / lastDurMs).toInt().coerceIn(0, 1000) else 0
            val buf = p.bufferedPosition
            seekBar.secondaryProgress = if (lastDurMs > 0) ((buf * 1000L) / lastDurMs).toInt().coerceIn(0, 1000) else 0
            timeCur.text = fmt(shown)
            timeDur.text = fmt(lastDurMs)
        }
        PlayerEvents.report(lastPosMs / 1000.0, lastDurMs / 1000.0)
        val now = android.os.SystemClock.elapsedRealtime()
        if (p.isPlaying && now - lastSaveAt >= 10_000) { lastSaveAt = now; saveProgress(false) }
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%d:%02d", m, sec)
    }

    private fun posKey() = "pos_${d.id}_${se}_$ep"

    /** Remembers where we are: on this TV (always) and in the account (when signed in) so Continue watching works. */
    private fun saveProgress(done: Boolean) {
        if (lastDurMs <= 0) return
        val pos = if (done) lastDurMs / 1000.0 else lastPosMs / 1000.0
        if (!done && pos < 5.0) return
        if (done || lastPosMs >= lastDurMs - 20_000) prefs.edit().remove(posKey()).apply()
        else prefs.edit().putLong(posKey(), lastPosMs).apply()
        if (Net.token == null) return
        val body = JSONObject()
            .put("sid", d.id).put("season", se).put("episode", ep)
            .put("pos", pos).put("dur", lastDurMs / 1000.0)
            .put("slug", d.slug).put("name", d.title).put("poster_url", d.poster)
        d.rating?.let { body.put("rating", it) }
        Net.async({ Net.request("/api/progress", body) }, { }, { })
    }

    // ------------------------------------------------------------------ episodes
    private fun nextEp(): Pair<Int, Int>? {
        if (!d.series) return null
        val i = d.seasons.indexOfFirst { it.se == se }
        if (i < 0) return null
        return if (ep < d.seasons[i].n) Pair(se, ep + 1) else d.seasons.getOrNull(i + 1)?.let { Pair(it.se, 1) }
    }

    private fun prevEp(): Pair<Int, Int>? {
        if (!d.series) return null
        val i = d.seasons.indexOfFirst { it.se == se }
        if (i < 0) return null
        return if (ep > 1) Pair(se, ep - 1) else d.seasons.getOrNull(i - 1)?.let { Pair(it.se, it.n) }
    }

    private fun onEnded() {
        if (ended) return
        ended = true
        capturePosition()
        saveProgress(true)
        val nx = nextEp()
        if (nx != null && autoNext()) startCountdown(nx) else finish()
    }

    private var countdownTarget: Pair<Int, Int>? = null
    private val countdownRunnable = object : Runnable {
        override fun run() {
            if (countdown <= 0) return
            countdown--
            if (countdown <= 0) { nextBox.visibility = View.GONE; goEpisode(countdownTarget, true); return }
            paintCountdown()
            handler.postDelayed(this, 1000)
        }
    }

    private fun paintCountdown() { nextBox.text = "Next episode in ${countdown}s    OK = play now    Back = cancel" }

    private fun startCountdown(nx: Pair<Int, Int>) {
        countdownTarget = nx
        countdown = 6
        nextBox.visibility = View.VISIBLE
        handler.removeCallbacks(countdownRunnable)
        countdown--
        paintCountdown()
        handler.postDelayed(countdownRunnable, 1000)
    }

    private fun cancelCountdown() {
        if (countdown <= 0 && nextBox.visibility != View.VISIBLE) return
        countdown = 0
        handler.removeCallbacks(countdownRunnable)
        nextBox.visibility = View.GONE
    }

    /** Loads the video links of another episode (or the same one in another dub) and plays them. */
    private fun goEpisode(target: Pair<Int, Int>?, auto: Boolean) {
        if (target == null) { if (auto) finish(); return }
        loadStreams(dubIdx, target.first, target.second, 0L, auto)
    }

    /** [startMs] = where to continue (language switch: same second; new episode: the saved position or 0). */
    private fun loadStreams(newDub: Int, newSe: Int, newEp: Int, startMsIn: Long, auto: Boolean) {
        if (loading) return
        loading = true
        cancelCountdown()
        if (newSe != se || newEp != ep) { capturePosition(); saveProgress(false) }
        val gen = ++loadGen
        val dub = d.dubs.getOrNull(newDub)
        val id = dub?.id ?: d.id
        val slug = dub?.slug ?: d.slug
        spinner.visibility = View.VISIBLE
        player?.pause()
        Net.async({ Guard.watch(id, slug, newSe, newEp) }, { st ->
            if (gen != loadGen) return@async
            loading = false
            if (st.sources.isEmpty()) {
                toast(st.note.ifEmpty { "No video found for this one." })
                spinner.visibility = View.GONE
                if (auto) finish() else player?.play()
                return@async
            }
            val episodeChanged = newSe != se || newEp != ep
            dubIdx = newDub; se = newSe; ep = newEp
            streams = st
            relayBad = false
            caps = emptyList(); subIdx = -1
            chooseSource()
            val startMs = if (startMsIn > 0) startMsIn else if (episodeChanged) prefs.getLong(posKey(), 0L) else 0L
            startPlayback(startMs)
            loadCaptions(gen)
        }, { e ->
            if (gen != loadGen) return@async
            loading = false
            spinner.visibility = View.GONE
            when {
                Guard.isCaptcha(e) -> TvPair.show(this) { ok -> if (ok) loadStreams(newDub, newSe, newEp, startMsIn, auto) else { if (auto) finish() else player?.play() } }
                Guard.isSignin(e) -> { toast("Free videos finished. Please sign in on the home screen."); finish() }
                else -> { toast(Guard.message(e)); if (auto) finish() else player?.play() }
            }
        })
    }

    // ------------------------------------------------------------------ subtitles
    /** All subtitle languages of this video. The remembered language is switched on by itself. */
    private fun loadCaptions(gen: Int) {
        val dub = d.dubs.getOrNull(dubIdx)
        val id = dub?.id ?: d.id
        val slug = dub?.slug ?: d.slug
        val st = streams
        Net.async({ Api.captions(id, slug, st) }, { list ->
            if (gen != loadGen) return@async
            caps = list
            val want = prefs.getString("sub", "off") ?: "off"
            if (want != "off") {
                val i = list.indexOfFirst { it.lang.equals(want, ignoreCase = true) }
                if (i >= 0) { subIdx = i; reloadHere(); return@async }
            }
            refreshButtons()
        }, { refreshButtons() })
    }

    private fun showSubtitleDialog() {
        if (caps.isEmpty()) { toast("No subtitles for this video."); return }
        val names = ArrayList<String>()
        names.add("Off"); caps.forEach { names.add(it.lang) }
        dialog("Subtitles", names, subIdx + 1) { i ->
            subIdx = i - 1
            prefs.edit().putString("sub", if (subIdx < 0) "off" else caps[subIdx].lang).apply()
            reloadHere()
        }
    }

    // ------------------------------------------------------------------ language / quality / audio / episodes dialogs
    private fun dialog(title: String, items: List<String>, checked: Int, pick: (Int) -> Unit) {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(title)
            .setSingleChoiceItems(items.toTypedArray(), checked) { dlg, i -> dlg.dismiss(); pick(i); hideSystemUi() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Screen: Fit (whole picture, black bars) -> Fill (picture fills the screen, edges cut) -> Stretch (fills, picture is stretched). */
    private fun resizeModeFor(v: String?): Int = when (v) {
        "zoom" -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        "stretch" -> AspectRatioFrameLayout.RESIZE_MODE_FILL
        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
    }

    private fun cycleFit() {
        val next = when (prefs.getString("fit", "fit")) { "fit" -> "zoom"; "zoom" -> "stretch"; else -> "fit" }
        prefs.edit().putString("fit", next).apply()
        playerView.resizeMode = resizeModeFor(next)
        refreshButtons()
        flash(when (next) { "zoom" -> "Fill screen"; "stretch" -> "Stretch"; else -> "Fit" })
    }

    private val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
    private fun curSpeed(): Float = prefs.getFloat("speed", 1f)
    private fun speedLabel(v: Float): String = (if (v == v.toInt().toFloat()) v.toInt().toString() else v.toString()) + "x"

    private fun showSpeedDialog() {
        val cur = speeds.indexOf(curSpeed())
        dialog("Playback speed", speeds.map { speedLabel(it) }, cur) { i ->
            prefs.edit().putFloat("speed", speeds[i]).apply()
            player?.setPlaybackSpeed(speeds[i])
            refreshButtons()
        }
    }

    private fun showBufferDialog() {
        val keys = listOf("low", "auto", "high")
        val cur = keys.indexOf(prefs.getString("buf", "auto") ?: "auto").coerceAtLeast(1)
        dialog("Buffer", listOf("Low (saves memory)", "Auto (by this device)", "High (smoother on slow internet)"), cur) { i ->
            prefs.edit().putString("buf", keys[i]).apply()
            // the buffer size is fixed when the player is built: rebuild it and continue from the same second
            val pos = posMs()
            releasePlayer()
            initPlayer()
            startPlayback(pos)
        }
    }

    private fun showLanguageDialog() {
        if (d.dubs.size < 2) return
        dialog("Language", d.dubs.map { it.lang }, dubIdx) { i ->
            if (i != dubIdx) loadStreams(i, se, ep, posMs(), false)
        }
    }

    private fun showQualityDialog() {
        val vis = visibleSources()
        val cur = vis.indexOfFirst { it.label == curSrc?.label }
        dialog("Quality", vis.map { it.label }, cur) { i ->
            val s = vis[i]
            prefs.edit().putString("q", s.label).apply()
            curSrc = s; triedUrls.clear()
            reloadHere()
        }
    }

    private data class AudioOpt(val group: Tracks.Group, val index: Int, val label: String, val selected: Boolean)

    private fun audioOptions(): List<AudioOpt> {
        val p = player ?: return emptyList()
        val out = ArrayList<AudioOpt>()
        var n = 0
        for (g in p.currentTracks.groups) {
            if (g.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                n++
                val f = g.getTrackFormat(i)
                val name = f.label?.takeIf { it.isNotBlank() }
                    ?: f.language?.takeIf { it.isNotBlank() && it != "und" }?.let { Locale(it).displayLanguage.ifBlank { it } }
                    ?: "Audio $n"
                out.add(AudioOpt(g, i, name, g.isTrackSelected(i)))
            }
        }
        return out
    }

    private fun refreshAudioBtn() {
        val a = audioOptions()
        audioBtn.visibility = View.VISIBLE
        audioBtn.text = "Audio: " + (a.firstOrNull { it.selected }?.label ?: "Auto")
    }

    private fun showAudioDialog() {
        val a = audioOptions()
        if (a.size < 2) { toast("Only one audio track in this video."); return }
        dialog("Audio", a.map { it.label }, a.indexOfFirst { it.selected }) { i ->
            val o = a[i]
            val p = player ?: return@dialog
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setOverrideForType(TrackSelectionOverride(o.group.mediaTrackGroup, listOf(o.index)))
                .build()
        }
    }

    private fun showEpisodesDialog() {
        if (!d.series) return
        fun pickEpisode(s: Season) {
            val items = (1..s.n).map { "Episode $it" }
            dialog("Season ${s.se}", items, if (s.se == se) ep - 1 else -1) { i ->
                if (s.se != se || i + 1 != ep) goEpisode(Pair(s.se, i + 1), false)
            }
        }
        if (d.seasons.size > 1) {
            dialog("Season", d.seasons.map { "Season ${it.se}" }, d.seasons.indexOfFirst { it.se == se }) { i -> pickEpisode(d.seasons[i]) }
        } else d.seasons.firstOrNull()?.let { pickEpisode(it) }
    }

    // ------------------------------------------------------------------ touch (phone / tablet)
    //  tap = show / hide controls     double tap left / right = -10 s / +10 s     double tap middle = play / pause
    //  swipe up / down on the left half = brightness, on the right half = volume     drag on the seek bar = seek
    private lateinit var gestures: GestureDetector
    private var swipeMode = 0            // 0 none, 1 volume, 2 brightness
    private var swipeStartVol = 0
    private var swipeStartBright = 0.5f
    private val hideSeekText = Runnable { seekText.visibility = View.GONE }

    private fun inView(v: View, x: Float, y: Float): Boolean {
        if (v.visibility != View.VISIBLE) return false
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return x >= loc[0] && x <= loc[0] + v.width && y >= loc[1] && y <= loc[1] + v.height
    }

    private fun onBars(e: MotionEvent) = inView(bottomBar, e.rawX, e.rawY) || inView(topBar, e.rawX, e.rawY) || inView(nextBox, e.rawX, e.rawY)

    private fun flash(msg: String) {
        seekText.text = msg
        seekText.visibility = View.VISIBLE
        handler.removeCallbacks(hideSeekText)
        handler.postDelayed(hideSeekText, 900)
    }

    private fun initGestures() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        nextBox.setOnClickListener { val t = countdownTarget; cancelCountdown(); goEpisode(t, true) }
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean { swipeMode = 0; return true }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (onBars(e)) return false
                if (controlsVisible) { handler.removeCallbacks(hideRunnable); setControls(false) } else showControls()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (onBars(e)) return false
                val w = window.decorView.width.toFloat()
                when {
                    e.x < w / 3f -> seekBy(-10_000L)
                    e.x > w * 2f / 3f -> seekBy(10_000L)
                    else -> player?.let { it.playWhenReady = !it.playWhenReady; refreshPlayState() }
                }
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (e1 == null || onBars(e1)) return false
                if (swipeMode == 0) {
                    if (Math.abs(dy) < Math.abs(dx) * 1.5f) return false
                    swipeMode = if (e1.x < window.decorView.width / 2f) 2 else 1
                    swipeStartVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                    swipeStartBright = window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it }
                }
                val frac = (e1.y - e2.y) / window.decorView.height.toFloat().coerceAtLeast(1f) * 1.2f
                if (swipeMode == 1) {
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    val v = Math.round(swipeStartVol + frac * max).coerceIn(0, max)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                    flash("Volume " + (v * 100 / max.coerceAtLeast(1)) + "%")
                } else {
                    val b = (swipeStartBright + frac).coerceIn(0.02f, 1f)
                    val wl = window.attributes
                    wl.screenBrightness = b
                    window.attributes = wl
                    flash("Brightness " + (b * 100).toInt() + "%")
                }
                return true
            }
        })
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::gestures.isInitialized) gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    /** Touch on the seek bar: finger position = time, the video jumps when the finger is lifted. */
    private fun scrub(v: View, e: MotionEvent): Boolean {
        val dur = lastDurMs
        if (dur <= 0) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                v.parent?.requestDisallowInterceptTouchEvent(true)
                val f = (e.x / v.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                pendingSeekMs = (f * dur).toLong().coerceAtMost((dur - 1000L).coerceAtLeast(0L))
                seekAnchorMs = lastPosMs
                seekText.text = fmt(pendingSeekMs)
                seekText.visibility = View.VISIBLE
                handler.removeCallbacks(applySeek)
                handler.removeCallbacks(hideSeekText)
                handlerReschedule()
                tick()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(applySeek)
                handler.post(applySeek)
            }
        }
        return true
    }

    // ------------------------------------------------------------------ remote control
    private var pendingSeekMs = -1L
    private var seekAnchorMs = 0L
    private var lastHoldAt = 0L

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val down = event.action == KeyEvent.ACTION_DOWN
        val key = event.keyCode

        // "Next episode in 5 s": OK plays now, Back cancels
        if (countdown > 0) {
            if (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER) {
                if (down && event.repeatCount == 0) { val t = countdownTarget; cancelCountdown(); goEpisode(t, true) }
                return true
            }
            return super.dispatchKeyEvent(event)
        }

        val cf = currentFocus
        val onBtn = cf != null && cf in allBtns()
        if (onBtn) {
            when (key) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { if (down) showControls(); return super.dispatchKeyEvent(event) }
                KeyEvent.KEYCODE_DPAD_UP -> { if (down) { cf?.clearFocus(); showControls() }; return true }
                KeyEvent.KEYCODE_DPAD_DOWN -> return true
            }
        }
        when (key) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (down && event.repeatCount == 0) player?.let { it.playWhenReady = !it.playWhenReady; refreshPlayState(); showControls() }
                return true
            }
            KeyEvent.KEYCODE_MEDIA_NEXT -> { if (down && event.repeatCount == 0) goEpisode(nextEp(), false); return true }
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { if (down && event.repeatCount == 0) goEpisode(prevEp(), false); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY -> { if (down) { player?.playWhenReady = true; refreshPlayState() }; return true }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> { if (down) { player?.playWhenReady = false; refreshPlayState() }; return true }
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> { onSeekKey(event, -1, key == KeyEvent.KEYCODE_MEDIA_REWIND); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { onSeekKey(event, +1, key == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD); return true }
            KeyEvent.KEYCODE_DPAD_UP -> { if (down) showControls(); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (down) {
                    if (!controlsVisible) showControls()
                    else allBtns().firstOrNull()?.requestFocus()
                    handlerReschedule()
                }
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    /** Left / Right: one press = 10 s; holding the key makes the steps bigger (10, 20, 40, 60 s). The seek happens after a short pause. */
    private fun onSeekKey(e: KeyEvent, dir: Int, media: Boolean) {
        if (e.action != KeyEvent.ACTION_DOWN) return
        val sec = when {
            media -> 30
            e.repeatCount == 0 -> 10
            else -> {
                if (e.eventTime - lastHoldAt < 250) return
                val held = e.eventTime - e.downTime
                when { held < 1500 -> 10; held < 3500 -> 20; held < 6000 -> 40; else -> 60 }
            }
        }
        lastHoldAt = e.eventTime
        seekBy(dir * sec * 1000L)
    }

    private fun seekBy(delta: Long) {
        val p = player ?: return
        capturePosition()
        if (pendingSeekMs < 0) { seekAnchorMs = lastPosMs; pendingSeekMs = lastPosMs }
        var t = (pendingSeekMs + delta).coerceAtLeast(0L)
        if (lastDurMs > 0) t = t.coerceAtMost((lastDurMs - 1000L).coerceAtLeast(0L))
        pendingSeekMs = t
        seekText.text = String.format(Locale.US, "%+d s", ((t - seekAnchorMs) / 1000).toInt())
        seekText.visibility = View.VISIBLE
        showControls()
        handler.removeCallbacks(applySeek)
        handler.postDelayed(applySeek, 450)
        if (p.playbackState == Player.STATE_IDLE) return
    }

    private val applySeek = Runnable {
        val t = pendingSeekMs
        pendingSeekMs = -1L
        if (t >= 0) { player?.seekTo(t); lastPosMs = t }
        handler.postDelayed({ seekText.visibility = View.GONE }, 900)
        tick()
    }
}
