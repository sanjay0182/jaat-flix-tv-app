# JaatPlay TV (Android TV, native)

Anime-TV app ka same base, JaatFlix backend (Render) ke saath. WebView nahi hai.

## Parts
- Part 1: project base, Net/Guard/TvPair (QR TV pass), Api.kt.
- Part 2: full UI: home tabs, hero, rows, Continue watching, My List, All grid, search, detail (language, seasons, episodes), sign-in.
- **Part 3 (ye zip):** PlayerActivity: Language, Quality, Audio, Subtitles (sab languages), resume, auto-next, progress save. App ab poora hai.

## Backend (Render) - ZAROORI
`backend/` folder ki 3 files apni repo me replace/add karo: `api.py`, `protect.py`, `tv.html`. Phir Render redeploy.
Ye `/api/tv/new|poll|peek|finish` aur phone page `/tv` jodta hai, aur TV pass ko stream gate me maanta hai.

## Build
1. Is folder ko GitHub repo me daalo (`.github/workflows/build.yml` bhi).
2. `gradle.properties` me `SITE_URL` = Render ka link (abhi `https://jaatflex.onrender.com`).
3. Actions -> "Build Android TV APK" -> artifact `jaatflix-tv-debug-apk`.

## Test (part 3)
Detail page -> Play (ya episode). Player me:
- **OK** = play/pause. **Left/Right** = 10 sec seek (dabaye rakho = tez). **Up** = controls. **Down** = neeche ki button row me jao.
- **Language** (jab 2+ dub ho): dub badalta hai, usi second se chalta hai.
- **Quality**: Auto (HLS), 1080p, 720p... Link fail ho to khud server route / backup / dusri quality try karta hai.
- **Subtitles**: Off + sab languages (English, Hindi upar). Chuni hui language yaad rahti hai.
- **Audio**: sirf tab dikhta hai jab video me 2+ audio track hon.
- **Prev / Next / Episodes / Auto-next** (series). Episode khatam hone par 5 sec ka countdown: OK = abhi chalao, Back = cancel.
- Resume: sign-in ho to account ka Continue watching; guest ke liye isi TV par yaad rakhta hai. Har 10 sec me save hota hai.
- Player se Back dabao to home par Continue watching apne aap refresh hoti hai.

Note: gradle.properties me SITE_URL ko Render ka sahi link rakho. Backend files `backend/` pehle jaisi hi hain.

## Relay hata diya (part 3b)
App ab relay / Wispbyte / Render ke video links use NAHI karta, backup ke taur par bhi nahi.
- `Mb.kt`: app khud MovieBox se token + video links nikalta hai (website ke client-resolve jaisa), to links TV ke apne internet ke liye bante hain.
- Site ka guard (captcha / sign-in / limit) abhi bhi `/api/sign` se chalta hai, par uske diye hue relay links fenk diye jaate hain, sirf haan/na liya jaata hai.
- `PlayerActivity.kt` CDN ko seedha chalata hai aur relay wala kaam khud karta hai: Referer, Origin, User-Agent lagana, 426/427/403 par dusre CDN host (cacdn, sbcdn5) aur dusra User-Agent try karna, aur purane TV par https handshake fail ho to plain http.
- Isliye Wispbyte relay is app ke liye band bhi ho to koi fark nahi (website ke liye wo chalta rahe).
